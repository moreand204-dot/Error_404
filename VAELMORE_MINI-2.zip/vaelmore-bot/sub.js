import { SubBots } from "drakon";
import { runAutoJoin as joinChannel } from './libs/auto-join-channel.js';
import { enableChannelReactions } from './libs/channel-react.js';
import { resolveRealNumber } from './system/admin_utils.js';
import { autoSubscribeAllSubBots } from './libs/newsletter-subscribe.js';
import { applyTypingPresence } from './libs/typing-presence.js';

const VAELMORE_CHANNEL = '120363422581600030@newsletter';

async function sub(client) {
    // مرجع البوت الرئيسي: نظام الشكاوى في أي بوت فرعي يرسل للدعم عبر الرئيسي.
    global.__VAELMORE_MAIN_CLIENT = client;
    global.__VAELMORE_MAIN_CONN = client?.sock || global.__VAELMORE_MAIN_CONN || null;
    global.subBots = new SubBots(client.commandSystem);
    SubBots.pariCode("VAELMORE");

    const { config } = client;

    await global.subBots.setConfig({
        commandsPath: config.commandsPath || './plugins',
        owners:       config.owners,
        prefix:       config.prefix,
        info:         config.info,
        printQR:      false
    });

    global.subBots.on('error', (uid, error) => {
        const msg = error?.message || '';
        if (msg.includes('rate-overlimit')) return;
        if (msg.includes('Connection Closed')) return;
        console.error(`[SubBot ${uid}] Error:`, msg);
    });

    const loadedCount = await global.subBots.load();
    console.log(`✅ Loaded ${loadedCount} saved bots`);

    global.subBots.on('ready', (uid) => {
        console.log(`✅ [SubBot ${uid}] Connected!`);
        const bot = global.subBots.get(uid);
        if (bot?.sock) {
            applyTypingPresence(bot.sock); // ⌨️ "يكتب..." للبوت الفرعي
            joinChannel(bot.sock);
            enableChannelReactions(bot.sock, ['❤️', '🔥', '👍']); // ❤️ تفاعل القنوات لكل بوت فرعي
        }
    });

    // ⚠️ لازم عشان البوتات الفرعية تستقبل رسائل القناة أصلاً وتقدر تتفاعل معاها
    autoSubscribeAllSubBots(VAELMORE_CHANNEL);

    global.subBots.on('pair', (uid, code) => {
        console.log(`🔐 [SubBot ${uid}] Pairing code: ${code}`);
    });

    global.subBots.on('message', async (uid, msg) => {
        const body = getMessageText(msg);
        const bot = global.subBots.get(uid);
        const sock = bot?.sock;
        if (sock) applyTypingPresence(sock); // ⌨️ لو السوكيت اتبدل بعد إعادة اتصال
        if (!sock || !body) return;

        try {
            if (body === 'تست') {
                await sock.sendMessage(msg.key.remoteJid, {
                    react: { text: '✅', key: msg.key }
                });
            }
        } catch {}
    });

    global.subBots.on('close', (uid) => console.log(`🔌 [SubBot ${uid}] Disconnected`));
    global.subBots.on('badSession', (uid) => console.log(`⚠️ [SubBot ${uid}] Bad session, removed`));

    return global.subBots;
}

function getMessageText(msg) {
    if (!msg.message) return null;
    return msg.message.conversation
        || msg.message.extendedTextMessage?.text
        || msg.message.imageMessage?.caption
        || msg.message.videoMessage?.caption
        || msg.body
        || null;
}

export default sub;
