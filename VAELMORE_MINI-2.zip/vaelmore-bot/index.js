import fs from 'fs';
import { Client } from 'drakon';
import autoJoinChannel from './libs/auto-join-channel.js';
import { enableChannelReactions } from './libs/channel-react.js';
import BotDetector from './libs/bot-detector.js';
import { group, access } from "./system/control.js";
import UltraDB from "./system/UltraDB.js";
import keepServerAlive from './system/keep_alive.js';
import sub from './sub.js';
import { applyTypingPresence } from './libs/typing-presence.js';
import { keepNewsletterSubscribed } from './libs/newsletter-subscribe.js';

/* =========== إعدادات النسخة (bot.config.json) ✏️ ==========
   موقع صنع البوتات بيولّد الملف ده تلقائي. لو مش موجود بيتستخدم الافتراضي تحت.
   تقدر تعدّل الملف ده بإيدك بدل ما تعدّل الكود. */
const DEFAULT_CFG = {
    botName: '♡ 𝑽𝑨𝑬𝑳𝑴𝑶𝑹𝑬 𝑩𝑶𝑻👨🏻‍💻 〈',
    botNumber: '9647882892089',
    owners: [
        { name: '◥◣ 𝐕𝑬𝑵𝕆𝑀 ◢◤', jid: '201065948582@s.whatsapp.net', lid: '110462431670456@lid' },
        { name: '𝐋𝐨𝐫𝐝 𝐄𝐒𝐂𝐀𝐍𝛩𝐑', jid: '79312265574@s.whatsapp.net', lid: '275561477836913@lid' }
    ],
    channelName: '⚜️ 𝐕𝐀𝐄𝐋𝐌𝐎𝐑𝐄 | 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 𝐒𝐲𝐬𝐭𝐞𝐦',
    channelId: '120363422581600030@newsletter'
};
const loadCfg = () => {
    try {
        if (fs.existsSync('./bot.config.json')) {
            const c = JSON.parse(fs.readFileSync('./bot.config.json', 'utf8'));
            return { ...DEFAULT_CFG, ...Object.fromEntries(Object.entries(c).filter(([, v]) => v && (!Array.isArray(v) || v.length))) };
        }
    } catch (e) { console.error('[bot.config.json] فيه مشكلة، هستخدم الافتراضي:', e.message); }
    return DEFAULT_CFG;
};
const CFG = loadCfg();
const BOT_PHONE = String(CFG.botNumber).replace(/\D/g, '');

/* =========== Database ========== */
if (!global.db) global.db = new UltraDB();

/* =========== Client ✏️ إعدادات تقدر تغيّرها ========== */
const client = new Client({
    phoneNumber: BOT_PHONE,   // ✏️ رقم البوت - غيّره لو بدّلت الرقم
    prefix: ['.', '/', '!'],       // ✏️ البادئات اللي البوت بيرد عليها
    fromMe: false,                 // ⚠️ سيبها false إلا لو عايز البوت يرد على نفسه بس
    owners: CFG.owners,            // ✏️ المطورين - من bot.config.json
    settings: {},
    commandsPath: './plugins',     // ⚠️ متغيرش ده إلا لو نقلت فولدر البلجنز
    autoReconnect:        true,    // ⚠️ سيبها true - بتحاول توصل تاني لو النت قطع
    reconnectDelay:       3000,    // ✏️ المدة بين محاولات إعادة الاتصال (ميلي ثانية)
    maxReconnectAttempts: 999999,  // ✏️ عدد محاولات إعادة الاتصال قبل ما يستسلم

    /* ✅ الانضمام للقنوات بيتنفذ هنا بس، بعد ما الاتصال يفتح فعليًا
       ويستقر (event "open" الحقيقي من واتساب) - مش بعد X ثانية من
       بداية تشغيل السكريبت زي الأول. وبيتنفذ مرة واحدة بس لكل
       تشغيل للسيرفر (يعني لو السيرفر عمل ريستارت، هيتنفذ تاني من
       الأول عشان أي قناة اتلغى متابعتها ترجع تتابع تاني)، لكن
       مش في كل إعادة اتصال جوه نفس التشغيلة (زي قطع النت)، عشان
       مايتكررش الضغط على واتساب. */
    onConnected: () => {
        global.__VAELMORE_MAIN_CLIENT = client;
        global.__VAELMORE_MAIN_CONN = client.sock || global.__VAELMORE_MAIN_CONN || null;
        // ⌨️ "يكتب..." قبل أي رسالة (بيتركب على كل اتصال جديد)
        if (client.sock) applyTypingPresence(client.sock);
        // ❤️ تفعيل التفاعل التلقائي مع بوستات القناة - بيتحط في كل
        // مرة الاتصال يفتح فيها (مش مرة واحدة بس زي الانضمام تحت)
        if (client.sock) enableChannelReactions(client.sock, ['❤️', '🔥', '👍']);

        if (global.__autoJoinDoneThisRun) return; // اتعمل قبل كده في نفس التشغيلة، متعملوش تاني
        global.__autoJoinDoneThisRun = true;
        setTimeout(async () => {
            try {
                if (client.sock) {
                    await autoJoinChannel.runAutoJoin(client.sock);
                }
            } catch {}
        }, 8000); // استنى 8 ثواني كمان بعد الاتصال عشان الجلسة تستقر تمام
    },
});

/* =========== رابط البوت الرئيسي لنظام الشكاوى ==========
   كل البوتات الفرعية تستخدم نفس الاتصال الرئيسي لإرسال الشكاوى
   إلى جروب الدعم المحدد داخل plugins/support_complaints.js */
global.__VAELMORE_MAIN_CLIENT = client;
global.__VAELMORE_MAIN_CONN = client.sock || null;

/* =========== ⚠️ منع إيقاف السيرفر - متلمسهاش ==========
   بتمنع الاستضافة إنها توقف السيرفر تلقائي (زي KataBump وقت تجاوز حد الرام) */
process.removeAllListeners('SIGINT');
process.removeAllListeners('SIGTERM');
process.removeAllListeners('SIGHUP');

process.on('SIGINT',  () => console.log('🛡️ SIGINT received - تم تجاهلها، السيرفر فاضل شغال'));
process.on('SIGTERM', () => console.log('🛡️ SIGTERM received - تم تجاهلها، السيرفر فاضل شغال'));
process.on('SIGHUP',  () => console.log('🛡️ SIGHUP received - تم تجاهلها، السيرفر فاضل شغال'));

/* =========== ⚠️ تحميل المطورين الإضافيين - متلمسهاش ========== */
try {
    const extra = global.db?.data?.extraOwners || [];
    if (extra.length) {
        // 🛡️ لازم يبقى معاه jid صحيح (string) وإلا الـ Client بيرفض
        // يشتغل بالكامل (zod validation error على owners[i].jid) - أي
        // مطور اتضاف قبل كده بـ jid فاضي/undefined بيتشال هنا تلقائي
        const cleaned = extra
            .filter(o => o && typeof o.jid === 'string' && o.jid.trim())
            .map(({ secondary, ...rest }) => rest);
        client.config.owners.push(...cleaned);
    }
} catch {}

try {
    client.config.owners = client.config.owners
        .filter(o => o && typeof o.jid === 'string' && o.jid.trim())
        .map(({ secondary, ...rest }) => rest);
} catch {}

client.onGroupEvent(group);
client.onCommandAccess(access);

/* =========== دعم تنفيذ الأوامر في القنوات (Channels) ✏️ ==========
   القنوات مالهاش مفهوم "أدمن الجروب" زي الجروبات العادية، فأي حد
   قادر يبعت رسالة في القناة أصلاً هو أونر/أدمن القناة (لأن واتساب
   نفسه بيمنع غير كده). فبنعتبره isAdmin عشان أوامر { admin: true }
   تشتغل معاه. الأوامر اللي محتاجة { group: true } هتفضل مش شغالة في
   القنوات لأنها بتعتمد على participants/metadata مش موجودة هناك. */
client.onBeforeCommand((m) => {
    // ⌨️ تأكيد إن "يكتب..." مركّبة على السوكيت الحالي (آمنة لو اتركبت قبل كده)
    try { if (client.sock) applyTypingPresence(client.sock); } catch {}
    if (m.chat?.endsWith('@newsletter')) {
        m.isAdmin = true;
    }
});

/* =========== Config ✏️ بيانات البوت اللي بتظهر للمستخدمين ========== */
client.config.info = {
    nameBot:     CFG.botName,                 // ✏️ اسم البوت الظاهر
    nameChannel: CFG.channelName,        // ✏️ اسم قناة البوت
    idChannel:   CFG.channelId,    // ✏️ آيدي القناة (من رابطها)
    urls: {                                           // ✏️ روابط البوت
        repo:    'https://github.com/moreand458-eng/Oracle-bot',
        api:     'https://emam-api.web.id',
        channel: 'https://whatsapp.com/channel/0029VbBbvWcJ3jv1T55BmR0f'
    },
    copyright: { pack: 'سـ ES إ', author: 'ES' },      // ✏️ حقوق الحزمة
    images: [                                          // ✏️ صور عشوائية تظهر في بعض الأوامر
        'https://i.postimg.cc/jqm1vSy9/1779217311694.png',
        'https://i.postimg.cc/PxcS6SvT/d7e8080a5326b0d93e36d85d4a897f8d.jpg',
        'https://i.postimg.cc/nzMdYyrt/ad97fb316f5da69714a7f521673217ac.jpg'
    ]
};

/* =========== Pairing Code - إشعار كود الربط ⚠️ ==========
   بيبعت كود الربط للمطور تلقائي أول ما يظهر، عشان محتاجش تفضل شايل الشاشة */
const OWNER_PHONE = (CFG.owners[0]?.jid || '').split('@')[0].split(':')[0] || BOT_PHONE; // ✏️ الرقم اللي هيستقبل كود الربط

const sendPairingNotification = async (code) => {
    console.log('\n' + '='.repeat(50));
    console.log(`🔑 PAIRING CODE: ${code}`);
    console.log(`📱 FOR NUMBER: ${BOT_PHONE}`);
    console.log('='.repeat(50) + '\n');

    // لو في اتصال شغال، ابعت الكود كرسالة واتساب للمطور كمان
    try {
        if (client.sock?.user) {
            const ownerJid = OWNER_PHONE + '@s.whatsapp.net';
            await client.sock.sendMessage(ownerJid, {
                text: `🔑 *VAELMORE - Pairing Code*\n\n\`${code}\`\n\n📱 ده للرقم: ${BOT_PHONE}\n\nادخل الكود ده في واتساب بسرعة`
            });
        }
    } catch {}
};

const checkPairingCode = setInterval(async () => {
    try {
        const sock = client.sock;
        if (!sock) return;

        sock.ev?.on?.('connection.update', async (update) => {
            if (update?.qr || update?.pairingCode) {
                const code = update.pairingCode || update.qr;
                if (code && code.length > 3) {
                    clearInterval(checkPairingCode);
                    await sendPairingNotification(code);
                }
            }
        });
        clearInterval(checkPairingCode);
    } catch {}
}, 1000);

/* =========== Start ⚠️ ========== */
client.start();
setTimeout(() => { try { if (client.commandSystem) sub(client); } catch {} }, 3000);

/* =========== اشتراك البوت الرئيسي في تحديثات القناة اللحظية ==========
   ⚠️ من غير ده، البوت الرئيسي مش هيستقبل رسائل القناة خالص، فمفيش
   before hook هيتنفذ ومفيش تفاعل هيحصل حتى لو الأوامر شغالة ظاهريًا. */
const waitForMainSock = setInterval(() => {
    if (client.sock?.user) {
        clearInterval(waitForMainSock);
        keepNewsletterSubscribed(
            client.sock,
            client.config.info?.idChannel || '120363422581600030@newsletter',
            'main'
        );
    }
}, 2000);

/* =========== منع النوم/التعليق/التوقف 🛡️ ✏️ الأرقام دي تقدر تظبطها ========== */
keepServerAlive(client, {
    connection: { checkEveryMs: 15000, maxDisconnectedMs: 90000 }, // ✏️ كل قد إيه يفحص الاتصال
    memory:     { checkEveryMs: 60000, maxHeapMB: 700 },           // ✏️ أقصى رام قبل ما يعمل تحذير
    ping:       { everyMs: 240000 },                               // ✏️ كل قد إيه يبعت ping يفضل صاحي
});

/* =========== المكتبات المساعدة ⚠️ متلمسهاش إلا لو عارف بتعمل إيه ==========
   ⚠️ AUTO-JOIN بقت بتتنفذ من جوه onConnected في إعدادات الـ Client فوق،
   مش هنا، عشان تستنى الاتصال يستقر فعليًا قبل ما تبدأ. */

setTimeout(() => {
    try {
        const botDetector = new BotDetector(client, {
            ownerJid:     OWNER_PHONE + '@s.whatsapp.net', // ✏️ رقم إشعارات كشف البوتات
            autoWarn:     true,   // ✏️ true = يحذر تلقائي لو لقى بوت تاني في الجروب
            autoKick:     false,  // ✏️ true = يطرد تلقائي (خطير، سيبها false إلا لو متأكد)
            antiBotMode:  false,  // ✏️ true = وضع حماية أقوى ضد البوتات التانية
            sessionPaths: ['./sessions', './auth_info', './session'], // ⚠️ أماكن ملفات الجلسة
        });
        botDetector.start();
        global._botDetector = botDetector;
    } catch {}
}, 5000);

/* =========== Error Handlers ⚠️ متلمسهاش ==========
   بيتجاهل أخطاء الشبكة العادية (قطع نت مؤقت وغيره) عشان مايوقفش السيرفر لأي حاجة تافهة */
const IGNORE = [
    'rate-overlimit', 'Connection Closed', 'timed out',
    'ECONNRESET', 'ENOTFOUND', 'fetch failed',
    'Socket connection timeout', 'stream errored',
    'Unexpected server response', 'invalid session'
];

process.on('uncaughtException', (e) => {
    if (IGNORE.some(x => e?.message?.includes(x))) return;
    console.error('[uncaughtException]', e?.message);
});

process.on('unhandledRejection', (e) => {
    if (IGNORE.some(x => e?.message?.includes(x))) return;
    console.error('[unhandledRejection]', e?.message);
});

/* =========== ⚠️ منع process.exit - متلمسهاش ========== */
process.exit = (code) => {
    console.log(`🛡️ process.exit(${code}) blocked - server stays alive`);
};
