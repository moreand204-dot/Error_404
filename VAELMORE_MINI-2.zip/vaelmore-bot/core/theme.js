// ════════════════════════════════════════
//  core/theme.js — Compatibility shim
//  الأصل: نظام تنسيق رسائل جاي من بلجنز VAELMORE
//  الملف مكانش موجود جوه بوت VAELMORE، فتم إعادة بناؤه هنا عشان
//  البلجنز المنقولة (اللي بتستورد '../core/theme.js') تشتغل بنفس
//  التوقيع اللي كانت متوقعاه: theme.build([{ type, text/label/value }])
// ════════════════════════════════════════

function line(block) {
    switch (block.type) {
        case 'title':
            return `╭─═⊐‹ ${block.text} ›⊏═─╮`;
        case 'subtitle':
            return `✧ ${block.text}`;
        case 'divider':
            return '┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄';
        case 'spacer':
            return '';
        case 'line':
            return block.text ?? '';
        case 'info':
            return `▸ *${block.label}:* ${block.value}`;
        case 'error':
            return `⚠️ ${block.text}`;
        default:
            return block.text ?? '';
    }
}

export const theme = {
    build(blocks = []) {
        return blocks.map(line).join('\n');
    }
};

export default theme;
