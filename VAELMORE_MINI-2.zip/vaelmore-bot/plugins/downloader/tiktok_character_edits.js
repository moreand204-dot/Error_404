// plugins/downloader/tiktok_character_edits.js
// ✧ VAELMORE BOT - بحث عن اديتات تيك توك لشخصية معينة 🎬
// منقول ومُعاد بناؤه ليستخدم كلاس Carousel بتاع core/NIXCODE.js بدل بناء
// الرسالة يدويًا بـ relayMessage خام (نفس المشكلة اللي حصلت مع قوائم ق1-ق11:
// من غير الـ additionalNodes الخاصة بـ native_flow، واتساب بيسكت ومايبعتش الكارت).

import { generateWAMessageContent } from '@whiskeysockets/baileys'
import { Carousel } from '../../core/NIXCODE.js'
import { theme } from '../../core/theme.js'

let handler = async (m, { conn, args, usedPrefix, command }) => {
  const chat = m.chat

  if (!args[0]) {
    await conn.sendMessage(chat, { react: { text: '❌', key: m.key } })
    return m.reply(theme.build([
      { type: 'title', text: '🎬 بـحـث الاديـتـات' },
      { type: 'subtitle', text: 'بحث اديتات شخصيات من تيك توك' },
      { type: 'divider' },
      { type: 'info', label: '⚔️ الاستخدام', value: `${usedPrefix}${command} <اسم الشخصية>` },
      { type: 'spacer' },
      { type: 'info', label: '📌 أمثلة', value: '' },
      { type: 'line', text: `${usedPrefix}${command} ناروتو` },
      { type: 'line', text: `${usedPrefix}${command} gojo` },
      { type: 'line', text: `${usedPrefix}${command} itachi` }
    ]))
  }

  const characterName = args.join(' ')
  const searchQuery = `${characterName} edit`

  await conn.sendMessage(chat, { react: { text: '🔍', key: m.key } })
  await m.reply(theme.build([
    { type: 'title', text: '🔍 جـاري الـبـحـث' },
    { type: 'info', label: 'عن', value: characterName }
  ]))

  try {
    const videos = await searchTikTok(searchQuery)

    if (!videos || videos.length === 0) {
      await conn.sendMessage(chat, { react: { text: '❌', key: m.key } })
      return m.reply(theme.build([
        { type: 'title', text: '❌ خـطـأ' },
        { type: 'error', text: `ما لقيت اديتات لـ ${characterName}` },
        { type: 'divider' },
        { type: 'line', text: '⚔️ جرب اسم ثاني أو بالإنجليزي' }
      ]))
    }

    let carouselSent = false

    try {
      await sendCarousel(conn, chat, m, characterName, videos)
      carouselSent = true
    } catch (carouselErr) {
      console.log('⚠️ Carousel failed:', carouselErr.message)
    }

    if (!carouselSent) {
      await sendIndividualVideos(conn, chat, m, characterName, videos)
    }

    await conn.sendMessage(chat, { react: { text: '✅', key: m.key } })
  } catch (err) {
    console.error('❌ Edit Search Error:', err)
    await conn.sendMessage(chat, { react: { text: '❌', key: m.key } })
    m.reply(theme.build([
      { type: 'title', text: '❌ خـطـأ' },
      { type: 'error', text: `فشل البحث: ${err.message}` }
    ]))
  }
}

async function searchTikTok(query) {
  try {
    const res = await fetch('https://www.tikwm.com/api/feed/search', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        Accept: 'application/json',
      },
      body: `keywords=${encodeURIComponent(query)}&count=10&cursor=0&HD=1`,
      signal: AbortSignal.timeout(15000)
    })
    const raw = await res.text()
    let json
    try { json = JSON.parse(raw) } catch { return null }

    if (json.code === 0 && json.data?.videos?.length) {
      return json.data.videos.map((v) => ({
        title: v.title || 'اديت 🎬',
        videoUrl: v.hdplay || v.play,
        cover: v.cover || v.origin_cover || '',
        author: v.author?.nickname || 'غير معروف',
        username: v.author?.unique_id || '',
        duration: v.duration || 0,
        likes: v.digg_count || 0,
        comments: v.comment_count || 0,
        shares: v.share_count || 0,
        plays: v.play_count || 0,
      }))
    }
  } catch (e) {
    console.error('tikwm search error:', e.message)
  }
  return null
}

async function sendCarousel(conn, chat, m, characterName, videos) {
  const selectedVideos = videos.slice(0, 5)
  const carousel = new Carousel(conn)
    .setBody(theme.build([
      { type: 'title', text: `🎬 اديـتـات: ${characterName}` },
      { type: 'info', label: '📹 فيديوهات', value: selectedVideos.length.toString() }
    ]))
    .setFooter('❄️ VAELMORE BOT ❄️')

  let added = 0
  for (const video of selectedVideos) {
    try {
      const { videoMessage } = await generateWAMessageContent(
        { video: { url: video.videoUrl } },
        { upload: conn.waUploadToServer }
      )

      carousel.addCard({
        header: {
          title: video.title.length > 50 ? video.title.substring(0, 47) + '...' : video.title,
          hasMediaAttachment: true,
          videoMessage,
        },
        body: { text: `❤️ ${formatNum(video.likes)} | 💬 ${formatNum(video.comments)} | 👁️ ${formatNum(video.plays)}` },
        footer: { text: `👤 ${video.author} | ⏱️ ${video.duration}s` },
      })
      added++
    } catch (err) {
      console.log('Card error:', err.message)
    }
  }

  if (!added) throw new Error('No cards created')

  await carousel.send(chat, { quoted: m })
}

async function sendIndividualVideos(conn, chat, m, characterName, videos) {
  const selectedVideos = videos.slice(0, 3)

  for (let i = 0; i < selectedVideos.length; i++) {
    const video = selectedVideos[i]
    const caption = theme.build([
      { type: 'title', text: `🎬 اديـت ${characterName} (${i + 1}/${selectedVideos.length})` },
      { type: 'divider' },
      { type: 'line', text: video.title.substring(0, 50) },
      { type: 'divider' },
      { type: 'info', label: '👤', value: video.author },
      { type: 'info', label: '⏱️', value: `${video.duration} ثانية` },
      { type: 'info', label: '❤️', value: `${formatNum(video.likes)} | 💬 ${formatNum(video.comments)}` }
    ])

    await conn.sendMessage(chat, {
      video: { url: video.videoUrl },
      caption,
      mimetype: 'video/mp4',
    }, { quoted: m })

    if (i < selectedVideos.length - 1) await delay(2000)
  }
}

function formatNum(n) {
  if (!n) return '0'
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + 'M'
  if (n >= 1_000) return (n / 1_000).toFixed(1) + 'K'
  return n.toString()
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

handler.help = ['ايديت <اسم شخصية>']
handler.tags = ['downloader']
handler.command = /^(ايديت|اديتات|edits)$/i

export default handler
