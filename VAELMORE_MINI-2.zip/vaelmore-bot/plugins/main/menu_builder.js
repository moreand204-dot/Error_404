import { Button } from '../../core/NIXCODE.js';
import { getTimezone } from '../../system/timezone.js';

const NEWSLETTER = { name: '⚜️ 𝐕𝐀𝐄𝐋𝐌𝐎𝐑𝐄 | 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 𝐒𝐲𝐬𝐭𝐞𝐦', jid: '120363422581600030@newsletter' };

const SUPPORT_GROUP_URL = 'https://chat.whatsapp.com/BR3vHZUaLjy1qwhS3ttQpJ?s=cl&p=a&ilr=1';

const DEFAULT_TAGS = ['🔥 الأقوى', '⚡ ترند', '👑 مميز', '💎 مايتفوتش', '🚀 جديد', '✨ الأحلى', '🎯 جربه', '🏆 الأفضل'];
const tagFor = (i) => DEFAULT_TAGS[i % DEFAULT_TAGS.length];

async function safeText(conn, m, text) {
    try {
        return await conn.sendMessage(m.chat, { text }, { quoted: m });
    } catch (e) {
        console.error('[menu_builder] حتى الرسالة النصية فشلت:', e?.message);
        return null;
    }
}

async function sendMainMenu(m, { conn, bot }, { sections, user, totalUsers } = {}) {
  try {
    const mentionId = m.sender;
    const now = new Date();
    // بنستخدم توقيت البوت المحفوظ (.تعيين_التوقيت) مش توقيت السيرفر
    let tz;
    try { tz = getTimezone(); } catch { tz = undefined; }
    const fmt = (opts) => {
        try { return now.toLocaleDateString('ar-EG', { ...opts, timeZone: tz }); }
        catch { return now.toLocaleDateString('ar-EG', opts); }
    };
    const week = fmt({ weekday: 'long' });
    const date = fmt({ year: 'numeric', month: 'long', day: 'numeric' });

    const sectionsText = (sections || [])
        .map(s => `> │┊ ۬.͜ـ📂˖ ⟨${s.title} ➜ ${s.id}☇`)
        .join('\n');

    const bodyText = `╮••─๋︩︪──๋︩︪─═⊐‹﷽›⊏═─๋︩︪──๋︩︪─┈☇
╿↵ مرحــبـا ⌊@${mentionId.split('@')[0]}⌉
── • ◈ • ──
*⌝👿┊𝚅𝙰𝙴𝙻𝙼𝙾𝚁𝙴-𝙱𝙾𝚃┊👿⌞*
╮─ׅ─๋︩︪─┈─๋︩︪─═⊐‹𝐕𝐀𝐄𝐋𝐌𝐎𝐑𝐄 𝐁𝐎𝐓›⊏═┈ ─๋︩︪─ ∙ ∙ ⊰ـ
┤─ׅ─ׅ┈ ─๋︩︪──ׅ─ׅ┈ ─๋︩︪─☇ـ
> │┊ ۬.͜ـ☠️˖ ⟨الاسم: 𝚅𝙰𝙴𝙻𝙼𝙾𝚁𝙴-𝙱𝙾𝚃☇
> │┊ ۬.͜ـ👑˖ ⟨المطورين: 𝐓𝐇𝐄 𝐅𝐎𝐔𝐑 𝐋𝐎𝐑𝐃𝐒☇
> │┊ ۬.͜ـ⌛˖ ⟨اليوم: ${week}☇
> │┊ ۬.͜ـ⏳˖ ⟨التاريخ: ${date}☇
> │┊ ۬.͜ـ🔱˖ ⟨مستواك: ${user?.level ?? '-'}☇
> │┊ ۬.͜ـ👨🏻‍✈️˖ ⟨رتبتك: ${user?.role ?? '-'}☇
> │┊ ۬.͜ـ👥˖ ⟨المستخدمين: ${totalUsers ?? '-'}☇
┤└─ׅ─ׅ┈ ─๋︩︪──ׅ─ׅ┈ ─๋︩︪☇ـ
│ 📂 *الأقسام (ابعت .اوامر ورقم القسم):*
${sectionsText}
╯─ׅ─๋︩︪─═⊐‹𝐕𝐀𝐄𝐋𝐌𝐎𝐑𝐄 𝐁𝐎𝐓›⊏═┈ ─๋︩︪─⊰ـ`;

    // صورة القائمة (JPEG): التصميم + صورة بروفايل اللي كتب الأمر + اسمه + اليوم/التاريخ/المستوى/الرتبة/المستخدمين
    let cardBuffer = null;
    try {
        const { createVaelmoreMenuCard } = await import('../../src/lib/vaelmore-menu-card.js');
        const avatarUrl = await conn
            .profilePictureUrl(mentionId, 'image')
            .catch(() => null);
        cardBuffer = await createVaelmoreMenuCard({
            avatarUrl,
            username: m.pushName || mentionId.split('@')[0],
            day: week,
            date,
            level: user?.level ?? '-',
            role: user?.role ?? '-',
            users: totalUsers ?? '-'
        });
    } catch (e) {
        console.error('[sendMainMenu] فشل توليد صورة القائمة:', e?.message);
        cardBuffer = null;
    }

    // ══ الإرسال الأساسي: كارت تفاعلي = الصورة + القايمة المنسدلة بالأقسام + الزراير (من غير نص) ══
    try {
        const btn = new Button(conn);

        if (cardBuffer) btn.setImage(cardBuffer);

        // القايمة المنسدلة: كل قسم صف، متقسمة كل 10 صفوف في سكشن
        const list = sections || [];
        if (list.length) btn.addSelection('📂 عرض الأقسام');
        for (let i = 0; i < list.length; i += 10) {
            btn.makeSection(list.length > 10 ? `الأقسام (${Math.floor(i / 10) + 1})` : 'الأقسام');
            for (const sec of list.slice(i, i + 10)) {
                btn.makeRow('', sec.title, sec.highlight || 'اضغط لعرض الأوامر', sec.id);
            }
        }

        btn.addReply('🤖 تنصيب بوت', '.تنصيب')
           .addUrl('👥 جروب الدعم', SUPPORT_GROUP_URL);

        return await btn.send(m.chat, { quoted: m });
    } catch (e) {
        console.error('[sendMainMenu] فشل إرسال الكارت التفاعلي:', e?.message);
    }

    // ══ فولباك 1: الصورة لوحدها ══
    if (cardBuffer) {
        try {
            return await conn.sendMessage(m.chat, { image: cardBuffer }, { quoted: m });
        } catch (e2) {
            console.error('[sendMainMenu] فشل إرسال صورة القائمة:', e2?.message);
        }
    }

    // ══ فولباك 2: نص بس ══
    return safeText(conn, m, bodyText);
  } catch (e) {
    console.error('[sendMainMenu] خطأ غير متوقع:', e?.message);
    return safeText(conn, m, '*❌ حصل خطأ في عرض القائمة، جرب تاني.*');
  }
}

async function sendSectionMenu(m, { conn, bot }, { sectionId, sectionTitle, sectionEmoji, rows, backCommand = 'قائمة' } = {}) {
  try {
    const cmdsText = (rows || []).map(r => `> │┊ ۬.͜ـ${sectionEmoji}˖ ⟨${r.cmd} | ${r.desc}☇`).join('\n');
    const bodyText = `╮••─๋︩︪──๋︩︪─═⊐‹﷽›⊏═─๋︩︪──๋︩︪─┈☇
╿↵ مرحــبـا ⌊@${m.sender.split('@')[0]}⌉
── • ◈ • ──
*⌝${sectionEmoji}┊قـائـمـة ${sectionTitle}┊${sectionEmoji}⌞*
╮─ׅ─๋︩︪─┈─๋︩︪─═⊐‹𝐕𝐀𝐄𝐋𝐌𝐎𝐑𝐄 𝐁𝐎𝐓›⊏═┈ ─๋︩︪─ ∙ ∙ ⊰ـ
┤─ׅ─ׅ┈ ─๋︩︪──ׅ─ׅ┈ ─๋︩︪─☇ـ
${cmdsText}
┤└─ׅ─ׅ┈ ─๋︩︪──ׅ─ׅ┈ ─๋︩︪☇ـ
╯─ׅ ─๋︩︪─┈ ─๋︩︪─═⊐‹𝐕𝐀𝐄𝐋𝐌𝐎𝐑𝐄 𝐁𝐎𝐓›⊏═┈ ─๋︩︪─ ∙ ∙ ⊰ـ`;
    try {
        return await conn.sendButton(m.chat, {
            bodyText,
            footerText: bot?.config?.info?.nameBot || '𝐕𝐀𝐄𝐋𝐌𝐎𝐑𝐄 𝐁𝐎𝐓',
            buttons: [
                {
                    name: 'single_select',
                    params: {
                        title: `${sectionEmoji} الأوامر`,
                        sections: [{
                            title: `${sectionTitle}`,
                            rows: (rows || []).map(r => ({
                                title: `${r.cmd}`,
                                description: r.desc || sectionTitle,
                                id: `.${r.cmd}`
                            }))
                        }]
                    }
                },
                { name: 'quick_reply', params: { display_text: '🔙 الرئيسية', id: `.${backCommand}` } }
            ],
            mentions: [m.sender],
            interactiveConfig: { buttons_limits: 2 }
        }, m);
    } catch (e) {
        return safeText(conn, m, bodyText);
    }
  } catch (e) {
    return safeText(conn, m, '*❌ حصل خطأ في عرض القائمة، جرب تاني.*');
  }
}

async function sendDevMenu(m, { conn, bot }, isDev, backCommand = 'قائمة') {
    if (!isDev) return null;
  try {
    const cmds = [
        { cmd: 'بنج', desc: 'اختبار سرعة البوت' },
        { cmd: 'الرام', desc: 'إظهار استخدام الذاكرة' },
        { cmd: 'الايرورات', desc: 'عرض آخر الأخطاء' },
        { cmd: 'اضافه_ملف', desc: 'إضافة ملف أمر جديد' },
        { cmd: 'اضافه_قسم', desc: 'إضافة قسم جديد' },
        { cmd: 'اضافه_مطور', desc: 'إضافة مطور جديد' },
        { cmd: 'حظر', desc: 'حظر مستخدم' },
        { cmd: 'فك_حظر', desc: 'فك حظر مستخدم' },
        { cmd: 'بلوك', desc: 'بلوك رقم مايقدرش ينصب ولا يستخدم البوت' },
        { cmd: 'فك_بلوك', desc: 'فك البلوك عن رقم' },
        { cmd: 'البوتات', desc: 'إدارة البوتات الفرعية' },
        { cmd: 'اذاعه_فرعي', desc: 'إذاعة لجميع المجموعات' },
        { cmd: 'تنظيف', desc: 'حذف الملفات المؤقتة' },
        { cmd: 'لمطور', desc: 'معرّف المستخدم' }
    ];
    const cmdsText = cmds.map(c => `> │┊ ۬.͜ـ👨🏻‍💻˖ ⟨${c.cmd} | ${c.desc}☇`).join('\n');
    const bodyText = `╮••─๋︩︪──๋︩︪─═⊐‹﷽›⊏═─๋︩︪──๋︩︪─┈☇
╿↵ مرحــبـا ⌊@${m.sender.split('@')[0]}⌉
── • ◈ • ──
*⌝👨🏻‍💻┊قـائـمـة المطورين┊👨🏻‍💻⌞*
╮─ׅ─๋︩︪─┈─๋︩︪─═⊐‹𝐕𝐀𝐄𝐋𝐌𝐎𝐑𝐄 𝐁𝐎𝐓›⊏═┈ ─๋︩︪─ ∙ ∙ ⊰ـ
┤─ׅ─ׅ┈ ─๋︩︪──ׅ─ׅ┈ ─๋︩︪─☇ـ
${cmdsText}
┤└─ׅ─ׅ┈ ─๋︩︪──ׅ─ׅ┈ ─๋︩︪☇ـ
╯─ׅ ─๋︩︪─┈ ─๋︩︪─═⊐‹𝐕𝐀𝐄𝐋𝐌𝐎𝐑𝐄 𝐁𝐎𝐓›⊏═┈ ─๋︩︪─ ∙ ∙ ⊰ـ`;
    try {
        return await conn.sendButton(m.chat, {
            bodyText,
            footerText: bot?.config?.info?.nameBot || '𝐕𝐀𝐄𝐋𝐌𝐎𝐑𝐄 𝐁𝐎𝐓',
            buttons: [
                {
                    name: 'single_select',
                    params: {
                        title: 'أوامر المطورين 👨🏻‍💻',
                        sections: [{
                            title: 'قسم المطورين',
                            rows: cmds.map(c => ({
                                title: `${c.cmd}`,
                                description: c.desc,
                                id: `.${c.cmd}`
                            }))
                        }]
                    }
                },
                { name: 'quick_reply', params: { display_text: '🔙 الرئيسية', id: `.${backCommand}` } }
            ],
            mentions: [m.sender],
            interactiveConfig: { buttons_limits: 2 }
        }, m);
    } catch (e) {
        return safeText(conn, m, bodyText);
    }
  } catch (e) {
    return safeText(conn, m, '*❌ حصل خطأ في عرض القائمة، جرب تاني.*');
  }
}

async function sendCategoriesList(m, { conn, bot }, { rows } = {}) {
  try {
    const bodyText = `╮••─๋︩︪──๋︩︪─═⊐‹﷽›⊏═─๋︩︪──๋︩︪─┈☇
╿↵ مرحــبـا ⌊@${m.sender.split('@')[0]}⌉
── • ◈ • ──
*⌝📁┊الأقسام المتاحة┊📁⌞*
╮─ׅ─๋︩︪─┈─๋︩︪─═⊐‹𝐕𝐀𝐄𝐋𝐌𝐎𝐑𝐄 𝐁𝐎𝐓›⊏═┈ ─๋︩︪─ ∙ ∙ ⊰ـ
┤─ׅ─ׅ┈ ─๋︩︪──ׅ─ׅ┈ ─๋︩︪─☇ـ
اختار القسم اللي عايز تشوف أوامره
┤└─ׅ─ׅ┈ ─๋︩︪──ׅ─ׅ┈ ─๋︩︪☇ـ
╯─ׅ ─๋︩︪─┈ ─๋︩︪─═⊐‹𝐕𝐀𝐄𝐋𝐌𝐎𝐑𝐄 𝐁𝐎𝐓›⊏═┈ ─๋︩︪─ ∙ ∙ ⊰ـ`;

    if (!rows || !rows.length) {
        return safeText(conn, m, '*❌ مفيش أقسام متاحة دلوقتي*');
    }

    try {
        return await conn.sendButton(m.chat, {
            bodyText,
            footerText: bot?.config?.info?.nameBot || '𝐕𝐀𝐄𝐋𝐌𝐎𝐑𝐄 𝐁𝐎𝐓',
            buttons: [{
                name: 'single_select',
                params: {
                    title: 'الأقسام 📁',
                    sections: [{ title: 'كل الأقسام', rows }]
                }
            }],
            mentions: [m.sender],
            interactiveConfig: { buttons_limits: 1 }
        }, m);
    } catch (e) {
        return safeText(conn, m, `${bodyText}\n\n${rows.map(r => `> ${r.title} — ${r.id}`).join('\n')}`);
    }
  } catch (e) {
    console.error('[sendCategoriesList] خطأ غير متوقع:', e?.message);
    return safeText(conn, m, '*❌ حصل خطأ في عرض الأقسام، جرب تاني.*');
  }
}

async function sendLinksList(m, { conn, bot }, { rows } = {}) {
  try {
    const bodyText = `╮••─๋︩︪──๋︩︪─═⊐‹﷽›⊏═─๋︩︪──๋︩︪─┈☇
╿↵ مرحــبـا ⌊@${m.sender.split('@')[0]}⌉
── • ◈ • ──
*⌝🔗┊روابط وتواصل┊🔗⌞*
╮─ׅ─๋︩︪─┈─๋︩︪─═⊐‹𝐕𝐀𝐄𝐋𝐌𝐎𝐑𝐄 𝐁𝐎𝐓›⊏═┈ ─๋︩︪─ ∙ ∙ ⊰ـ
┤─ׅ─ׅ┈ ─๋︩︪──ׅ─ׅ┈ ─๋︩︪─☇ـ
كل روابط وخدمات البوت هنا
┤└─ׅ─ׅ┈ ─๋︩︪──ׅ─ׅ┈ ─๋︩︪☇ـ
╯─ׅ ─๋︩︪─┈ ─๋︩︪─═⊐‹𝐕𝐀𝐄𝐋𝐌𝐎𝐑𝐄 𝐁𝐎𝐓›⊏═┈ ─๋︩︪─ ∙ ∙ ⊰ـ`;

    if (!rows || !rows.length) {
        return safeText(conn, m, '*❌ مفيش روابط متاحة دلوقتي*');
    }

    try {
        return await conn.sendButton(m.chat, {
            bodyText,
            footerText: bot?.config?.info?.nameBot || '𝐕𝐀𝐄𝐋𝐌𝐎𝐑𝐄 𝐁𝐎𝐓',
            buttons: [{
                name: 'single_select',
                params: {
                    title: 'الروابط 🔗',
                    sections: [{ title: 'روابط وخدمات', rows }]
                }
            }],
            mentions: [m.sender],
            interactiveConfig: { buttons_limits: 1 }
        }, m);
    } catch (e) {
        return safeText(conn, m, `${bodyText}\n\n${rows.map(r => `> ${r.title} — ${r.description || ''}`).join('\n')}`);
    }
  } catch (e) {
    console.error('[sendLinksList] خطأ غير متوقع:', e?.message);
    return safeText(conn, m, '*❌ حصل خطأ في عرض الروابط، جرب تاني.*');
  }
}

// نفس منطق sendSectionMenu بالظبط - اسم تاني بيستخدمه بعض البلجنز
const sendSectionList = sendSectionMenu;

export { sendMainMenu, sendSectionMenu, sendDevMenu, sendCategoriesList, sendLinksList, sendSectionList };
