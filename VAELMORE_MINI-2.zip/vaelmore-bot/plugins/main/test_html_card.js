// plugins/main/test_html_card.js
// ✧ أمر تجريبي بس - عشان نتأكد إن الفريم بيدعم شكل "HTML Menu Card"
// (ExternalAdReply / Interactive) قبل ما نغير أي حاجة في القايمة
// الأساسية (menu2.js / menu_builder.js). الأمر ده منفصل تماماً ومبيلمسش
// أي كود شغال، فلو فشل مفيش أي تأثير على باقي البوت.

const handler = async (m, { conn }) => {
    // 1) اختبار الكارت (externalAdReply) - صورة + عنوان + وصف زي لينك بريفيو
    try {
        await conn.msgUrl(m.chat, "🧪 *اختبار 1: كارت externalAdReply*", {
            img: "https://files.catbox.moe/hm9iq4.jpg",
            title: "VAELMORE BOT - تجربة",
            body: "لو شايف الكارت ده، يبقى externalAdReply شغال 👌",
            big: true
        }, m);
    } catch (e) {
        await conn.sendMessage(m.chat, {
            text: `❌ فشل اختبار externalAdReply: ${e?.message || e}`
        }, { quoted: m });
    }

    // 2) اختبار الأزرار/القائمة التفاعلية (Interactive / Native Flow)
    try {
        await conn.sendButton(m.chat, {
            imageUrl: "https://files.catbox.moe/hm9iq4.jpg",
            bodyText: "🧪 *اختبار 2: كارت تفاعلي (أزرار + قائمة)*",
            footerText: "VAELMORE BOT - تجربة",
            buttons: [
                {
                    name: "single_select",
                    params: {
                        title: "📂 قائمة تجريبية",
                        sections: [{
                            title: "اختبار",
                            rows: [
                                { title: "خيار 1", description: "وصف الخيار الأول", id: ".بنج" },
                                { title: "خيار 2", description: "وصف الخيار التاني", id: ".الرام" }
                            ]
                        }]
                    }
                },
                { name: "quick_reply", params: { display_text: "🔙 القائمة الأصلية", id: ".اوامر" } }
            ]
        }, m);
    } catch (e) {
        await conn.sendMessage(m.chat, {
            text: `❌ فشل اختبار الأزرار التفاعلية: ${e?.message || e}`
        }, { quoted: m });
    }
};

handler.command = ["تست_كارت", "test_card"];
handler.category = "main";
handler.usage = ["تست_كارت"];
export default handler;
