// ملحوظة: قبل كده الأمر كان بيبعت رسالة نص، يقيس عليها، وبعدين يبعت
// رسالة تانية تقيلة (لينك بريفيو + تحميل صورة من postimg.cc) عشان يبلغ
// بالنتيجة - يعني بنج "سريع" كان بياخد وقت تحميل صورة من النت كل مرة!
// دلوقتي: رسالة واحدة بس، وبنعدلها (edit) بالنتيجة بدل ما نبعت تانية،
// فمفيش تحميل صور ولا طلبات نت زيادة، والقياس بقى حقيقي (وقت الإرسال الفعلي).
const handler = async (m, { conn }) => {
  const start = process.hrtime.bigint();
  const sent = await conn.sendMessage(m.chat, { text: "🏓 بنج..." }, { quoted: m });
  const ping = Number(process.hrtime.bigint() - start) / 1e6;

  const resultText = `⚡ *سرعة البوت:* ${ping.toFixed(2)}ms`;
  try {
    // تعديل نفس الرسالة لو الاتصال بيدعم الـ edit (أسرع وأخف من إرسال رسالة جديدة)
    await conn.sendMessage(m.chat, { text: resultText, edit: sent.key });
  } catch {
    await conn.sendMessage(m.chat, { text: resultText }, { quoted: m });
  }
};

handler.command = ["بنج", "ping"];
handler.category = "info";
handler.usage = ["بنج"];
export default handler;