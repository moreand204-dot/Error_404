// plugins/protection/stats_log.js
// إحصائيات الحماية + سجل آخر المخالفات + أكثر المخالفين
import { getG } from '../../system/protection_engine.js';

const handler = async (m, { command, text }) => {
    if (!m.isGroup) return m.reply('*❌ الأمر ده شغال في الجروبات بس يا معلم*');

    const g = getG(m.chat);

    if (command === 'إحصائيات_الحماية' || command === 'احصائيات_الحماية') {
        const s = g.stats || {};
        return m.reply(
            `📊 *إحصائيات الحماية*\n\n` +
            `🗑️ رسائل اتمسحت: ${s.blocked || 0}\n` +
            `👢 أعضاء اتطردوا: ${s.kicked || 0}\n` +
            `⚠️ إنذارات اتسجلت: ${Object.values(g.warnings || {}).reduce((a, b) => a + b, 0)}`
        );
    }

    if (command === 'سجل_الحماية') {
        const log = g.log || [];
        if (!log.length) return m.reply('*📋 مفيش مخالفات مسجلة لسه*');
        const count = Math.min(10, log.length);
        const lines = log.slice(0, count).map((e, i) =>
            `${i + 1}. @${e.sender.split('@')[0]} - ${e.reason} (${new Date(e.ts).toLocaleTimeString('ar-EG')})`
        );
        return m.reply(`📜 *آخر ${count} مخالفات:*\n\n${lines.join('\n')}`, m.chat, { mentions: log.slice(0, count).map(e => e.sender) });
    }

    if (command === 'أكثر_المخالفين' || command === 'اكثر_المخالفين') {
        const offenders = g.offenders || {};
        const entries = Object.entries(offenders).sort((a, b) => b[1] - a[1]).slice(0, 10);
        if (!entries.length) return m.reply('*📋 مفيش مخالفين مسجلين لسه*');
        const lines = entries.map(([id, count], i) => `${i + 1}. @${id.split('@')[0]} - ${count} مخالفة`);
        return m.reply(`🏆 *أكثر المخالفين:*\n\n${lines.join('\n')}`, m.chat, { mentions: entries.map(([id]) => id) });
    }
};

handler.command  = ['إحصائيات_الحماية', 'احصائيات_الحماية', 'سجل_الحماية', 'أكثر_المخالفين', 'اكثر_المخالفين'];
handler.usage    = ['إحصائيات_الحماية'];
handler.category = 'protection';
export default handler;
