// plugins/protection/levels.js
// مستويات حماية جاهزة: اقتصادية / متوازنة / مشددة
import { canUseAdminCmd } from '../../system/admin_utils.js';
import { adminGuard, notAuthMsg } from '../../system/bot_protection.js';
import { getG } from '../../system/protection_engine.js';

const LEVELS = {
    economic: {
        label: 'اقتصادية 🟢', strictMode: false,
        flags: { antiLink: true, antiSpam: true, antiFlood: false, antiDuplicate: false, antiTag: false, antiFake: false, antiSwear: true, antiCrash: true }
    },
    balanced: {
        label: 'متوازنة 🟡', strictMode: false,
        flags: { antiLink: true, antiLinkInvite: true, antiSpam: true, antiFlood: true, antiDuplicate: true, antiTag: true, antiFake: false, antiSwear: true, antiCrash: true }
    },
    strict: {
        label: 'مشددة 🔴', strictMode: true,
        flags: { antiLink: true, antiLinkInvite: true, antiSpam: true, antiFlood: true, antiDuplicate: true, antiTag: true, antiFake: true, antiSwear: true, antiCrash: true }
    }
};

const ALL_FLAGS = ['antiLink', 'antiLinkInvite', 'antiSpam', 'antiFlood', 'antiDuplicate', 'antiTag', 'antiFake', 'antiSwear', 'antiCrash'];

const handler = async (m, { conn, command, bot }) => {
    if (!m.isGroup) return m.reply('*❌ الأمر ده شغال في الجروبات بس يا معلم*');

    await adminGuard(m, { conn, bot });
    if (!canUseAdminCmd(m, bot, conn)) return m.reply(notAuthMsg());

    const g = getG(m.chat);

    const map = {
        'حماية_اقتصادية': 'economic',
        'حماية_متوازنة': 'balanced',
        'حماية_مشددة': 'strict'
    };
    const levelKey = map[command];
    if (!levelKey) return;

    const level = LEVELS[levelKey];
    for (const f of ALL_FLAGS) {
        if (level.flags[f]) g[f] = true; else delete g[f];
    }
    g.strictMode = level.strictMode || null;
    g.protectionLevel = levelKey;

    const list = ALL_FLAGS.map(f => `${level.flags[f] ? '✅' : '❌'} ${f}`).join('\n');
    return m.reply(`🛡️ *تفعيل حماية ${level.label}*\n\n${list}\n⚡ طرد فوري بدل الإنذار: ${level.strictMode ? '✅' : '❌'}\n\n> تقدر تظبط كل مضاد لوحده بعدين بـ .anti-x تشغيل/ايقاف`);
};

handler.command  = ['حماية_اقتصادية', 'حماية_متوازنة', 'حماية_مشددة'];
handler.usage    = ['حماية_متوازنة'];
handler.admin    = true;
handler.category = 'protection';
export default handler;
