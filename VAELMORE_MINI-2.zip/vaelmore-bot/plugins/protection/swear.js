// plugins/protection/swear.js
// فلتر السب: تشغيل/إيقاف + قاموس مخصص لكل جروب فوق القاموس المدمج
import { canUseAdminCmd } from '../../system/admin_utils.js';
import { adminGuard, notAuthMsg } from '../../system/bot_protection.js';
import { getG, checkSwear } from '../../system/protection_engine.js';

const handler = async (m, { conn, command, text, bot }) => {
    if (!m.isGroup && command !== 'فحص_سب') return m.reply('*❌ الأمر ده شغال في الجروبات بس يا معلم*');

    const g = m.isGroup ? getG(m.chat) : {};
    if (!g.swearExtra) g.swearExtra = [];

    if (command === 'قفل_السب' || command === 'فتح_السب') {
        await adminGuard(m, { conn, bot });
        if (!canUseAdminCmd(m, bot, conn)) return m.reply(notAuthMsg());
        if (command === 'قفل_السب') { g.antiSwear = true; return m.reply('✅ *فلتر السب اتشغل - بيستخدم قاموس كامل + كلماتك الخاصة*'); }
        delete g.antiSwear; return m.reply('✅ *فلتر السب اتقفل*');
    }

    if (command === 'إضافة_سبة' || command === 'اضافة_سبة') {
        await adminGuard(m, { conn, bot });
        if (!canUseAdminCmd(m, bot, conn)) return m.reply(notAuthMsg());
        const word = text?.trim()?.toLowerCase();
        if (!word) return m.reply('*مثال:* .إضافة_سبة كلمة');
        if (g.swearExtra.includes(word)) return m.reply('*الكلمة موجودة أصلاً*');
        g.swearExtra.push(word);
        return m.reply(`✅ *اتضافت لقاموس السب الخاص بالجروب*`);
    }

    if (command === 'حذف_سبة') {
        await adminGuard(m, { conn, bot });
        if (!canUseAdminCmd(m, bot, conn)) return m.reply(notAuthMsg());
        const word = text?.trim()?.toLowerCase();
        if (!word) return m.reply('*مثال:* .حذف_سبة كلمة');
        const before = g.swearExtra.length;
        g.swearExtra = g.swearExtra.filter(w => w !== word);
        if (g.swearExtra.length === before) return m.reply('*الكلمة مش موجودة في القاموس الخاص بيك*');
        return m.reply('✅ *اتمسحت من القاموس الخاص بالجروب*');
    }

    if (command === 'قائمة_السب') {
        if (!g.swearExtra.length) return m.reply('*📋 مفيش كلمات مخصصة مضافة - بس القاموس المدمج شغال*');
        return m.reply(`*🤬 كلمات السب المخصصة للجروب (${g.swearExtra.length}):*\n\n${g.swearExtra.map((w, i) => `${i + 1}. ${w}`).join('\n')}`);
    }

    if (command === 'مسح_قائمة_السب') {
        await adminGuard(m, { conn, bot });
        if (!canUseAdminCmd(m, bot, conn)) return m.reply(notAuthMsg());
        g.swearExtra = [];
        return m.reply('✅ *القاموس المخصص اتمسح (القاموس المدمج لسه شغال)*');
    }

    if (command === 'فحص_سب') {
        if (!text?.trim()) return m.reply('*اكتب النص بعد الأمر عشان تجرّبه*\nمثال: *.فحص_سب النص هنا*');
        const result = checkSwear(text.trim(), g.swearExtra || []);
        return m.reply(result ? `🚫 *النص ده هيتعتبر سب*\nالسبب: ${result.reason}` : '✅ *النص ده مش سب*');
    }
};

handler.command  = ['قفل_السب', 'فتح_السب', 'إضافة_سبة', 'اضافة_سبة', 'حذف_سبة', 'قائمة_السب', 'مسح_قائمة_السب', 'فحص_سب'];
handler.usage    = ['قفل_السب', 'إضافة_سبة كلمة', 'فحص_سب نص للتجربة'];
handler.category = 'protection';
export default handler;
