// plugins/protection/wordfilter.js
// فلتر كلمات مخصص لكل جروب (منفصل عن قاموس السب)
import { canUseAdminCmd } from '../../system/admin_utils.js';
import { adminGuard, notAuthMsg } from '../../system/bot_protection.js';
import { getG } from '../../system/protection_engine.js';

const handler = async (m, { conn, command, text, bot }) => {
    if (!m.isGroup) return m.reply('*❌ الأمر ده شغال في الجروبات بس يا معلم*');

    await adminGuard(m, { conn, bot });
    if (!canUseAdminCmd(m, bot, conn)) return m.reply(notAuthMsg());

    const g = getG(m.chat);
    if (!g.words) g.words = [];

    if (command === 'قفل_الكلمات' || command === 'فتح_الكلمات') {
        if (command === 'قفل_الكلمات') { g.wordFilter = true; return m.reply('✅ *فلتر الكلمات المحظورة اتشغل*'); }
        delete g.wordFilter; return m.reply('✅ *فلتر الكلمات المحظورة اتقفل*');
    }

    if (command === 'إضافة_كلمة' || command === 'اضافة_كلمة') {
        const word = text?.trim()?.toLowerCase();
        if (!word) return m.reply('*مثال:* .إضافة_كلمة كلمة');
        if (g.words.includes(word)) return m.reply('*الكلمة موجودة أصلاً*');
        g.words.push(word);
        return m.reply(`✅ *اتضافت "${word}" لقائمة الكلمات المحظورة*`);
    }

    if (command === 'حذف_كلمة') {
        const word = text?.trim()?.toLowerCase();
        if (!word) return m.reply('*مثال:* .حذف_كلمة كلمة');
        const before = g.words.length;
        g.words = g.words.filter(w => w !== word);
        if (g.words.length === before) return m.reply('*الكلمة مش موجودة*');
        return m.reply(`✅ *"${word}" اتمسحت*`);
    }

    if (command === 'قائمة_الكلمات') {
        if (!g.words.length) return m.reply('*📋 مفيش كلمات محظورة مضافة*');
        return m.reply(`*🚫 الكلمات المحظورة (${g.words.length}):*\n\n${g.words.map((w, i) => `${i + 1}. ${w}`).join('\n')}`);
    }

    if (command === 'مسح_الكلمات') {
        g.words = [];
        return m.reply('✅ *قائمة الكلمات المحظورة اتمسحت*');
    }
};

handler.command  = ['قفل_الكلمات', 'فتح_الكلمات', 'إضافة_كلمة', 'اضافة_كلمة', 'حذف_كلمة', 'قائمة_الكلمات', 'مسح_الكلمات'];
handler.usage    = ['قفل_الكلمات', 'إضافة_كلمة كلمة'];
handler.admin    = true;
handler.category = 'protection';
export default handler;
