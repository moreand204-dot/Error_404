// plugins/protection/countries.js
// إدارة مقدمات الدول المسموح لأرقامها بالانضمام - يشتغل مع مضاد الأرقام الوهمية
import { canUseAdminCmd } from '../../system/admin_utils.js';
import { adminGuard, notAuthMsg } from '../../system/bot_protection.js';
import { getG } from '../../system/protection_engine.js';

const handler = async (m, { conn, command, text, bot }) => {
    if (!m.isGroup) return m.reply('*❌ الأمر ده شغال في الجروبات بس يا معلم*');

    await adminGuard(m, { conn, bot });
    if (!canUseAdminCmd(m, bot, conn)) return m.reply(notAuthMsg());

    const g = getG(m.chat);
    if (!g.allowedCountryCodes) g.allowedCountryCodes = [];

    if (command === 'إضافة_دولة' || command === 'اضافة_دولة') {
        const code = text?.trim()?.replace(/\D/g, '');
        if (!code) return m.reply('*مثال:* .إضافة_دولة 20 (مصر)');
        if (g.allowedCountryCodes.includes(code)) return m.reply('*الكود ده موجود أصلاً*');
        g.allowedCountryCodes.push(code);
        return m.reply(`✅ *اتضاف كود الدولة "${code}" لقائمة المسموح بيها*`);
    }

    if (command === 'حذف_دولة') {
        const code = text?.trim()?.replace(/\D/g, '');
        if (!code) return m.reply('*مثال:* .حذف_دولة 20');
        const before = g.allowedCountryCodes.length;
        g.allowedCountryCodes = g.allowedCountryCodes.filter(c => c !== code);
        if (g.allowedCountryCodes.length === before) return m.reply('*الكود ده مش موجود*');
        return m.reply(`✅ *كود "${code}" اتمسح*`);
    }

    if (command === 'الدول_المسموحة') {
        if (!g.allowedCountryCodes.length) return m.reply('*📋 مفيش تقييد بدول حالياً - كل الأرقام مسموحة*');
        return m.reply(`*🌍 أكواد الدول المسموحة (${g.allowedCountryCodes.length}):*\n\n${g.allowedCountryCodes.map((c, i) => `${i + 1}. +${c}`).join('\n')}\n\n> فعّل *.anti-fake تشغيل* عشان يبدأ التقييد فعلياً`);
    }
};

handler.command  = ['إضافة_دولة', 'اضافة_دولة', 'حذف_دولة', 'الدول_المسموحة'];
handler.usage    = ['إضافة_دولة 20'];
handler.admin    = true;
handler.category = 'protection';
export default handler;
