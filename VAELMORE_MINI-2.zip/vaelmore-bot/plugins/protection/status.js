// plugins/protection/status.js
// ملخص حالة الحماية الشامل - .الحماية
import { getG } from '../../system/protection_engine.js';

const ROWS = [
    ['antiLink', '🔗 مضاد الروابط'], ['antiLinkInvite', '📩 مضاد روابط الدعوة'],
    ['antiSpam', '📢 مضاد الإزعاج'], ['antiFlood', '🌊 مضاد الفيضان'],
    ['antiDuplicate', '🔁 مضاد التكرار'], ['antiTag', '🏷️ مضاد المنشن الجماعي'],
    ['antiFake', '📵 مضاد الأرقام الوهمية'], ['antiSwear', '🤬 مضاد السب'],
    ['wordFilter', '🚫 فلتر الكلمات'], ['antiCrash', '💥 مضاد الكراش'],
    ['antiForward', '↪️ مضاد إعادة التوجيه'],
    ['antiImage', '🖼️ مضاد الصور'], ['antiVideo', '🎬 مضاد الفيديو'],
    ['antiSticker', '🎭 مضاد الستيكر'], ['antiAudio', '🔉 مضاد الصوت'],
];

const handler = async (m) => {
    if (!m.isGroup) return m.reply('*❌ الأمر ده شغال في الجروبات بس يا معلم*');

    const g = getG(m.chat);
    const lines = ROWS.map(([key, label]) => `${g[key] ? '✅' : '❌'} ${label}`);

    const levelLabel = { economic: 'اقتصادية 🟢', balanced: 'متوازنة 🟡', strict: 'مشددة 🔴' }[g.protectionLevel] || 'مخصصة ⚙️';

    return m.reply(
        `❄️ *VAELMORE - حالة الحماية* ❄️\n\n` +
        `المستوى: ${levelLabel}\n` +
        `الوضع المشدد (طرد فوري): ${g.strictMode ? '✅' : '❌'}\n\n` +
        lines.join('\n') +
        `\n\n> *.حماية_اقتصادية* / *.حماية_متوازنة* / *.حماية_مشددة* لتفعيل مستوى جاهز\n` +
        `> *.anti-x تشغيل/ايقاف* لتعديل مضاد واحد لوحده`
    );
};

handler.command  = ['الحماية', 'حماية', 'حالة_الحماية', 'إعدادات_الحماية'];
handler.usage    = ['الحماية'];
handler.category = 'protection';
export default handler;
