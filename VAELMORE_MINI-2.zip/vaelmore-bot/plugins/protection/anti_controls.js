// تحكم في كل المضادات بأمر واحد - مركزي لمحرك الحماية (system/protection_engine.js)
import { canUseAdminCmd } from '../../system/admin_utils.js';
import { adminGuard, notAuthMsg } from '../../system/bot_protection.js';
import { getG } from '../../system/protection_engine.js';

const ANTI_MAP = {
    'anti-link':    'antiLink',    'مضاد_روابط':     'antiLink',
    'anti-invite':  'antiLinkInvite', 'مضاد_دعوات':  'antiLinkInvite',
    'anti-spam':    'antiSpam',    'مضاد_ازعاج':     'antiSpam',
    'anti-flood':   'antiFlood',   'مضاد_فيضان':     'antiFlood',
    'anti-duplicate': 'antiDuplicate', 'مضاد_تكرار':  'antiDuplicate',
    'anti-tag':     'antiTag',     'مضاد_منشن':      'antiTag',
    'anti-fake':    'antiFake',    'مضاد_وهمي':      'antiFake',
    'anti-bot':     'antiBots',    'مضاد_بوتات':     'antiBots',
    'anti-delete':  'antiDelete',  'كشف_المحذوف':    'antiDelete',
    'anti-edit':    'antiEdit',    'كشف_التعديل':    'antiEdit',
    'anti-image':   'antiImage',   'مضاد_صور':       'antiImage',
    'anti-video':   'antiVideo',   'مضاد_فيديو':     'antiVideo',
    'anti-document':'antiDocument','مضاد_ملفات':     'antiDocument',
    'anti-media':   'antiImage',   'مضاد_ميديا':     'antiImage',
    'anti-sticker': 'antiSticker', 'مضاد_ستيكر':     'antiSticker',
    'anti-audio':   'antiAudio',   'مضاد_صوت':       'antiAudio',
    'anti-contact': 'antiContact', 'مضاد_جهات':      'antiContact',
    'anti-location':'antiLocation','مضاد_مواقع':     'antiLocation',
    'anti-poll':    'antiPoll',    'مضاد_استطلاع':   'antiPoll',
    'anti-status-tag': 'antiStatusTag', 'مضاد_تاق_الحالات': 'antiStatusTag',
    'anti-status':  'antiStatusTag', 'مضاد_الحالات':  'antiStatusTag',
    'anti-forward': 'antiForward', 'مضاد_التوجيه':   'antiForward',
    'مضاد_اعادة_التوجيه': 'antiForward', 'مضاد_إعادة_التوجيه': 'antiForward',
    'anti-crash':   'antiCrash',   'مضاد_كراش':      'antiCrash',
    'anti-swear':   'antiSwear',   'مضاد_سب':        'antiSwear',
    'word-filter':  'wordFilter',  'فلتر_كلمات':     'wordFilter',
};

const names = {
    antiLink: '🔗 مضاد الروابط', antiLinkInvite: '📩 مضاد روابط الدعوة',
    antiSpam: '📢 مضاد الإزعاج', antiFlood: '🌊 مضاد الفيضان',
    antiDuplicate: '🔁 مضاد التكرار',
    antiTag: '🏷️ مضاد المنشن الجماعي', antiFake: '📵 مضاد الأرقام الوهمية',
    antiBots: '🤖 مضاد البوتات', antiDelete: '🗑️ كشف الرسائل المحذوفة',
    antiEdit: '✏️ كشف التعديل',
    antiImage: '🖼️ مضاد الصور', antiVideo: '🎬 مضاد الفيديو',
    antiDocument: '📁 مضاد الملفات', antiSticker: '🎭 مضاد الستيكر',
    antiAudio: '🔉 مضاد الصوت', antiContact: '👤 مضاد جهات الاتصال',
    antiLocation: '📍 مضاد المواقع', antiPoll: '📊 مضاد الاستطلاعات',
    antiStatusTag: '📵 مضاد تاق الحالات', antiForward: '↪️ مضاد إعادة التوجيه',
    antiCrash: '💥 مضاد الكراش', antiSwear: '🤬 مضاد السب',
    wordFilter: '🚫 فلتر الكلمات المحظورة',
};

const handler = async (m, { conn, command, text, bot }) => {
    if (!m.isGroup) return m.reply('*❌ الأمر ده شغال في الجروبات بس يا معلم*');

    await adminGuard(m, { conn, bot });
    if (!canUseAdminCmd(m, bot, conn)) return m.reply(notAuthMsg());

    const g = getG(m.chat);
    const key = ANTI_MAP[command];
    if (!key) return;

    const action = text?.trim()?.toLowerCase();
    if (!action) {
        const status = g[key] ? '✅ شغال' : '❌ مقفول';
        return m.reply(`*${names[key] || command}*\nالحالة: ${status}\n\nطريقة الاستخدام:\n*.${command} تشغيل* عشان تشغّله\n*.${command} ايقاف* عشان توقفه`);
    }

    if (action === 'on' || action === 'تشغيل') {
        g[key] = true;
        return m.reply(`✅ *${names[key] || key} اتشغل*`);
    }

    if (action === 'off' || action === 'إيقاف' || action === 'ايقاف') {
        delete g[key];
        return m.reply(`✅ *${names[key] || key} اتقفل*`);
    }

    return m.reply(`*اكتب:* .${command} تشغيل / ايقاف`);
};

handler.command  = Object.keys(ANTI_MAP);
handler.usage    = ['مضاد_روابط تشغيل/ايقاف'];
handler.admin    = true;
handler.category = 'protection';
export default handler;
