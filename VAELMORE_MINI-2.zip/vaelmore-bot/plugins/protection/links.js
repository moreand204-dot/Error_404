// plugins/protection/links.js
// إدارة قائمة الروابط/النطاقات المسموحة لمضاد الروابط
import { canUseAdminCmd } from '../../system/admin_utils.js';
import { adminGuard, notAuthMsg } from '../../system/bot_protection.js';
import { getG, normalizeDomain } from '../../system/protection_engine.js';

const handler = async (m, { conn, command, text, bot }) => {
    if (!m.isGroup) return m.reply('*❌ الأمر ده شغال في الجروبات بس يا معلم*');

    await adminGuard(m, { conn, bot });
    if (!canUseAdminCmd(m, bot, conn)) return m.reply(notAuthMsg());

    const g = getG(m.chat);
    if (!g.allowedLinks) g.allowedLinks = [];

    if (command === 'إضافة_رابط_مسموح' || command === 'اضافة_رابط_مسموح') {
        const domain = normalizeDomain(text?.trim()) || text?.trim();
        if (!domain) return m.reply('*مثال:* .إضافة_رابط_مسموح example.com');
        if (g.allowedLinks.includes(domain)) return m.reply('*النطاق ده موجود أصلاً في القائمة*');
        g.allowedLinks.push(domain);
        return m.reply(`✅ *اتضاف "${domain}" لقائمة النطاقات المسموحة*`);
    }

    if (command === 'حذف_رابط_مسموح') {
        const domain = normalizeDomain(text?.trim()) || text?.trim();
        if (!domain) return m.reply('*مثال:* .حذف_رابط_مسموح example.com');
        const before = g.allowedLinks.length;
        g.allowedLinks = g.allowedLinks.filter(d => d !== domain);
        if (g.allowedLinks.length === before) return m.reply('*النطاق ده مش موجود في القائمة*');
        return m.reply(`✅ *"${domain}" اتمسح من القائمة*`);
    }

    if (command === 'الروابط_المسموحة') {
        if (!g.allowedLinks.length) return m.reply('*📋 مفيش نطاقات مسموحة مضافة لسه*');
        return m.reply(`*🔗 النطاقات المسموحة (${g.allowedLinks.length}):*\n\n${g.allowedLinks.map((d, i) => `${i + 1}. ${d}`).join('\n')}`);
    }

    if (command === 'مسح_الروابط_المسموحة') {
        g.allowedLinks = [];
        return m.reply('✅ *قائمة النطاقات المسموحة اتمسحت بالكامل*');
    }
};

handler.command  = ['إضافة_رابط_مسموح', 'اضافة_رابط_مسموح', 'حذف_رابط_مسموح', 'الروابط_المسموحة', 'مسح_الروابط_المسموحة'];
handler.usage    = ['إضافة_رابط_مسموح example.com'];
handler.admin    = true;
handler.category = 'protection';
export default handler;
