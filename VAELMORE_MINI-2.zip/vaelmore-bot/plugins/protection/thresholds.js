// plugins/protection/thresholds.js
// ضبط حدود الحساسية لمضاد الإزعاج/الفيضان/التكرار/المنشن
import { canUseAdminCmd } from '../../system/admin_utils.js';
import { adminGuard, notAuthMsg } from '../../system/bot_protection.js';
import { getG } from '../../system/protection_engine.js';

const FIELDS = {
    'حد_السبام':   { key: 'spamMax',       label: 'حد رسائل السبام', def: 7 },
    'مدة_السبام':  { key: 'spamWindow',    label: 'مدة نافذة السبام (ثانية)', def: 12 },
    'حد_الفيضان':  { key: 'floodMax',      label: 'حد رسائل الفيضان', def: 14 },
    'مدة_الفيضان': { key: 'floodWindow',   label: 'مدة نافذة الفيضان (ثانية)', def: 18 },
    'حد_التكرار':  { key: 'duplicateMax',  label: 'حد تكرار نفس الرسالة', def: 3 },
    'مدة_التكرار': { key: 'duplicateWindow', label: 'مدة نافذة التكرار (ثانية)', def: 30 },
    'حد_المنشن':   { key: 'mentionMax',    label: 'حد عدد المنشن في رسالة واحدة', def: 5 },
    'حد_التحذيرات': { key: 'maxWarnings',  label: 'حد التحذيرات قبل الطرد', def: 3 },
};

const handler = async (m, { conn, command, text, bot }) => {
    if (!m.isGroup) return m.reply('*❌ الأمر ده شغال في الجروبات بس يا معلم*');

    const g = getG(m.chat);
    const field = FIELDS[command];
    if (!field) return;

    const raw = text?.trim();
    if (!raw) {
        return m.reply(`*${field.label}:* ${g[field.key] || field.def}\n\n*اكتب رقم بعد الأمر عشان تغيّره*\nمثال: *.${command} ${field.def}*`);
    }

    await adminGuard(m, { conn, bot });
    if (!canUseAdminCmd(m, bot, conn)) return m.reply(notAuthMsg());

    const val = parseInt(raw, 10);
    if (Number.isNaN(val) || val < 1) return m.reply('*لازم تكتب رقم صحيح أكبر من صفر*');

    g[field.key] = val;
    return m.reply(`✅ *${field.label} اتغيّر لـ ${val}*`);
};

handler.command  = Object.keys(FIELDS);
handler.usage    = ['حد_السبام 7'];
handler.category = 'protection';
export default handler;
