// plugins/tools/ميتا.js
// ✨ رسائل Meta AI Rich Response المتقدمة — VAELMORE BOT

import { generateWAMessageFromContent, generateMessageIDV2 } from '@whiskeysockets/baileys';

let handler = async (m, { conn }) => {
    try {
        await conn.sendMessage(m.chat, { react: { text: '✨', key: m.key } });

        // 1. إعدادات الـ Meta
        const botMeta = {
            isForwarded: true,
            forwardingScore: 1,
            forwardedAiBotMessageInfo: { 
                botJid: "867051314767696@bot"
            },
            forwardOrigin: 4
        };

        // 2. جلب صورة البروفايل
        let imageUrl = 'https://i.imgur.com/8QKqSJp.jpeg';
        try {
            const botJid = conn.user.id.split(':')[0] + '@s.whatsapp.net';
            imageUrl = await conn.profilePictureUrl(botJid, 'image');
        } catch(e) {}

        // 3. بناء الهيكل
        const richMessage = {
            richResponseMessage: {
                messageType: 1,
                submessages: [
                    {
                        messageType: 2,
                        messageText: "\n✨ *❄️ VAELMORE BOT ❄️* ✨\n",
                    },
                    {
                        messageType: 2,
                        messageText: "\n📊 *1- جدول الأوامر:*\n",
                    },
                    {
                        messageType: 4,
                        tableMetadata: {
                            title: "أوامر VAELMORE",
                            rows: [
                                { items: ["الأمر", "الوصف", "مثال"], isHeading: true },
                                { items: [".اوامر", "القائمة الرئيسية", ".اوامر"], isHeading: false },
                                { items: [".كلود", "ذكاء Claude", ".كلود مرحبا"], isHeading: false },
                                { items: [".كابلود", "ذكاء Copilot", ".كابلود مرحبا"], isHeading: false },
                                { items: [".ترجم", "ترجمة نصوص", ".ترجم en أهلاً"], isHeading: false }
                            ]
                        }
                    },
                    {
                        messageType: 2,
                        messageText: "\n💻 *2- كود JavaScript:*\n",
                    },
                    {
                        messageType: 5,
                        codeMetadata: {
                            codeLanguage: "javascript",
                            codeBlocks: [
                                { highlightType: 2, codeContent: 'const bot = {' },
                                { highlightType: 3, codeContent: '    name: "VAELMORE",' },
                                { highlightType: 4, codeContent: '    unit: "V3"' },
                                { highlightType: 1, codeContent: '};' }
                            ]
                        }
                    },
                    {
                        messageType: 2,
                        messageText: "\n🖼️ *3- صورة البوت:*\n",
                    },
                    {
                        messageType: 3,
                        imageMetadata: {
                            imageUrl: {
                                imagePreviewUrl: imageUrl,
                                imageHighResUrl: imageUrl,
                                sourceUrl: `https://wa.me/${conn.user.id.split(':')[0]}`
                            },
                            imageText: "❄️ VAELMORE BOT",
                            alignment: 2,
                            tapLinkUrl: `https://wa.me/${conn.user.id.split(':')[0]}`
                        }
                    }
                ],
                contextInfo: botMeta
            }
        };

        // 4. إنشاء الرسالة
        const msg = await generateWAMessageFromContent(m.chat, { 
            botForwardedMessage: { message: richMessage } 
        }, {
            senderId: conn.user.id,
            userJid: conn.user.id,
            messageId: generateMessageIDV2(conn.user.id)
        });

        // 5. إرسال الرسالة
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (err) {
        console.error("[Meta]", err);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        
        // رسالة بديلة
        await conn.sendMessage(m.chat, {
            text: "> ❄️ *VAELMORE BOT ❄️*\n> \n> 📊 *جدول الأوامر*\n> ┌─────────┬─────────────┐\n> │ .اوامر  │ القائمة     │\n> │ .كلود   │ الذكاء     │\n> │ .ترجم   │ الترجمة    │\n> └─────────┴─────────────┘"
        }, { quoted: m });
    }
}

handler.usage    = ['متقدم'];
handler.category = 'tools';
handler.command  = ['متقدم', 'ميتا', 'meta', 'rich'];

export default handler;