// نظام الشكاوى - VAELMORE BOT
// يعمل مع البوت الرئيسي وكل البوتات الفرعية من نفس مجلد plugins.

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.join(__dirname, '..', 'system');
const DATA_FILE = path.join(DATA_DIR, 'complaints.json');

const GROUP_CONFIG_FILE = path.join(DATA_DIR, 'complaint_group.json');
const DEFAULT_GROUP_JID = '120363412435368760@g.us';

function loadGroupConfig() {
    try {
        if (fs.existsSync(GROUP_CONFIG_FILE)) {
            const data = JSON.parse(fs.readFileSync(GROUP_CONFIG_FILE, 'utf8'));
            if (data?.jid) return data;
        }
    } catch (e) {
        console.error('[Complaints] group config load error:', e?.message || e);
    }
    return { jid: DEFAULT_GROUP_JID, inviteLink: null };
}

function saveGroupConfig(cfg) {
    try {
        fs.mkdirSync(DATA_DIR, { recursive: true });
        fs.writeFileSync(GROUP_CONFIG_FILE, JSON.stringify(cfg, null, 2), 'utf8');
    } catch (e) {
        console.error('[Complaints] group config save error:', e?.message || e);
    }
}

// بيتقرا من الملف في كل مرة (مش متغير ثابت) عشان أي تحديث من أمر
// .رابط_شكوي يتطبق فورًا من غير ما نحتاج نعمل ريستارت للبوت.
export function getSupportGroupJid() {
    return loadGroupConfig().jid;
}

export function getSupportGroupInfo() {
    return loadGroupConfig();
}

export function setSupportGroupFromInvite(jid, inviteLink) {
    saveGroupConfig({ jid, inviteLink, updatedAt: Date.now() });
}

const COMPLAINT_IMAGE =
    'https://raw.githubusercontent.com/moreand204-dot/photo/main/file_0000000023c082468c56d7bf8ad0d919.png';

const sessions = new Map();
let writeTimer = null;

function loadSessions() {
    try {
        if (!fs.existsSync(DATA_FILE)) return;
        const data = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
        if (!data || typeof data !== 'object') return;

        for (const [key, value] of Object.entries(data)) {
            if (!value || !['writing', 'confirm'].includes(value.status)) continue;
            // الجلسات القديمة جدًا لا نرجعها بعد إعادة تشغيل البوت.
            if (Date.now() - Number(value.updatedAt || 0) > 30 * 60 * 1000) continue;
            sessions.set(key, value);
        }
    } catch (e) {
        console.error('[Complaints] load error:', e?.message || e);
    }
}

function saveSessions() {
    try {
        fs.mkdirSync(DATA_DIR, { recursive: true });
        const data = Object.fromEntries(sessions);
        fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf8');
    } catch (e) {
        console.error('[Complaints] save error:', e?.message || e);
    }
}

function scheduleSave() {
    clearTimeout(writeTimer);
    writeTimer = setTimeout(() => {
        writeTimer = null;
        saveSessions();
    }, 150);
}

loadSessions();

function getBotId(bot, conn) {
    return (
        bot?.config?.phoneNumber ||
        conn?.user?.id?.split(':')[0] ||
        conn?.user?.id ||
        'main'
    );
}

function getSessionKey(m, bot, conn) {
    return `${getBotId(bot, conn)}::${m.chat}::${m.sender}`;
}

function getMessageText(m) {
    if (!m) return '';
    if (typeof m.body === 'string' && m.body.trim()) return m.body.trim();

    const msg = m.message;
    if (!msg) return '';

    return String(
        msg.conversation ||
        msg.extendedTextMessage?.text ||
        msg.imageMessage?.caption ||
        msg.videoMessage?.caption ||
        msg.documentMessage?.caption ||
        ''
    ).trim();
}

function getNumber(jid) {
    if (!jid) return 'غير معروف';
    return String(jid).split('@')[0].split(':')[0];
}

async function getChatDetails(conn, m) {
    const isGroup =
        !!m.isGroup ||
        String(m.chat || '').endsWith('@g.us');

    if (!isGroup) {
        return {
            type: 'خاص',
            name: 'محادثة خاصة',
            jid: m.chat
        };
    }

    try {
        const meta = await conn.groupMetadata(m.chat);
        return {
            type: 'جروب',
            name: meta?.subject || 'جروب بدون اسم',
            jid: m.chat
        };
    } catch {
        return {
            type: 'جروب',
            name: 'جروب غير معروف',
            jid: m.chat
        };
    }
}

function getUserName(m) {
    return (
        m.userName ||
        m.username ||
        m.pushName ||
        m.name ||
        m.senderName ||
        m.notifyName ||
        'غير معروف'
    );
}

function getBotLabel(bot, conn) {
    return (
        bot?.config?.info?.nameBot ||
        bot?.config?.info?.name ||
        conn?.user?.name ||
        'VAELMORE BOT'
    );
}

async function getMainConnection(currentConn) {
    // البوت الرئيسي يسجل نفسه في index.js.
    // لو البلجن اشتغل على الرئيسي نفسه، نستخدم الاتصال الحالي.
    const mainClient = global.__VAELMORE_MAIN_CLIENT;
    const mainConn = mainClient?.sock || global.__VAELMORE_MAIN_CONN;

    if (mainConn?.user) return mainConn;
    if (global.__VAELMORE_MAIN_CONN?.user) return global.__VAELMORE_MAIN_CONN;

    // في حالة البوت الرئيسي نفسه لم يسجل المرجع بعد.
    if (currentConn?.user) {
        const currentId = currentConn.user.id?.split(':')[0];
        const mainId = mainClient?.config?.phoneNumber;
        if (!mainId || currentId === String(mainId)) return currentConn;
    }

    return null;
}

async function sendComplaintToSupport({ conn, bot, m, complaint }) {
    const mainConn = await getMainConnection(conn);
    if (!mainConn) {
        throw new Error('اتصال البوت الرئيسي غير متاح حاليًا');
    }

    const chat = await getChatDetails(conn, m);
    const userName = getUserName(m);
    const userNumber = getNumber(m.sender);
    const botNumber =
        bot?.config?.phoneNumber ||
        mainConn?.user?.id?.split(':')[0] ||
        getNumber(mainConn?.user?.id);

    const sourceBot = getBotLabel(bot, conn);

    const report =
        `╭─〔 🚨 شكوى جديدة 〕─╮\n` +
        `┃\n` +
        `┃ 👤 *المستخدم:* ${userName}\n` +
        `┃ 📱 *الرقم:* ${userNumber}\n` +
        `┃ 🆔 *اليوزر:* ${m.userName || m.username ? '@' + (m.userName || m.username) : 'غير متاح'}\n` +
        `┃ 🤖 *البوت المستقبِل:* ${sourceBot}\n` +
        `┃ 📞 *رقم البوت:* ${botNumber || 'غير معروف'}\n` +
        `┃ 📍 *المصدر:* ${chat.type}\n` +
        `┃ 🏷️ *المحادثة:* ${chat.name}\n` +
        `┃ 🆔 *آيدي المحادثة:* ${chat.jid}\n` +
        `┃\n` +
        `╰────────────────╯\n\n` +
        `📝 *نص الشكوى:*\n${complaint}\n\n` +
        `⏰ *الوقت:* ${new Date().toLocaleString('ar-EG')}`;

    const supportGroupJid = getSupportGroupJid();

    // نحاول نجهّز بيانات الجروب (المشاركين/الأجهزة) قبل الإرسال؛ لو البوت لسه فاتح
    // من ثانية أو الجروب لسه ما اتخزنش في الـ store، إرسال مباشر ممكن يرمي
    // "item-not-found" من Baileys. الـ prefetch ده بيقلل احتمال الخطأ ده كتير.
    try {
        await mainConn.groupMetadata(supportGroupJid);
    } catch (e) {
        console.error('[Complaints] groupMetadata prefetch failed:', e?.message || e);
    }

    const payload = { text: report, mentions: [m.sender] };

    try {
        await mainConn.sendMessage(supportGroupJid, payload);
    } catch (e) {
        console.error('[Complaints] send error, retrying once:', e?.message || e);
        // محاولة تانية بعد مهلة بسيطة تدي وقت لـ Baileys يزامن بيانات الجروب
        await new Promise(r => setTimeout(r, 3000));
        await mainConn.sendMessage(supportGroupJid, payload);
    }

    return { mainConn, chat };
}

async function openComplaint(m, conn, bot) {
    const key = getSessionKey(m, bot, conn);
    const existing = sessions.get(key);

    if (existing) {
        if (existing.status === 'writing') {
            return m.reply(
                '⚠️ *عندك شكوى مفتوحة بالفعل.*\n\n' +
                'اكتب نص الشكوى في رسالة واحدة، أو اكتب *.الغاء_الشكوى* لإلغائها.'
            );
        }

        if (existing.status === 'confirm') {
            return m.reply(
                '⚠️ *الشكوى جاهزة للإرسال بالفعل.*\n\n' +
                'لو متأكد اكتب *.ارسال*، أو *.الغاء_الشكوى* للإلغاء.'
            );
        }
    }

    sessions.set(key, {
        status: 'writing',
        complaint: '',
        chat: m.chat,
        sender: m.sender,
        botId: getBotId(bot, conn),
        createdAt: Date.now(),
        updatedAt: Date.now()
    });
    scheduleSave();

    // رسالة واحدة فقط عند فتح النظام: الصورة + التعليمات.
    return conn.sendMessage(
        m.chat,
        {
            image: { url: COMPLAINT_IMAGE },
            caption:
                `📝 *نظام الشكاوى — VAELMORE BOT*\n\n` +
                `اكتب شكواك كاملة في *رسالة واحدة*.\n\n` +
                `بعد ما تبعتها هعرضها عليك للتأكيد.\n` +
                `لو متأكد منها اكتب:\n` +
                `*.ارسال*\n\n` +
                `ولإلغاء الشكوى اكتب:\n` +
                `*.الغاء_الشكوى*`
        },
        { quoted: m }
    );
}

async function cancelComplaint(m, conn, bot) {
    const key = getSessionKey(m, bot, conn);
    if (!sessions.has(key)) {
        return m.reply('ℹ️ مفيش شكوى مفتوحة ليك دلوقتي.');
    }

    sessions.delete(key);
    scheduleSave();
    return m.reply('✅ تم إلغاء الشكوى.');
}

async function confirmAndSend(m, conn, bot) {
    const key = getSessionKey(m, bot, conn);
    const session = sessions.get(key);

    if (!session) {
        return m.reply(
            '❌ مفيش شكوى جاهزة للإرسال.\nاكتب *.شكوي* لفتح نظام الشكاوى.'
        );
    }

    if (session.status !== 'confirm' || !session.complaint) {
        return m.reply(
            '⚠️ لسه ما استلمتش نص شكوى مكتمل.\nاكتب الشكوى في رسالة واحدة أولًا.'
        );
    }

    try {
        await sendComplaintToSupport({
            conn,
            bot,
            m,
            complaint: session.complaint
        });

        sessions.delete(key);
        scheduleSave();

        return m.reply(
            '✅ *تم إرسال شكواك بنجاح.*\n\n' +
            'وصلت الشكوى لفريق الدعم، شكرًا ليك على التوضيح.'
        );
    } catch (e) {
        console.error('[Complaints] send error:', e?.message || e);
        return m.reply(
            '❌ *تعذر إرسال الشكوى حاليًا.*\n' +
            'حاول مرة ثانية بعد قليل، والشكوى ما زالت محفوظة.'
        );
    }
}

const handler = async (m, { conn, bot, command }) => {
    if (command === 'شكوي' || command === 'شكوى') {
        return openComplaint(m, conn, bot);
    }

    if (command === 'الغاء_الشكوى' || command === 'الغاء_شكوى') {
        return cancelComplaint(m, conn, bot);
    }

    if (command === 'ارسال') {
        return confirmAndSend(m, conn, bot);
    }
};

// التقاط رسالة الشكوى نفسها بدون إرسال رسائل إضافية قبلها.
handler.before = async (m, { conn, bot }) => {
    const key = getSessionKey(m, bot, conn);
    const session = sessions.get(key);
    if (!session) return false;

    const text = getMessageText(m);
    if (!text) return false;

    const normalized = text.replace(/^[.!/#]/, '').trim();

    // الأوامر الخاصة بالنظام تظل تروح للـ handler الأساسي.
    if (
        normalized === 'شكوي' ||
        normalized === 'شكوى' ||
        normalized === 'ارسال' ||
        normalized === 'الغاء_الشكوى' ||
        normalized === 'الغاء_شكوى'
    ) {
        return false;
    }

    if (session.status === 'writing') {
        if (text.length < 3) {
            await m.reply('⚠️ اكتب الشكوى بشكل أوضح في رسالة واحدة.');
            return true;
        }

        session.complaint = text;
        session.status = 'confirm';
        session.updatedAt = Date.now();
        scheduleSave();

        await conn.sendMessage(
            m.chat,
            {
                text:
                    `📋 *تم استلام الشكوى*\n\n` +
                    `${text}\n\n` +
                    `━━━━━━━━━━━━━━\n` +
                    `⚠️ *متأكد من الكلام ده؟*\n\n` +
                    `لو متأكد اكتب: *.ارسال*\n` +
                    `لو عايز تلغيها: *.الغاء_الشكوى*`
            },
            { quoted: m }
        );

        return true;
    }

    // في حالة التأكيد، أي رسالة غير .ارسال لا تغيّر الشكوى.
    if (session.status === 'confirm') {
        await m.reply(
            '⚠️ الشكوى جاهزة للإرسال.\nاكتب *.ارسال* لإرسالها أو *.الغاء_الشكوى* لإلغائها.'
        );
        return true;
    }

    return false;
};

handler.command = [
    'شكوي',
    'شكوى',
    'ارسال',
    'الغاء_الشكوى',
    'الغاء_شكوى'
];
handler.usage = ['شكوي', 'ارسال', 'الغاء_الشكوى'];
handler.category = 'support';

export default handler;
