// reaction_sub.js - إدارة اشتراكات رشق التفاعلات (أوامر المالك فقط)
import {
    addSub, removeSub, getSub, getSubsByUser, getAllSubs,
    parseChannelJid, formatExpiry
} from '../../system/reaction_db.js';

// الإيموجي المسموح بيها كـ reactions في واتساب
const VALID_EMOJIS = ['❤️','🔥','😂','😍','👏','😢','😮','🎉','💯','🙏','👍','💪','⚡','🌹','✅'];

// مدد الاشتراك
const DURATIONS = {
    '1':    { label: 'يوم واحد',   ms: 86400000 },
    '3':    { label: '3 أيام',     ms: 259200000 },
    '7':    { label: 'أسبوع',      ms: 604800000 },
    '14':   { label: 'أسبوعين',    ms: 1209600000 },
    '30':   { label: 'شهر',        ms: 2592000000 },
    'يوم':  { label: 'يوم واحد',   ms: 86400000 },
    'اسبوع':{ label: 'أسبوع',      ms: 604800000 },
    'شهر':  { label: 'شهر',        ms: 2592000000 },
};

// حالة المحادثة (wizard steps) لكل مستخدم
if (!global.__reactionWizard) global.__reactionWizard = {};

const handler = async (m, { conn, command, text, bot }) => {
    const isOwner = bot?.config?.owners?.some(o => m.sender === o.jid || m.sender === o.lid);
    if (!isOwner) return m.reply('*❌ الأمر ده للمطورين بس يا صاحبي*');

    const sender = m.sender;
    const wizard = global.__reactionWizard;

    // ═══════════════════════════════════════
    // أمر: .رشق_جديد — يبدأ wizard إضافة اشتراك
    // ═══════════════════════════════════════
    if (command === 'رشق_جديد' || command === 'reaction_add') {
        wizard[sender] = { step: 'channel' };
        return m.reply(
            `╭─┈─┈─┈─⟞⚡⟝─┈─┈─┈─╮\n` +
            `┃ *إضافة اشتراك رشق تفاعلات*\n` +
            `╰─┈─┈─┈─⟞⚡⟝─┈─┈─┈─╯\n\n` +
            `*الخطوة 1/4*\n` +
            `📢 أرسل رابط القناة أو JID\n\n` +
            `مثال:\nhttps://whatsapp.com/channel/xxx\nأو: 12345@newsletter\n\n` +
            `*.رشق_إلغاء* للإلغاء`
        );
    }

    // ═══════════════════════════════════════
    // إلغاء الـ wizard
    // ═══════════════════════════════════════
    if (command === 'رشق_إلغاء' || command === 'reaction_cancel') {
        delete wizard[sender];
        return m.reply('*✅ العملية اتلغت*');
    }

    // ═══════════════════════════════════════
    // عرض كل الاشتراكات
    // ═══════════════════════════════════════
    if (command === 'رشق_قائمة' || command === 'reaction_list') {
        const subs = getAllSubs();
        if (!subs.length) return m.reply('*📋 مفيش اشتراكات نشطة دلوقتي*');

        const lines = subs.map((s, i) => {
            const remaining = formatExpiry(s.expiresAt);
            return (
                `*${i+1}.* 📢 \`${s.channelJid.split('@')[0]}\`\n` +
                `    👤 ${s.ownerName || s.owner.split('@')[0]}\n` +
                `    ${s.emojis.join(' ')} × ${s.count}\n` +
                `    ⏳ متبقي: ${remaining}\n` +
                `    🆔 \`${s.id}\``
            );
        }).join('\n\n');

        return m.reply(`*🔥 الاشتراكات النشطة (${subs.length}):*\n\n${lines}`);
    }

    // ═══════════════════════════════════════
    // حذف اشتراك: .رشق_حذف <id>
    // ═══════════════════════════════════════
    if (command === 'رشق_حذف' || command === 'reaction_remove') {
        const id = text?.trim();
        if (!id) return m.reply('*اكتب:* .رشق_حذف <id>');
        const sub = getSub(id);
        if (!sub) return m.reply('*❌ الاشتراك ده مش موجود أو منتهي*');
        removeSub(id);
        return m.reply(`*✅ الاشتراك اتمسح:*\n📢 ${sub.channelJid}`);
    }

    // ═══════════════════════════════════════
    // معالجة خطوات الـ wizard
    // ═══════════════════════════════════════
    if (!wizard[sender]) return;

    const step = wizard[sender].step;
    const input = m.body?.trim() || text?.trim() || '';

    // ─ خطوة 1: رابط القناة ─
    if (step === 'channel') {
        const jid = parseChannelJid(input);
        if (!jid) {
            return m.reply(
                `*❌ الرابط غلط*\n\n` +
                `أرسل رابط القناة:\nhttps://whatsapp.com/channel/xxx\nأو: 12345@newsletter`
            );
        }

        // محاولة الانضمام للقناة لو مش منضم
        try {
            await conn.newsletterFollow?.(jid).catch(() => {});
        } catch {}

        wizard[sender].channelJid = jid;
        wizard[sender].step = 'duration';

        return m.reply(
            `*الخطوة 2/4*\n` +
            `⏳ اختار مدة الاشتراك:\n\n` +
            `*1* ← يوم واحد\n` +
            `*3* ← 3 أيام\n` +
            `*7* ← أسبوع\n` +
            `*14* ← أسبوعين\n` +
            `*30* ← شهر\n\n` +
            `أو اكتب عدد الأيام مباشرة (مثل: 15)`
        );
    }

    // ─ خطوة 2: مدة الاشتراك ─
    if (step === 'duration') {
        let durMs;
        let durLabel;

        if (DURATIONS[input]) {
            durMs    = DURATIONS[input].ms;
            durLabel = DURATIONS[input].label;
        } else {
            const days = parseInt(input);
            if (!days || days < 1 || days > 365) {
                return m.reply('*❌ المدة غلط* — اكتب رقم الأيام (1 - 365)');
            }
            durMs    = days * 86400000;
            durLabel = `${days} يوم`;
        }

        wizard[sender].expiresAt = Date.now() + durMs;
        wizard[sender].durLabel  = durLabel;
        wizard[sender].step = 'count';

        return m.reply(
            `*الخطوة 3/4*\n` +
            `🔢 كام تفاعل على كل رسالة؟\n\n` +
            `(رقم من 1 إلى 50)`
        );
    }

    // ─ خطوة 3: عدد التفاعلات ─
    if (step === 'count') {
        const count = parseInt(input);
        if (!count || count < 1 || count > 50) {
            return m.reply('*❌ العدد غلط* — اكتب رقم من 1 لـ 50');
        }

        wizard[sender].count = count;
        wizard[sender].step  = 'emoji';

        return m.reply(
            `*الخطوة 4/4*\n` +
            `😍 أرسل الإيموجي اللي عايز تتفاعل بيها\n` +
            `(ممكن ترسل أكتر من واحد مع بعض)\n\n` +
            `الإيموجي الموجودة:\n${VALID_EMOJIS.join(' ')}\n\n` +
            `مثال: ❤️ 🔥 😍`
        );
    }

    // ─ خطوة 4: الإيموجي ─
    if (step === 'emoji') {
        // استخرج الإيموجي من الرسالة
        const emojiRegex = /\p{Emoji}/gu;
        const found = [...new Set((input.match(emojiRegex) || []))];

        if (!found.length) {
            return m.reply(
                `*❌ مش لاقي إيموجي في رسالتك*\n\n` +
                `ابعت إيموجي من دول:\n${VALID_EMOJIS.join(' ')}`
            );
        }

        // تأكيد وحفظ
        const sub = addSub({
            channelJid: wizard[sender].channelJid,
            owner:      sender,
            ownerName:  m.pushName || sender.split('@')[0],
            expiresAt:  wizard[sender].expiresAt,
            durLabel:   wizard[sender].durLabel,
            count:      wizard[sender].count,
            emojis:     found,
            chat:       m.chat,
        });

        delete wizard[sender];

        return m.reply(
            `╭─┈─┈─┈─⟞✅⟝─┈─┈─┈─╮\n` +
            `┃ *الاشتراك اتضاف!*\n` +
            `╰─┈─┈─┈─⟞✅⟝─┈─┈─┈─╯\n\n` +
            `📢 القناة: \`${sub.channelJid.split('@')[0]}\`\n` +
            `⏳ المدة: ${sub.durLabel}\n` +
            `🔢 التفاعلات: ${sub.count} لكل رسالة\n` +
            `😍 الإيموجي: ${sub.emojis.join(' ')}\n\n` +
            `🆔 \`${sub.id}\`\n\n` +
            `*.رشق_حذف ${sub.id}* عشان توقف الاشتراك`
        );
    }
};

// before hook: استقبال خطوات الـ wizard من أي رسالة
handler.before = async (m, ctx) => {
    if (!m?.sender) return false;
    const w = global.__reactionWizard?.[m.sender];
    if (!w) return false;
    // لو الرسالة أمر (بتبدأ بالبريفيكس)، اتجاهل الـ wizard
    const prefix = ctx?.bot?.config?.prefix || '.';
    if (m.body?.startsWith(prefix)) return false;
    // شغّل الـ handler على الرسالة دي (زي أمر داخلي)
    await handler(m, { ...ctx, command: '__wizard__', text: m.body });
    return true;
};

handler.command  = ['رشق_جديد', 'رشق_قائمة', 'رشق_حذف', 'رشق_إلغاء', 'reaction_add', 'reaction_list', 'reaction_remove', 'reaction_cancel'];
handler.usage    = ['رشق_جديد'];
handler.category = 'owner';
handler.owner    = true;

export default handler;
