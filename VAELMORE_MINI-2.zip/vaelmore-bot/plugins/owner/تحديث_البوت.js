import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import AdmZip from 'adm-zip';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
// جذر المشروع (خطوتين لفوق من plugins/owner)
const ROOT = path.join(__dirname, '..', '..');

const IGNORE_DIRS = new Set(['node_modules', '.git', 'backups', 'session', 'auth', 'auth_info', 'temp_update', '.wwebjs_auth']);
const SESSION_TIMEOUT_MS = 15 * 60 * 1000; // 15 دقيقة

const isOwner = (m, bot) => bot?.config?.owners?.some(o => m.sender === o.jid || m.sender === o.lid);

const resetSession = () => {
    if (global.__botUpdate?.timer) clearTimeout(global.__botUpdate.timer);
    global.__botUpdate = null;
};

// بيدور على كل ملفات المشروع (ما عدا المجلدات المستثناة) ويرجع مسارات نسبية
// (مستخدم بس للملفات المفردة اللي مبعوتة من غير مسار زيب واضح)
const walkAll = (dir, root, out = []) => {
    if (!fs.existsSync(dir)) return out;
    for (const item of fs.readdirSync(dir)) {
        if (IGNORE_DIRS.has(item)) continue;
        const p = path.join(dir, item);
        let stat;
        try { stat = fs.statSync(p); } catch { continue; }
        if (stat.isDirectory()) walkAll(p, root, out);
        else out.push(path.relative(root, p));
    }
    return out;
};

// بيلاقي الملف المستهدف اللي هيتحدث: أول حاجة بنجرب المسار النسبي لو معروف
// ولو مش معروف أو مش موجود، بندور بالاسم بس على مستوى المشروع كله
const findTarget = (relHint, baseName) => {
    if (relHint) {
        const exact = path.join(ROOT, relHint);
        if (fs.existsSync(exact) && fs.statSync(exact).isFile()) {
            return { targetPath: exact, matches: 1 };
        }
    }
    const all = walkAll(ROOT, ROOT);
    const found = all.filter(f => path.basename(f) === baseName);
    if (found.length === 1) return { targetPath: path.join(ROOT, found[0]), matches: 1 };
    if (found.length > 1) return { targetPath: null, matches: found.length, candidates: found };
    return { targetPath: null, matches: 0 };
};

// تأمين مسار جاي من زيب (أو من كابشن): بيمنع الخروج بره جذر المشروع (Zip Slip)
// وبيستبعد أي مسار جوه مجلد محظور (node_modules, session, ...الخ)
const safeZipPath = (entryName) => {
    if (!entryName) return null;
    const rel = entryName.replace(/\\/g, '/').replace(/^\/+/, '');
    const parts = rel.split('/').filter(p => p && p !== '.');
    if (!parts.length) return null;
    if (parts.some(p => p === '..')) return null;      // Zip Slip
    if (IGNORE_DIRS.has(parts[0])) return null;         // مجلد محظور
    const full = path.join(ROOT, ...parts);
    if (full !== ROOT && !full.startsWith(ROOT + path.sep)) return null;
    return full;
};

// شكل شريط التقدم
const PROGRESS_STEPS = [
    { bar: '▮▯▯▯▯▯▯▯▯▯', percent: 10 },
    { bar: '▮▮▯▯▯▯▯▯▯▯', percent: 20 },
    { bar: '▮▮▮▯▯▯▯▯▯▯', percent: 30 },
    { bar: '▮▮▮▮▯▯▯▯▯▯', percent: 40 },
    { bar: '▮▮▮▮▮▯▯▯▯▯', percent: 50 },
    { bar: '▮▮▮▮▮▮▯▯▯▯', percent: 60 },
    { bar: '▮▮▮▮▮▮▮▯▯▯', percent: 70 },
    { bar: '▮▮▮▮▮▮▮▮▯▯', percent: 80 },
    { bar: '▮▮▮▮▮▮▮▮▮▯', percent: 90 },
    { bar: '▮▮▮▮▮▮▮▮▮▮', percent: 100 },
];

const progressText = (step, extra = '') =>
    `📦 *جاري تطبيق التحديث...*\n\n${step.bar}  ${step.percent}%${extra ? `\n${extra}` : ''}`;

// بيحدّث رسالة الشريط، بس مرة واحدة لكل نسبة جديدة (مش كل ملف) عشان مايحصلش سبام تعديل
const makeProgressReporter = (conn, chat, msgKey) => {
    let lastStep = -1;
    return async (doneCount, total) => {
        if (!total) return;
        const percent = Math.floor((doneCount / total) * 100);
        const stepIndex = Math.min(9, Math.max(0, Math.ceil(percent / 10) - 1));
        if (stepIndex <= lastStep && doneCount < total) return;
        lastStep = stepIndex;
        const step = PROGRESS_STEPS[stepIndex];
        try {
            await conn.sendMessage(chat, {
                text: progressText(step, `📄 ${doneCount} / ${total}`),
                edit: msgKey
            });
        } catch { /* لو الـ edit مش مدعوم، منكملش نبعت رسايل كتير عادي */ }
    };
};

const applyUpdate = async (report) => {
    const session = global.__botUpdate;
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backupDir = path.join(ROOT, 'backups', `update-${stamp}`);

    const updated = [];
    const added = [];
    const ambiguous = [];
    const notFound = [];
    const blocked = [];

    // نفكك أي زيب موجود في الملفات المرفوعة لقائمة موحدة من العناصر
    const items = [];
    for (const f of session.files) {
        if (f.isZip) {
            try {
                const zip = new AdmZip(f.buffer);
                for (const entry of zip.getEntries()) {
                    if (entry.isDirectory) continue;
                    items.push({
                        baseName: path.basename(entry.entryName),
                        entryName: entry.entryName,
                        buffer: entry.getData(),
                        fromZip: true
                    });
                }
            } catch (e) {
                notFound.push(`${f.name} (زيب تالف: ${e.message})`);
            }
        } else {
            items.push({ baseName: f.name, relHint: f.relHint || null, buffer: f.buffer, fromZip: false });
        }
    }

    const total = items.length;

    for (let i = 0; i < items.length; i++) {
        const it = items[i];

        if (it.fromZip) {
            // ملف جاي من زيب: مساره جوه الزيب هو مساره الحقيقي في المشروع
            // (سواء ملف قديم هيتحدث أو ملف جديد هيتضاف - في المكان الصح تلقائي)
            const targetPath = safeZipPath(it.entryName);
            if (!targetPath) {
                blocked.push(it.entryName);
            } else {
                const isNew = !fs.existsSync(targetPath);
                try {
                    if (!isNew) {
                        const backupPath = path.join(backupDir, path.relative(ROOT, targetPath));
                        fs.mkdirSync(path.dirname(backupPath), { recursive: true });
                        fs.copyFileSync(targetPath, backupPath);
                    }
                    fs.mkdirSync(path.dirname(targetPath), { recursive: true });
                    fs.writeFileSync(targetPath, it.buffer);
                    (isNew ? added : updated).push(path.relative(ROOT, targetPath));
                } catch (e) {
                    notFound.push(`${it.entryName} (خطأ كتابة: ${e.message})`);
                }
            }
        } else {
            // ملف مفرد (مش من زيب): لو معروف مكانه من قبل نحدثه، لو مش معروف بس
            // عنده مسار في الكابشن نضيفه هناك كملف جديد، غير كده نبلغ إنه مش لاقيله مكان
            const { targetPath, matches, candidates } = findTarget(it.relHint, it.baseName);

            if (matches === 1 && targetPath) {
                try {
                    const backupPath = path.join(backupDir, path.relative(ROOT, targetPath));
                    fs.mkdirSync(path.dirname(backupPath), { recursive: true });
                    if (fs.existsSync(targetPath)) fs.copyFileSync(targetPath, backupPath);
                    fs.mkdirSync(path.dirname(targetPath), { recursive: true });
                    fs.writeFileSync(targetPath, it.buffer);
                    updated.push(path.relative(ROOT, targetPath));
                } catch (e) {
                    notFound.push(`${it.baseName} (خطأ كتابة: ${e.message})`);
                }
            } else if (matches > 1) {
                ambiguous.push(`${it.baseName} ← ${candidates.join(' | ')}`);
            } else if (it.relHint) {
                const newPath = safeZipPath(it.relHint);
                if (!newPath) {
                    blocked.push(it.relHint);
                } else {
                    try {
                        fs.mkdirSync(path.dirname(newPath), { recursive: true });
                        fs.writeFileSync(newPath, it.buffer);
                        added.push(path.relative(ROOT, newPath));
                    } catch (e) {
                        notFound.push(`${it.baseName} (خطأ كتابة: ${e.message})`);
                    }
                }
            } else {
                notFound.push(it.baseName);
            }
        }

        await report(i + 1, total);
    }

    return { updated, added, ambiguous, notFound, blocked, backupDir, total };
};

const handler = async (m, { conn, bot, command, text }) => {
    if (!isOwner(m, bot)) return m.reply('*❌ الأمر ده للمطورين بس يا صاحبي*');

    if (command === 'تحديث_البوت') {
        if (global.__botUpdate?.active) {
            const n = global.__botUpdate.files.length;
            return m.reply(
`📦 *وضع التحديث شغال بالفعل*
├─ الملفات المرفوعة لحد دلوقتي: ${n}
${global.__botUpdate.files.map(f => `│ 📄 ${f.name}`).join('\n')}
└─ ابعت باقي الملفات (أو زيب واحد فيه كل حاجة)، وبعدين اكتب: *حدث*
   (أو *الغاء_التحديث* عشان تلغي)`.trim()
            );
        }

        global.__botUpdate = { active: true, ownerJid: m.sender, files: [], timer: null };
        global.__botUpdate.timer = setTimeout(() => {
            resetSession();
        }, SESSION_TIMEOUT_MS);

        return m.reply(
`📦 *وضع تحديث البوت اتفعّل*
├─ ابعت زيب فيه أي ملفات جديدة أو محدثة بمساراتها زي ما هي
├─ أو ابعت ملفات مفردة (لو الاسم مكرر في أكتر من مكان، اكتب مساره في الكابشن)
├─ أي ملف موجود هيتحدث في مكانه، وأي ملف جديد هيتضاف لوحده في نفس المسار اللي جواه الزيب
├─ لما تخلص ابعت، اكتب: *حدث*
└─ ولو غيرت رأيك اكتب: *الغاء_التحديث*

⏳ الجلسة هتتلغي تلقائي لو فضلت من غير تحديث ${SESSION_TIMEOUT_MS / 60000} دقيقة`.trim()
        );
    }

    if (command === 'الغاء_التحديث') {
        if (!global.__botUpdate?.active) return m.reply('❌ مفيش وضع تحديث شغال أصلاً');
        resetSession();
        return m.reply('✅ اتلغى وضع التحديث، ومفيش حاجة اتغيرت');
    }

    if (command === 'حدث') {
        if (!global.__botUpdate?.active) return m.reply('❌ مفيش وضع تحديث شغال، ابدأ بـ *تحديث_البوت* الأول');
        if (m.sender !== global.__botUpdate.ownerJid) return m.reply('❌ بس اللي بدأ التحديث هو اللي يقدر يطبقه');
        if (!global.__botUpdate.files.length) return m.reply('❌ لسه مبعتش ولا ملف، ابعت الملفات الأول');

        const sent = await conn.sendMessage(m.chat, { text: progressText(PROGRESS_STEPS[0], '📄 0 / ؟') }, { quoted: m });

        let result;
        try {
            const report = makeProgressReporter(conn, m.chat, sent.key);
            result = await applyUpdate(report);
        } catch (e) {
            resetSession();
            return m.reply(`❌ حصل خطأ أثناء التحديث ولسه محدش اتغير كامل:\n\`\`\`${e.message}\`\`\``);
        }

        resetSession();

        // نتأكد إن الشريط بيبان 100% في الآخر مهما كان عدد الملفات
        try {
            await conn.sendMessage(m.chat, {
                text: progressText(PROGRESS_STEPS[9], `📄 ${result.total} / ${result.total}`),
                edit: sent.key
            });
        } catch {}

        let msg = `✅ *خلص التحديث*\n\n`;
        if (result.updated.length) {
            msg += `📄 *الملفات اللي اتحدثت* (${result.updated.length})\n${result.updated.map(f => `│ ✔️ ${f}`).join('\n')}\n\n`;
        }
        if (result.added.length) {
            msg += `🆕 *الملفات الجديدة اللي اتضافت* (${result.added.length})\n${result.added.map(f => `│ ➕ ${f}`).join('\n')}\n\n`;
        }
        if (result.ambiguous.length) {
            msg += `⚠️ *ملفات فيها أكتر من نسخة، محدش اتحدث فيها* (${result.ambiguous.length})\n${result.ambiguous.map(f => `│ ${f}`).join('\n')}\n> ابعتها تاني واكتب مسارها في الكابشن\n\n`;
        }
        if (result.blocked.length) {
            msg += `🚫 *مسارات اتمنعت (محظورة أو غير آمنة)* (${result.blocked.length})\n${result.blocked.map(f => `│ ${f}`).join('\n')}\n\n`;
        }
        if (result.notFound.length) {
            msg += `❔ *ملفات معرفناش نضيفها* (${result.notFound.length})\n${result.notFound.map(f => `│ ${f}`).join('\n')}\n> استخدم *اضافه_ملف* مع تحديد مسارها\n\n`;
        }
        msg += `💾 نسخة احتياطية من كل ملف اتغير محفوظة في:\n\`backups/${path.basename(result.backupDir)}\`\n\n`;

        if (!result.updated.length && !result.added.length) {
            msg += `ℹ️ محصلش أي تحديث فعلي، مفيش داعي للريستارت`;
            return m.reply(msg);
        }

        msg += `♻️ جاري إعادة تشغيل العملية بالكامل عشان الملفات الجديدة تتحمّل...`;
        await m.reply(msg);

        // ⚠️ ملحوظة مهمة: bot.restart() بتقفل السوكيت وتفتحه تاني *جوه نفس عملية
        // النود* - ده مفيد لإعادة الاتصال بواتساب بس مش بيعمل ريلود لملفات الكور
        // (زي index.js وأي ملف كان محمّل من الأول قبل التحديث)، فالتحديث بيتكتب
        // على الدسك لكن التغييرات الفعلية ما بتشتغلش غير بعد ريستارت حقيقي للعملية.
        // عشان كده هنا بنعمل إغلاق نضيف (bot.stop لو موجودة) وبعدين process.exit
        // فعلي، عشان مدير العملية بتاع الاستضافة (زي لوحة OptikLink) يشغّل عملية
        // Node جديدة من الصفر تحمّل كل الملفات المحدثة صح.
        try {
            setTimeout(async () => {
                try { if (typeof bot.stop === 'function') await bot.stop(); } catch {}
                process.exit(0);
            }, 1200);
        } catch {
            m.reply('⚠️ التحديث اتطبق، لكن مقدرتش أعمل إغلاق نضيف للعملية. اعمل *رستارت* من لوحة الاستضافة يدوي.');
        }
    }
};

handler.usage = ['تحديث_البوت', 'حدث', 'الغاء_التحديث'];
handler.category = 'owner';
handler.command = ['تحديث_البوت', 'حدث', 'الغاء_التحديث'];
handler.owner = true;

export default handler;
