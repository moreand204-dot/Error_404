// أمر تفعيل/إيقاف التفاعل التلقائي على قناة محددة فقط
// يشتغل عن طريق الـ reactor الحقيقي الموجود في plugins/auto/channel_auto_react.js
// البوت الرئيسي محتاج يكون متابع/أدمن القناة — البوتات الفرعية مش محتاجة تبقى أدمن عشان تتفاعل

const TARGET_CHANNEL = '120363422581600030@newsletter';

const handler = async (m, { conn, bot, command }) => {
    // تحقق حقيقي من المالك فقط (owners jid/lid + installer)
    const realOwners = [];
    if (bot.config?.owners) {
        bot.config.owners.forEach(o => {
            if (o.jid) realOwners.push(o.jid);
            if (o.lid) realOwners.push(o.lid);
        });
    }
    if (global.installer) realOwners.push(global.installer);

    if (!realOwners.includes(m.sender) && !m.isOwner) {
        return conn.sendMessage(m.chat, {
            text: '❌ الأمر ده للمطورين بس يا صاحبي.'
        });
    }

    if (!global._channelReact) global._channelReact = {};

    if (command === 'تفاعل_تفعيل') {
        global._channelReact[TARGET_CHANNEL] = true;

        // عدد البوتات الفرعية المتصلة فعليًا (للعرض فقط، مش شرط للتفعيل)
        const subCount = (global.subBots?.list?.() || []).filter(b => b.connected).length;

        return conn.sendMessage(m.chat, {
            text: `✅ *التفاعل التلقائي اتشغل*\n\n` +
                  `📌 القناة: ${TARGET_CHANNEL}\n` +
                  `🤖 بوتات فرعية متصلة: ${subCount}\n\n` +
                  `🔄 اكتب .تفاعل_ايقاف عشان توقفه`
        });
    }

    if (command === 'تفاعل_ايقاف') {
        delete global._channelReact[TARGET_CHANNEL];
        return conn.sendMessage(m.chat, {
            text: `🛑 *التفاعل اتقفل*\n📌 القناة: ${TARGET_CHANNEL}`
        });
    }
};

handler.command = ['تفاعل_تفعيل', 'تفاعل_ايقاف'];
handler.category = 'owner';
handler.usage = ['تفاعل_تفعيل', 'تفاعل_ايقاف'];
export default handler;
