import { typingConfig, setTypingEnabled } from '../../libs/typing-presence.js';

const handler = async (m, { conn, args }) => {
    if (!m.isOwner) return m.reply('❌ الأمر ده للمطور بس.');
    const a = (args[0] || '').toLowerCase();

    if (['on', 'تشغيل', 'شغل'].includes(a)) {
        setTypingEnabled(true);
        return m.reply('*✅ "يكتب..." اتشغلت* — البوت هيظهر يكتب قبل أي رسالة.');
    }
    if (['off', 'ايقاف', 'وقف'].includes(a)) {
        setTypingEnabled(false);
        return m.reply('*🔴 "يكتب..." اتوقفت.*');
    }

    const patched = !!conn?.__typingPatched;
    return m.reply(
`*⌨️ حالة "يكتب..."*
> الحالة: ${typingConfig.enabled ? '🟢 شغالة' : '🔴 واقفة'}
> مركّبة على الاتصال ده: ${patched ? '✅ أيوه' : '❌ لأ'}
> أقل مدة: ${typingConfig.minMs}ms — أقصى مدة: ${typingConfig.maxMs}ms

> للتحكم: .كتابة on / .كتابة off`);
};

handler.usage = ['كتابة'];
handler.category = 'owner';
handler.command = ['كتابة', 'typing'];
handler.owner = true;
export default handler;
