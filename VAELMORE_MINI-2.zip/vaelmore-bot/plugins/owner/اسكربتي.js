import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import archiver from 'archiver';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(__dirname, '..', '..'); // plugins/owner -> project root

const isOwner = (m, bot) => bot?.config?.owners?.some(o => m.sender === o.jid || m.sender === o.lid);

const PROGRESS_STEPS = [
    { bar: '▮▯▯▯▯▯▯▯▯▯', percent: 10 },
    { bar: '▮▮▯▯▯▯▯▯▯▯', percent: 20 },
    { bar: '▮▮▮▯▯▯▯▯▯▯', percent: 30 },
    { bar: '▮▮▮▮▯▯▯▯▯▯', percent: 40 },
    { bar: '▮▮▮▮▮▯▯▯▯▯', percent: 50 },
    { bar: '▮▮▮▮▮▮▯▯▯▯', percent: 60 },
    { bar: '▮▮▮▮▮▮▮▯▯▯', percent: 70 },
    { bar: '▮▮▮▮▮▮▮▮▯▯', percent: 80 },
    { bar: '▮▮▮▮▮▮▮▮▮▯', percent: 90 },
    { bar: '▮▮▮▮▮▮▮▮▮▮', percent: 100 },
];

// أقل مسافة زمنية مسموحة بين تعديل وتعديل (بالمللي ثانية)
// عشان منضربش واتساب بطلبات edit كتير في وقت قصير
const EDIT_THROTTLE_MS = 1500;

const handler = async (m, { conn, bot }) => {
    if (!isOwner(m, bot)) return m.reply('*❌ الأمر ده للمطورين بس يا صاحبي*');

    const sent = await conn.sendMessage(m.chat, {
        text: '⏳ بدأ تجهيز ملفات البوت...'
    }, { quoted: m });

    const zipPath = path.join('/tmp', `VAELMORE_BOT_${Date.now()}.zip`);

    try {
        await conn.sendMessage(m.chat, {
            text: `جاري الضغط...\n${PROGRESS_STEPS[0].bar} ${PROGRESS_STEPS[0].percent}%`,
            edit: sent.key
        }).catch(() => {});

        const output = fs.createWriteStream(zipPath);
        // level 6 بدل 9: أسرع بشكل ملحوظ جدًا، والفرق في حجم الملف النهائي ضئيل جدًا
        const archive = archiver('zip', { zlib: { level: 6 } });

        const done = new Promise((resolve, reject) => {
            output.on('close', resolve);
            archive.on('error', reject);
        });

        let lastStepIndex = 0;
        let lastEditTs = 0;
        let editInFlight = false;

        archive.on('progress', (data) => {
            const percentDone = data.entries.total > 0
                ? Math.floor((data.entries.processed / data.entries.total) * 100)
                : 0;
            const stepIndex = PROGRESS_STEPS.findIndex(s => s.percent >= percentDone);
            const targetIndex = stepIndex === -1 ? PROGRESS_STEPS.length - 1 : stepIndex;

            if (targetIndex <= lastStepIndex) return;

            const now = Date.now();
            // منع تراكم عدة طلبات edit في نفس اللحظة (throttle + عدم انتظار الرد قبل إرسال طلب جديد)
            if (editInFlight || now - lastEditTs < EDIT_THROTTLE_MS) return;

            lastStepIndex = targetIndex;
            lastEditTs = now;
            editInFlight = true;

            const step = PROGRESS_STEPS[targetIndex];
            conn.sendMessage(m.chat, {
                text: `جاري الضغط...\n${step.bar} ${step.percent}%`,
                edit: sent.key
            }).catch(() => {}).finally(() => { editInFlight = false; });
        });

        archive.pipe(output);
        archive.glob('**/*', {
            cwd: ROOT,
            ignore: [
                'node_modules/**',
                '.git/**',
                'backups/**',
                'session/**',
                'auth/**',
                'auth_info/**',
                '*.zip',
                '*.log'
            ]
        });

        await archive.finalize();
        await done;

        await conn.sendMessage(m.chat, {
            text: `تم التجهيز ✅\n${PROGRESS_STEPS[9].bar} 100%`,
            edit: sent.key
        }).catch(() => {});

        // بث الملف كـ stream بدل تحميله بالكامل في الذاكرة أولاً
        // كده الرفع بيبدأ فورًا من غير ما ينتظر readFileSync يخلص
        await conn.sendMessage(m.chat, {
            document: { stream: fs.createReadStream(zipPath) },
            mimetype: 'application/zip',
            fileName: 'VAELMORE_BOT.zip'
        }, { quoted: m });

    } catch (e) {
        console.error(e);
        await conn.sendMessage(m.chat, {
            text: '❌ حدث خطأ أثناء تجهيز ملف البوت.',
            edit: sent.key
        }).catch(async () => {
            await conn.sendMessage(m.chat, { text: '❌ حدث خطأ أثناء تجهيز ملف البوت.' }, { quoted: m });
        });
    } finally {
        try { if (fs.existsSync(zipPath)) fs.unlinkSync(zipPath); } catch {}
    }
};

handler.category = 'owner';
handler.usage = ['اسكربتي'];
handler.command = ['اسكربتي'];
handler.owner = true;

export default handler;
