// تحديث جروب استقبال الشكاوى عن طريق لينك دعوة جديد - من غير الدخول على السيرفر.

import { setSupportGroupFromInvite, getSupportGroupInfo } from '../support_complaints.js';

const isOwner = (m, bot) => bot?.config?.owners?.some(o => m.sender === o.jid || m.sender === o.lid);

// sender -> { chat, expiresAt }
const pending = new Map();
const TIMEOUT_MS = 5 * 60 * 1000; // 5 دقايق

function extractInviteCode(text) {
    const match = text?.match(/chat\.whatsapp\.com\/([A-Za-z0-9]+)/i);
    return match ? match[1] : null;
}

const handler = async (m, { conn, bot }) => {
    if (!isOwner(m, bot)) return m.reply('*❌ الأمر ده للمطورين بس يا صاحبي*');

    pending.set(m.sender, { chat: m.chat, expiresAt: Date.now() + TIMEOUT_MS });

    const current = getSupportGroupInfo();
    await m.reply(
        `🔗 *تحديث جروب استقبال الشكاوى*\n\n` +
        `🆔 الجروب الحالي: ${current.jid}\n\n` +
        `ابعت لينك دعوة الجروب الجديد (يبدأ بـ https://chat.whatsapp.com/) في رسالة واحدة، ` +
        `والبوت هينضم للجروب ويحدّث نفسه تلقائيًا.\n\n` +
        `أو اكتب *.الغاء* لإلغاء العملية.`
    );
};

handler.before = async (m, { conn }) => {
    const p = pending.get(m.sender);
    if (!p || p.chat !== m.chat) return;

    if (Date.now() > p.expiresAt) {
        pending.delete(m.sender);
        return;
    }

    if (!m.text) return;

    const normalized = m.text.trim().replace(/^[.!/#]/, '');
    if (normalized === 'الغاء') {
        pending.delete(m.sender);
        await m.reply('✅ اتلغى.');
        return true;
    }

    const code = extractInviteCode(m.text);
    if (!code) {
        await m.reply(
            '⚠️ ده مش لينك جروب واتساب صحيح.\n' +
            'ابعت لينك يبدأ بـ https://chat.whatsapp.com/ أو اكتب *.الغاء* للإلغاء.'
        );
        return true;
    }

    pending.delete(m.sender);

    try {
        const jid = await conn.groupAcceptInvite(code);
        setSupportGroupFromInvite(jid, m.text.trim());
        await m.reply(
            `✅ *تم بنجاح.*\n\n` +
            `انضم البوت للجروب الجديد وبقى هو المستقبِل الرسمي للشكاوى.\n` +
            `🆔 ${jid}`
        );
    } catch (e) {
        console.error('[رابط_شكوي] join error:', e?.message || e);
        await m.reply(
            '❌ حصل خطأ أثناء الانضمام للجروب (ممكن اللينك يكون خلص أو مش صحيح).\n' +
            'جرّب لينك تاني بـ *.رابط_شكوي*.'
        );
    }

    return true;
};

handler.category = 'owner';
handler.usage = ['رابط_شكوي'];
handler.command = ['رابط_شكوي'];
handler.owner = true;

export default handler;
