const handler = async (m, { conn, bot }) => {
  const targetLid = m.mentionedJid?.[0] || m.quoted?.sender;
  if (!targetLid) {
    return m.reply('⚠️ *منشن حد أو رد على رسالته يا معلم* ⚠️');
  }

  let user;
  try {
    const meta = await conn.groupMetadata(m.chat);
    user = meta.participants.find(p => p.id === targetLid);
  } catch {
    return m.reply('*❌ لازم تستخدم الأمر في جروب*');
  }

  if (!user) return m.reply('*❌ مش قادر أجيب بيانات الشخص*');

  // 🛡️ لو واتساب مادّاش الرقم الحقيقي (خصوصية اليوزر نيم)، بنكمل
  // بالـ lid كـ fallback عشان مايتضافش مطور بـ jid فاضي (ده اللي كان
  // بيكسر تشغيل البوت كله - owners[i].jid undefined)
  const rawPhone = user.phoneNumber;
  const jid = (typeof rawPhone === 'string' && rawPhone.includes('@s.whatsapp.net'))
      ? rawPhone
      : String(rawPhone || user.id || '').replace(/@.*/, '') + '@s.whatsapp.net';

  const lid = String(user.id || targetLid);
  const phone = jid.replace('@s.whatsapp.net', '').split(':')[0];

  if (!phone || phone === 'undefined') {
    return m.reply('*❌ مش قادر أجيب رقم الشخص - يمكن حاطط يوزر نيم بدل الرقم، جرب بعد ما يشيله*');
  }

  const alreadyOwner = bot.config.owners.some(o =>
      (o.jid && o.jid === jid) || (o.lid && o.lid === lid)
  );
  if (alreadyOwner) return m.reply('*⚠️ الشخص ده مطور بالفعل*');

  const newOwner = { name: 'Owner', jid, lid, secondary: true };
  bot.config.owners.push(newOwner);

  // احفظ في database عشان يبقى بعد الريستارت
  if (!global.db.data) global.db.data = {};
  if (!global.db.data.extraOwners) global.db.data.extraOwners = [];
  global.db.data.extraOwners = global.db.data.extraOwners.filter(
      o => o.jid !== jid && o.lid !== lid
  );
  global.db.data.extraOwners.push(newOwner);

  try {
      const { writeFileSync, readFileSync, existsSync } = await import('fs');
      const dbPath = './system/database.json';
      let dbData = {};
      if (existsSync(dbPath)) {
          try { dbData = JSON.parse(readFileSync(dbPath, 'utf-8')); } catch {}
      }
      if (!dbData.extraOwners) dbData.extraOwners = [];
      dbData.extraOwners = dbData.extraOwners.filter(o => o.jid !== jid && o.lid !== lid);
      dbData.extraOwners.push(newOwner);
      writeFileSync(dbPath, JSON.stringify(dbData, null, 2));
  } catch {}

  m.reply(`*📂: المطور الجديد اتضاف*\n\n👤 @${phone}\n\n> _اتحفظ - هيفضل بعد الريستارت ✅_`);
};

handler.usage = ["اضافه-مطور"];
handler.category = "owner";
handler.command = ["ضيف_مطور", "اضافه_مطور"];
handler.owner = true;

export default handler;
