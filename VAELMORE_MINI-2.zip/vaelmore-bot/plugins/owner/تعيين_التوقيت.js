import { getTimezone, setTimezone, getLocalNow } from '../../system/timezone.js';

const isOwner = (m, bot) => bot?.config?.owners?.some(o => m.sender === o.jid || m.sender === o.lid);

const handler = async (m, { bot, args }) => {
    if (!isOwner(m, bot)) return m.reply('*❌ الأمر ده للمطورين بس يا صاحبي*');

    const input = args.join(' ').trim();

    if (!input) {
        const tz = getTimezone();
        const { currentTime } = getLocalNow();
        return m.reply(
            `🌍 *التوقيت الحالي:* ${tz}\n🕒 *الساعة دلوقتي حسبه:* ${currentTime}\n\n` +
            `عشان تغيّره، ابعت:\n.تعيين_التوقيت <المنطقة الزمنية>\n\n` +
            `مثال: .تعيين_التوقيت Africa/Cairo\n` +
            `مثال: .تعيين_التوقيت Asia/Riyadh\n` +
            `مثال: .تعيين_التوقيت Africa/Casablanca\n\n` +
            `_(اكتب اسم منطقتك بصيغة IANA - دور على "IANA time zone list" لو مش عارف اسمها بالظبط)_`
        );
    }

    const ok = setTimezone(input);
    if (!ok) {
        return m.reply(`*❌ "${input}" مش منطقة زمنية صحيحة.* اتأكد من الصيغة زي Africa/Cairo مثلًا.`);
    }

    const { currentTime } = getLocalNow();
    await m.reply(
        `✅ *اتظبط التوقيت على:* ${input}\n🕒 الساعة دلوقتي حسبه: ${currentTime}\n\n` +
        `كل جدولة (فتح/قفل الجروبات وغيرها) هتتعامل بالتوقيت ده من دلوقتي.`
    );
};

handler.category = 'owner';
handler.usage = ['تعيين_التوقيت <المنطقة الزمنية>'];
handler.command = ['تعيين_التوقيت', 'التوقيت'];
handler.owner = true;

export default handler;
