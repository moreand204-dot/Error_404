import { readConfig, setReadEnabled } from '../../libs/read-receipt.js';

const handler = async (m, { conn, args }) => {
    if (!m.isOwner) return m.reply('❌ الأمر ده للمطور بس.');
    const a = (args[0] || '').toLowerCase();

    if (['on', 'تشغيل', 'شغل'].includes(a)) {
        setReadEnabled(true);
        return m.reply('*✅ مؤشر القراءة اتشغّل* — البوت هيقرا أي أمر يتبعتله (خاص أو جروب) قبل ما يرد.');
    }
    if (['off', 'ايقاف', 'وقف'].includes(a)) {
        setReadEnabled(false);
        return m.reply('*🔴 مؤشر القراءة اتوقّف.*');
    }

    return m.reply(
`*👁️ حالة مؤشر القراءة*
> الحالة: ${readConfig.enabled ? '🟢 شغّال' : '🔴 واقف'}
> بيقرا: أي أمر في الخاص أو الجروب

> للتحكم: .قراءة on / .قراءة off`);
};

handler.usage = ['قراءة'];
handler.category = 'owner';
handler.command = ['قراءة', 'قراءه', 'readreceipt'];
handler.owner = true;
export default handler;
