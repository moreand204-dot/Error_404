const VAELMORE_CHANNEL = '120363422581600030@newsletter';
const isOwner = (m, bot) => bot?.config?.owners?.some(o => m.sender === o.jid || m.sender === o.lid);

const handler = async (m, { conn, text, bot }) => {
    if (!isOwner(m, bot)) return m.reply('*❌ الأمر ده للمطورين بس يا صاحبي*');
    if (!text?.trim()) return m.reply('*⚠️ اكتب النص اللي عايز تنشره*\n> مثال: `نشر_بالقناة تحديث جديد للبوت! 🎉`');

    try {
        await conn.sendMessage(VAELMORE_CHANNEL, { text: text.trim() });
        return m.reply('*✅ اتنشر في القناة تمام*');
    } catch (e) {
        return m.reply(`*❌ النشر مضربش:* ${e?.message?.slice(0, 80) || 'خطأ مش عارفين ايه هوه'}`);
    }
};

handler.usage    = ['نشر_بالقناة'];
handler.category = 'settings';
handler.command  = ['نشر_بالقناة'];
handler.owner    = true;
handler.cooldown = 3000;

export default handler;
