import { fbdown } from 'btch-downloader';

// استخراج رابط الفيديو من أي شكل استجابة محتمل من المكتبة
// (النسخ المختلفة من المكتبة بترجع أسماء حقول شوية مختلفة)
function extractVideoUrl(data) {
    const d = data?.data || data;
    return d?.HD || d?.hd || d?.Normal_video || d?.sd || d?.SD
        || d?.url_1080p || d?.url_720p || d?.url || d?.video
        || (Array.isArray(d) ? (d[0]?.url || d[0]?.HD || d[0]?.hd || d[0]?.sd) : null);
}

// مهلة زمنية لأي عملية async (المكتبة نفسها أو الفيتش) عشان لو فيسبوك
// علّق بدل ما يرمي إيرور، الأمر مايفضلش عالق للأبد وياكل موارد السيرفر
const withTimeout = (promise, ms, label) => Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error(`${label} استغرق وقت طويل (تايم آوت)`)), ms))
]);

const FB_URL_RE = /facebook\.com|fb\.watch|fb\.me/i;

const handler = async (m, { conn, text, command }) => {
    if (!text) return m.reply(`*❲ ❤️ ❳ ~ حط رابط الفيديو بعد الأمر*\nمثال: .${command} https://www.facebook.com/reel/xxx`);

    const link = text.trim();
    if (!FB_URL_RE.test(link)) {
        return m.reply('*❌ ده مش رابط فيسبوك.* حط رابط فيديو/ريلز حقيقي من فيسبوك أو fb.watch');
    }

    m.react('🌾');

    // محاولتين قبل ما نبلغ بفشل - سكرابر فيسبوك بيفشل أحيانًا بشكل مؤقت بس
    let lastErr;
    for (let attempt = 1; attempt <= 2; attempt++) {
        try {
            const result = await withTimeout(fbdown(link), 25000, 'جلب بيانات الفيديو');
            console.log('[fb.js] رد المكتبة:', JSON.stringify(result)?.slice(0, 300));

            const videoUrl = extractVideoUrl(result);
            if (!videoUrl) throw new Error('المكتبة رجعت رد من غير رابط فيديو - غالبًا فيسبوك غيّر شكل الصفحة أو الفيديو خاص/محذوف');

            const fileRes = await withTimeout(
                fetch(videoUrl, { signal: AbortSignal.timeout(60000) }),
                65000, 'تحميل ملف الفيديو'
            );
            if (!fileRes.ok) throw new Error(`سيرفر الفيديو رد بخطأ ${fileRes.status}`);
            const buffer = Buffer.from(await fileRes.arrayBuffer());
            if (!buffer.length) throw new Error('اتحمل ملف فاضي، جرب تاني');

            await conn.sendMessage(m.chat, {
                video: buffer, caption: `> *اتعمل بواسطة ~ ${m.pushName}*`, mimetype: 'video/mp4'
            }, { quoted: m });
            m.react('✅');
            return;
        } catch (e) {
            lastErr = e;
            if (attempt === 1) await new Promise(r => setTimeout(r, 1500)); // فرصة تانية قبل ما نستسلم
        }
    }

    m.react('❌');
    m.reply(`*❌ التحميل مضربش:* ${lastErr?.message?.slice(0, 150) || 'خطأ غير معروف'}\n\n_لو فضل يفشل مع كل الروابط، يبقى فيسبوك غيّر نظامه وموقع التحميل محتاج تحديث._`);
};

handler.usage = ['فيس'];
handler.category = 'download';
handler.command = /^(فيس|فيسبوك|fb|fbdl|facebook)$/i;
export default handler;
