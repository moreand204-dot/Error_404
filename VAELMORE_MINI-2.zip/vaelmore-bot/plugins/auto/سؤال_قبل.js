// plugins/auto/سؤال_قبل.js
// معالج before المنقول من plugins/سؤال.js
// بوت VAELMORE بيستخدم نمط "before" في plugins/auto/ بدل handler.before

import { theme } from '../../core/theme.js';

export default async function before(m, { conn }) {
    // التأكد إن الرسالة أمر
    if (!m.isCommand) return false;
    if (!m.text) return false;
    
    const cmd = m.text.toLowerCase();
    
    // التحقق إذا كان الأمر يخص اختبار
    if (cmd.startsWith('.جواب_صحيح_') || cmd.startsWith('.جواب_خطأ_')) {
        
        const userQuiz = global.db.users[m.sender]?.currentQuiz;
        if (!userQuiz) {
            await conn.sendMessage(m.chat, { text: theme.build([
                { type: 'title', text: '❄️ VAELMORE: "لا توجد مهمة نشطة"' },
                { type: 'line', text: 'استخدم .سؤال_خيارات لبدء مهمة جديدة' }
            ]) }, { quoted: m });
            return true;
        }
        
        const isCorrect = cmd === `.${userQuiz.correctCmd}`;
        
        if (isCorrect) {
            if (!global.db.users[m.sender].points) {
                global.db.users[m.sender].points = 0;
            }
            global.db.users[m.sender].points += 100;
            
            await conn.sendMessage(m.chat, { text: theme.build([
                { type: 'title', text: '✅ VAELMORE: "إجابة صحيحة"' },
                { type: 'line', text: '🎉 أحسنت أيها المحارب! +100 نقطة' },
                { type: 'divider' },
                { type: 'info', label: 'الإجابة الصحيحة', value: userQuiz.correctAnswer },
                { type: 'info', label: 'نقاطك', value: `${global.db.users[m.sender].points} نقطة` }
            ]) }, { quoted: m });
        } else {
            await conn.sendMessage(m.chat, { text: theme.build([
                { type: 'title', text: '❌ VAELMORE: "إجابة خاطئة"' },
                { type: 'line', text: 'للأسف إجابتك غير صحيحة' },
                { type: 'divider' },
                { type: 'info', label: 'الإجابة الصحيحة', value: userQuiz.correctAnswer }
            ]) }, { quoted: m });
        }
        
        // حذف السؤال
        delete global.db.users[m.sender].currentQuiz;
        return true;
    }
    
    return false;
}
