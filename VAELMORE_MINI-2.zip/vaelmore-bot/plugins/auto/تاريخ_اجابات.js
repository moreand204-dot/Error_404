// plugins/auto/تاريخ_اجابات.js
// 🔥 معالج ضغطات أزرار الإجابة في لعبة التاريخ (plugins/تاريخ_لعبة.js)
// بوت VAELMORE بيستخدم نمط "before" في plugins/auto/ بدل handler.before

import { theme } from '../../core/theme.js';

export default async function before(m, { conn }) {
    if (m.fromMe || !m.text) return false;

    const cmd = m.text.toLowerCase();
    if (!cmd.startsWith('.تاريخ_صحيح_') && !cmd.startsWith('.تاريخ_خطأ_')) return false;

    const userHistory = global.db.users[m.sender]?.currentHistory;
    if (!userHistory) {
        await conn.sendMessage(m.chat, {
            text: theme.build([
                { type: 'title', text: '❌ خـطـأ' },
                { type: 'subtitle', text: 'لا يوجد سؤال نشط!' },
                { type: 'divider' },
                { type: 'line', text: '⚔️ استخدم .تاريخ لبدء اللعبة' }
            ])
        }, { quoted: m });
        return true;
    }

    const isCorrect = cmd === `.${userHistory.correctCmd}`;

    if (isCorrect) {
        if (!global.db.users[m.sender].points) global.db.users[m.sender].points = 0;
        global.db.users[m.sender].points += 100;

        await conn.sendMessage(m.chat, {
            text: theme.build([
                { type: 'title', text: '✅ إجـابـة صـحـيـحـة' },
                { type: 'subtitle', text: '🎉 أحسنت! +100 نقطة' },
                { type: 'divider' },
                { type: 'info', label: 'الإجابة الصحيحة', value: userHistory.correctAnswer },
                { type: 'info', label: 'نقاطك', value: `${global.db.users[m.sender].points} نقطة` }
            ])
        }, { quoted: m });
    } else {
        await conn.sendMessage(m.chat, {
            text: theme.build([
                { type: 'title', text: '❌ إجـابـة خـاطـئـة' },
                { type: 'subtitle', text: 'للأسف إجابتك غير صحيحة' },
                { type: 'divider' },
                { type: 'info', label: 'الإجابة الصحيحة', value: userHistory.correctAnswer }
            ])
        }, { quoted: m });
    }

    delete global.db.users[m.sender].currentHistory;
    return true;
}
