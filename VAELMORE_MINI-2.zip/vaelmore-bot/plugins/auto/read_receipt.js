// plugins/auto/read_receipt.js
// ✧ مؤشر القراءة: أي أمر يتبعت للبوت (خاص أو جروب) البوت يقراه قبل ما يرد.
// الكلام العادي (اللي مش أمر) مبيتقراش خالص.
import { markCommandRead } from '../../libs/read-receipt.js';

export default async function before(m, { conn }) {
    // بنعمل قراءة للأمر بس وبنكمّل عادي (return false = كمّل تنفيذ الأمر)
    await markCommandRead(conn, m);
    return false;
}
