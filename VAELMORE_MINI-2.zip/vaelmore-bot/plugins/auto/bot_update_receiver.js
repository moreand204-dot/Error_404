const isOwner = (sender, bot) =>
    bot?.config?.owners?.some(o => sender === o.jid || sender === o.lid);

const ZIP_EXT = /\.zip$/i;

export default async function before(m, { conn, bot }) {
    const session = global.__botUpdate;
    if (!session?.active) return false;
    if (m.sender !== session.ownerJid) return false;
    if (!isOwner(m.sender, bot)) return false;

    if (m.mtype !== 'documentMessage') return false;

    const fileName = m.msg?.fileName || m.msg?.title || `file_${Date.now()}`;
    const caption = (m.msg?.caption || '').trim();
    const isZip = ZIP_EXT.test(fileName) || m.msg?.mimetype === 'application/zip' || m.msg?.mimetype === 'application/x-zip-compressed';

    try {
        const buffer = await m.download();
        if (!buffer) throw new Error('تنزيل فاضي');

        session.files.push({
            name: fileName,
            buffer,
            isZip,
            relHint: caption || null
        });

        // نجدد المؤقت كل ما ملف جديد يوصل
        if (session.timer) clearTimeout(session.timer);
        session.timer = setTimeout(() => { global.__botUpdate = null; }, 15 * 60 * 1000);

        await conn.sendMessage(m.chat, {
            text: `📄 اتضاف: ${fileName}${isZip ? ' (زيب)' : ''}\n📦 العدد الحالي: ${session.files.length}\n\nابعت المزيد، أو اكتب *حدث* عشان تطبق`
        }, { quoted: m });
    } catch (e) {
        await conn.sendMessage(m.chat, {
            text: `❌ مقدرتش أنزل الملف: ${fileName}\n${e.message}`
        }, { quoted: m });
    }

    return true;
}
