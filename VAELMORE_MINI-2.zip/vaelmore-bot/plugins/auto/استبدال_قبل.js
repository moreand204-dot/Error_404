// plugins/auto/استبدال_قبل.js
// 🔄 معالج تأكيد/إلغاء أمر الاستبدال الجماعي (plugins/استبدال.js)
// بوت VAELMORE بيستخدم نمط "before" في plugins/auto/ بدل handler.before

import fs from 'fs';

export default async function before(m, { conn }) {
    let text = m.text || '';
    if (!text.startsWith('.replace_confirm ') && !text.startsWith('.replace_cancel ')) return false;
    if (!m.isOwner) return false;

    if (text.startsWith('.replace_confirm ')) {
        let sessionId = text.replace('.replace_confirm ', '').trim();
        if (!sessionId) return false;

        let data = global.replaceData?.[sessionId];
        if (!data) {
            await conn.sendMessage(m.chat, { text: '⏰ انتهت صلاحية الجلسة' }, { quoted: m });
            return true;
        }

        let { oldWord, newWord, foundFiles } = data;

        let changedCount = 0;
        for (let filePath of foundFiles) {
            try {
                let content = fs.readFileSync(filePath, 'utf8');
                if (content.includes(oldWord)) {
                    let newContent = content.replace(new RegExp(oldWord.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'), newWord);
                    fs.writeFileSync(filePath, newContent);
                    changedCount++;
                }
            } catch {}
        }

        delete global.replaceData[sessionId];

        await conn.sendMessage(m.chat, {
            text: `✅ *تم الاستبدال*\n\n🔍 *${oldWord}* ➜ *${newWord}*\n📁 *عدد الملفات:* ${changedCount}/${foundFiles.length}`
        }, { quoted: m });
        return true;
    }

    if (text.startsWith('.replace_cancel ')) {
        let sessionId = text.replace('.replace_cancel ', '').trim();
        if (!sessionId) return false;

        if (global.replaceData?.[sessionId]) {
            delete global.replaceData[sessionId];
        }

        await conn.sendMessage(m.chat, { text: '❌ *تم إلغاء الاستبدال*' }, { quoted: m });
        return true;
    }

    return false;
}
