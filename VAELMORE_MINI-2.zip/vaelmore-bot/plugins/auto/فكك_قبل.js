// plugins/auto/فكك_قبل.js
// معالج before المنقول من plugins/فكك.js
// بوت VAELMORE بيستخدم نمط "before" في plugins/auto/ بدل handler.before

import { theme } from '../../core/theme.js';

export default async function before(m, { conn }) {
    let id = m.chat;
    if (!conn.tekateki || !conn.tekateki[id]) return false;
    if (!m.text) return false;
    
    let game = conn.tekateki[id];
    let json = game[1];
    let poin = game[2];
    
    // مقارنة الإجابة
    let userAnswer = m.text.trim().toLowerCase();
    let correctAnswer = json.response.toLowerCase();
    
    if (userAnswer === correctAnswer || userAnswer.includes(correctAnswer) || correctAnswer.includes(userAnswer)) {
        
        // إضافة نقاط
        if (!global.db.users[m.sender].points) {
            global.db.users[m.sender].points = 0;
        }
        global.db.users[m.sender].points += poin;
        
        await conn.sendMessage(m.chat, { text: theme.build([
            { type: 'title', text: '✅ VAELMORE: "إجابة صحيحة"' },
            { type: 'line', text: `🎉 أحسنت أيها المحارب! +${poin} نقطة` },
            { type: 'divider' },
            { type: 'info', label: 'الإجابة', value: json.response },
            { type: 'info', label: 'نقاطك', value: `${global.db.users[m.sender].points} نقطة` }
        ]) }, { quoted: m });
        
        clearTimeout(game[3]);
        delete conn.tekateki[id];
        return true;
    }
    
    return false;
}
