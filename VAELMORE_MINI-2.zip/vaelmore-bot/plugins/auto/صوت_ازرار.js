// plugins/auto/صوت_ازرار.js
// 🎯 معالج ضغطات أزرار أمر المؤثرات الصوتية (plugins/tools/صوت.js)
// بوت VAELMORE بيستخدم نمط "before" في plugins/auto/ بدل handler.all

import { tempResults, downloadAudio, waitForSend } from '../tools/صوت.js';

export default async function before(m, { conn }) {
    if (m.fromMe) return false;

    let buttonId = null;

    if (m.message?.buttonsResponseMessage) {
        buttonId = m.message.buttonsResponseMessage.selectedButtonId;
    } else if (m.message?.templateButtonReplyMessage) {
        buttonId = m.message.templateButtonReplyMessage.selectedId;
    } else if (m.message?.interactiveResponseMessage?.nativeFlowResponseMessage) {
        buttonId = m.message.interactiveResponseMessage.nativeFlowResponseMessage.id;
    } else if (m.text && m.text.startsWith('sound_')) {
        buttonId = m.text;
    }

    if (!buttonId || !buttonId.startsWith('sound_')) return false;

    const index = parseInt(buttonId.split('_')[1]);
    if (isNaN(index)) return false;

    const userKey = `${m.chat}_${m.sender}`;
    const userResults = tempResults.get(userKey);

    if (!userResults || !userResults.results[index]) {
        await m.reply('❌ *انتهت صلاحية البحث، استخدم .مؤثر مرة أخرى*');
        return true;
    }

    const sound = userResults.results[index];
    tempResults.delete(userKey);

    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } }).catch(() => {});
    await m.reply(`⏳ *جاري تحميل:* ${sound.title}...`);

    try {
        const audioBuffer = await downloadAudio(sound.url);
        await waitForSend();

        await conn.sendMessage(m.chat, {
            audio: audioBuffer,
            mimetype: 'audio/mpeg',
            fileName: `${sound.title}.mp3`,
            caption: `> 🎵 *${sound.title}*\n> ⚡ VAELMORE BOT`
        }, { quoted: m });

        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } }).catch(() => {});
    } catch (err) {
        console.error('[صوت_ازرار]', err);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        await m.reply(`❌ *فشل:* ${err.message}`);
    }

    return true;
}
