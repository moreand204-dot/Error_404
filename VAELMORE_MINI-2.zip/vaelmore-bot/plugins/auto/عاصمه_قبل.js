// plugins/auto/عاصمه_قبل.js
// معالج before المنقول من plugins/عاصمه.js
// بوت VAELMORE بيستخدم نمط "before" في plugins/auto/ بدل handler.before

import { theme } from '../../core/theme.js';

export default async function before(m, { conn }) {
    if (!m.isCommand) return false;
    if (!m.text) return false;
    
    const cmd = m.text.toLowerCase();
    
    if (cmd.startsWith('.عاصمه_صحيح_') || cmd.startsWith('.عاصمه_خطأ_')) {
        
        const userCapital = global.db.users[m.sender]?.currentCapital;
        if (!userCapital) {
            await conn.sendMessage(m.chat, { text: theme.build([
                { type: 'title', text: '❄️ VAELMORE: "لا توجد مهمة نشطة"' },
                { type: 'line', text: 'استخدم .عاصمه لبدء مهمة جديدة' }
            ]) }, { quoted: m });
            return true;
        }
        
        const isCorrect = cmd === `.${userCapital.correctCmd}`;
        
        if (isCorrect) {
            if (!global.db.users[m.sender].points) {
                global.db.users[m.sender].points = 0;
            }
            global.db.users[m.sender].points += 100;
            
            await conn.sendMessage(m.chat, { text: theme.build([
                { type: 'title', text: '✅ VAELMORE: "إجابة صحيحة"' },
                { type: 'line', text: '🎉 أحسنت أيها المحارب! +100 نقطة' },
                { type: 'divider' },
                { type: 'info', label: 'العاصمة الصحيحة', value: userCapital.correctAnswer },
                { type: 'info', label: 'نقاطك', value: `${global.db.users[m.sender].points} نقطة` }
            ]) }, { quoted: m });
        } else {
            await conn.sendMessage(m.chat, { text: theme.build([
                { type: 'title', text: '❌ VAELMORE: "إجابة خاطئة"' },
                { type: 'line', text: 'للأسف إجابتك غير صحيحة' },
                { type: 'divider' },
                { type: 'info', label: 'العاصمة الصحيحة', value: userCapital.correctAnswer }
            ]) }, { quoted: m });
        }
        
        delete global.db.users[m.sender].currentCapital;
        return true;
    }
    
    return false;
}
