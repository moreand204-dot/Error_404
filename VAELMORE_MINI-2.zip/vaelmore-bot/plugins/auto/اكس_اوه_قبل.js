// plugins/auto/اكس_اوه_قبل.js
// 🎮 معالج حركات لعبة إكس أو (plugins/اكس_اوه.js)
// بوت VAELMORE بيستخدم نمط "before" في plugins/auto/ بدل handler.before

import { theme } from '../../core/theme.js';

export default async function before(m, { conn }) {
    conn.game = conn.game ? conn.game : {};
    if (!m.isGroup) return false;
    
    let room = Object.values(conn.game).find(room => room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender) && room.state === 'PLAYING');
    
    if (room) {
        let pos = parseInt(m.text);
        if (isNaN(pos)) return false;
        if (pos < 1 || pos > 9) return false;
        
        let { game, x, o } = room;
        if (game.currentTurn !== m.sender) {
            await conn.sendMessage(m.chat, { text: theme.build([
                { type: 'title', text: '⚠️ لـيـس دورك' },
                { type: 'subtitle', text: 'انتظر دورك في اللعب' }
            ]) }, { quoted: m });
            return true;
        }
        
        if (game.turn(game.currentTurn === game.playerX ? 'X' : 'O', pos - 1)) {
            let arr = game.render().map(v => {
                return {
                    X: '❌',
                    O: '⭕',
                    1: '1️⃣',
                    2: '2️⃣',
                    3: '3️⃣',
                    4: '4️⃣',
                    5: '5️⃣',
                    6: '6️⃣',
                    7: '7️⃣',
                    8: '8️⃣',
                    9: '9️⃣',
                }[v];
            });
            
            let str = theme.build([
                { type: 'title', text: '🎮 لـعـبـة إكـس أو ❌⭕' },
                { type: 'divider' },
                { type: 'line', text: '🎯 *الـسـاحـة:*' },
                { type: 'spacer' },
                { type: 'line', text: `${arr.slice(0, 3).join(' ')}` },
                { type: 'line', text: `${arr.slice(3, 6).join(' ')}` },
                { type: 'line', text: `${arr.slice(6).join(' ')}` },
                { type: 'divider' },
                { type: 'info', label: '⚔️ دور', value: '@' + game.currentTurn.split('@')[0] }
            ]);
            
            if (room.x !== room.o) {
                await conn.sendMessage(room.x, { text: str, mentions: [game.currentTurn] }, { quoted: m });
                await conn.sendMessage(room.o, { text: str, mentions: [game.currentTurn] }, { quoted: m });
            } else {
                await conn.sendMessage(room.x, { text: str, mentions: [game.currentTurn] }, { quoted: m });
            }
            
            if (game.winner) {
                if (game.winner === 'draw') {
                    await conn.sendMessage(m.chat, { text: theme.build([
                        { type: 'title', text: '🤝 تـعـادل 🤝' },
                        { type: 'subtitle', text: 'اللعبة انتهت بالتعادل!' }
                    ]) }, { quoted: m });
                } else {
                    let winner = game.winner === 'X' ? game.playerX : game.playerO;
                    await conn.sendMessage(m.chat, { text: theme.build([
                        { type: 'title', text: '🎉 فـائـز 🎉' },
                        { type: 'subtitle', text: `@${winner.split('@')[0]} فاز باللعبة!` },
                        { type: 'divider' },
                        { type: 'info', label: 'الجائزة', value: '+500 نقطة' }
                    ]) }, { quoted: m });
                    
                    if (!global.db.users[winner].points) global.db.users[winner].points = 0;
                    global.db.users[winner].points += 500;
                }
                delete conn.game[room.id];
            }
        } else {
            await conn.sendMessage(m.chat, { text: theme.build([
                { type: 'title', text: '❌ خـطـأ' },
                { type: 'subtitle', text: 'المربع مشغول أو غير موجود' }
            ]) }, { quoted: m });
        }
        return true;
    }
    return false;
}
