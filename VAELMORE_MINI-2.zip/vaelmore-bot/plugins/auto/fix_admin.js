// plugins/auto/fix_admin.js
// ✧ صلح مشكلة isAdmin / isBotAdmin لما الأرقام بتيجي بصيغة @lid
// الـ framework (drakon) بيقارن أرقام بس، لكن معرّفات @lid مختلفة عن رقم التليفون،
// فبيحسب إن البوت (أو الأدمن) "مش أدمن" حتى وهو أدمن فعلاً — وده اللي كان بيطلّع
// رسالة "ارفعني مشرف" رغم إن البوت أدمن، وبيخلّي مضادات الحماية تفتكر إن
// الأدمن عضو عادي.
// بنستخدم isBotActualAdmin / isUserActualAdmin (بيطابقوا id + lid + رقم الهاتف
// مع participants الجروب، وعليهم كاش 8 ثواني) عشان نصحّح الحالتين.

import { isBotActualAdmin, isUserActualAdmin } from '../../system/bot_protection.js';

export default async function before(m, { conn }) {
    if (!m.isGroup) return false;
    if (m.isBotAdmin && m.isAdmin) return false; // الاتنين تمام، مفيش داعي لنداء

    try {
        if (!m.isBotAdmin && await isBotActualAdmin(m.chat, conn)) {
            m.isBotAdmin = true;
        }
        if (!m.isAdmin && await isUserActualAdmin(m.sender, m.chat, conn)) {
            m.isAdmin = true;
        }
    } catch (e) {
        if (process.env.DEBUG_ADMIN_CHECK === '1') console.log('[fix_admin] فشل الفحص الحي:', e?.message);
    }

    return false;
}
