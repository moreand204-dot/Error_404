// reaction_worker.js - الـ worker اللي يراقب القنوات ويرشق التفاعلات
import { getSubsByChannel, getAllSubs, removeSub } from '../../system/reaction_db.js';

// حماية من التكرار عند إعادة تحميل الـ plugin
if (!global.__reactionWorkerActive) global.__reactionWorkerActive = false;

// سجل الرسائل اللي اتفاعل عليها (منع التكرار)
if (!global.__reactedMsgs) global.__reactedMsgs = new Set();

const MAX_REACTED_CACHE = 1000; // منع تضخم الـ cache

// تأخير بين كل reaction ومبعدها (بيشبه السلوك الطبيعي)
const delay = (ms) => new Promise(r => setTimeout(r, ms));

const randomDelay = (min = 1500, max = 4000) =>
    delay(min + Math.floor(Math.random() * (max - min)));

// رشق تفاعل واحد على رسالة
const sendReaction = async (conn, jid, msgKey, emoji) => {
    try {
        await conn.sendMessage(jid, {
            react: { text: emoji, key: msgKey }
        });
        return true;
    } catch (e) {
        console.log(`[ReactionWorker] فشل reaction: ${e.message?.slice(0,50)}`);
        return false;
    }
};

const handler = async (m, { conn }) => {};

// ═══════════════════════════════════════════════════════
// before hook: بيراقب كل رسالة تيجي
// لو الرسالة جاية من قناة فيها اشتراك → يرشق تفاعلات
// ═══════════════════════════════════════════════════════
handler.before = async (m, { conn }) => {
    if (!m?.key) return false;

    // نحفظ الـ conn في global عشان الـ intervals يستخدموه
    if (!global._conn) global._conn = conn;

    const jid = m.key.remoteJid || '';

    // بنراقب القنوات فقط (@newsletter)
    if (!jid.includes('@newsletter')) return false;

    // فحص لو فيه اشتراكات لهذه القناة
    const subs = getSubsByChannel(jid);
    if (!subs.length) return false;

    // منع التفاعل على نفس الرسالة مرتين
    const msgId = m.key.id;
    if (global.__reactedMsgs.has(msgId)) return false;
    global.__reactedMsgs.add(msgId);

    // تنظيف الكاش لو كبر
    if (global.__reactedMsgs.size > MAX_REACTED_CACHE) {
        const arr = [...global.__reactedMsgs];
        global.__reactedMsgs = new Set(arr.slice(-500));
    }

    // رشق تفاعلات لكل اشتراك نشط
    (async () => {
        for (const sub of subs) {
            // فحص انتهاء الاشتراك
            if (Date.now() > sub.expiresAt) {
                removeSub(sub.id);
                console.log(`[ReactionWorker] اشتراك منتهي: ${sub.id}`);
                continue;
            }

            // رشق العدد المطلوب من التفاعلات بالإيموجي المحددة
            let count = 0;
            const maxCount = Math.min(sub.count, 50);

            while (count < maxCount) {
                const emoji = sub.emojis[count % sub.emojis.length];
                const ok = await sendReaction(conn, jid, m.key, emoji);
                if (ok) count++;

                // تأخير عشوائي بين كل reaction يشبه السلوك الطبيعي
                if (count < maxCount) await randomDelay(2000, 5000);
            }
        }
    })().catch(e => console.log('[ReactionWorker] خطأ:', e.message));

    return false;
};

handler.command  = [];
handler.category = 'auto';

export default handler;
