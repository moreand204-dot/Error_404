// plugins/auto/اميوجي_قبل.js
// معالج before المنقول من plugins/اميوجي.js
// بوت VAELMORE بيستخدم نمط "before" في plugins/auto/ بدل handler.before

import { theme } from '../../core/theme.js';

export default async function before(m, { conn }) {
    if (!m.isCommand) return false;
    if (!m.text) return false;
    
    const cmd = m.text.toLowerCase();
    
    if (cmd.startsWith('.ايموجي_صحيح_') || cmd.startsWith('.ايموجي_خطأ_')) {
        
        const userEmoji = global.db.users[m.sender]?.currentEmoji;
        if (!userEmoji) {
            await conn.sendMessage(m.chat, { text: theme.build([
                { type: 'title', text: '❌ خـطـأ' },
                { type: 'subtitle', text: 'لا يوجد سؤال نشط!' },
                { type: 'divider' },
                { type: 'line', text: '⚔️ استخدم .ايموجي لبدء اللعبة' }
            ]) }, { quoted: m });
            return true;
        }
        
        const isCorrect = cmd === `.${userEmoji.correctCmd}`;
        
        if (isCorrect) {
            if (!global.db.users[m.sender].points) {
                global.db.users[m.sender].points = 0;
            }
            global.db.users[m.sender].points += 100;
            
            await conn.sendMessage(m.chat, { text: theme.build([
                { type: 'title', text: '✅ إجـابـة صـحـيـحـة' },
                { type: 'subtitle', text: '🎉 أحسنت! +100 نقطة' },
                { type: 'divider' },
                { type: 'info', label: 'المعنى الصحيح', value: userEmoji.correctAnswer },
                { type: 'info', label: 'نقاطك', value: `${global.db.users[m.sender].points} نقطة` }
            ]) }, { quoted: m });
        } else {
            await conn.sendMessage(m.chat, { text: theme.build([
                { type: 'title', text: '❌ إجـابـة خـاطـئـة' },
                { type: 'subtitle', text: 'للأسف إجابتك غير صحيحة' },
                { type: 'divider' },
                { type: 'info', label: 'المعنى الصحيح', value: userEmoji.correctAnswer }
            ]) }, { quoted: m });
        }
        
        delete global.db.users[m.sender].currentEmoji;
        return true;
    }
    
    return false;
}
