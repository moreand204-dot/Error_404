// plugins/auto/لورد_قبل.js
// 🎯 معالج ضغطات أزرار (ESCANOR / VENOM) اللي بتظهر بعد أمر .المطور
// بيشتغل بنفس نمط plugins/auto/صوت_ازرار.js (نمط "before")

const LORDS = {
    lord_escanor: {
        name: 'اللورد إسكانور',
        contactUrl: 'https://wa.me/79312265574',
        cardImg: 'https://raw.githubusercontent.com/moreand204-dot/photo/main/Lord_ESCANOR.png',
        audioUrl: 'https://raw.githubusercontent.com/moreand204-dot/photo/main/bot%20(2).mp3'
    },
    lord_venom: {
        name: 'اللورد فينوم',
        contactUrl: 'https://wa.me/201065948582',
        cardImg: 'https://raw.githubusercontent.com/moreand204-dot/photo/main/Lord_VENOM.png',
        audioUrl: 'https://raw.githubusercontent.com/moreand204-dot/photo/main/bot2.mp3'
    }
};

export default async function before(m, { conn }) {
    if (m.fromMe) return false;

    let buttonId = null;

    if (m.message?.buttonsResponseMessage) {
        buttonId = m.message.buttonsResponseMessage.selectedButtonId;
    } else if (m.message?.templateButtonReplyMessage) {
        buttonId = m.message.templateButtonReplyMessage.selectedId;
    } else if (m.message?.interactiveResponseMessage?.nativeFlowResponseMessage) {
        buttonId = m.message.interactiveResponseMessage.nativeFlowResponseMessage.id;
    }

    const lord = LORDS[buttonId];
    if (!lord) return false;

    // 1) كرت اللورد + زرار التواصل معاه
    try {
        await conn.sendButton(m.chat, {
            imageUrl: lord.cardImg,
            bodyText: `👑 تواصل مباشر مع ${lord.name}`,
            footerText: '𝐕𝐀𝐄𝐋𝐌𝐎𝐑𝐄 BOT Developers',
            buttons: [
                { name: 'cta_url', params: { display_text: `💬 تواصل مع ${lord.name}`, url: lord.contactUrl } }
            ],
            mentions: [m.sender],
            newsletter: { name: '⚜️ 𝐕𝐀𝐄𝐋𝐌𝐎𝐑𝐄 | 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 𝐒𝐲𝐬𝐭𝐞𝐦', jid: '120363422581600030@newsletter' },
            interactiveConfig: { buttons_limits: 1 }
        }, m);
    } catch (err) {
        console.error('[لورد_قبل - كرت]', err?.message);
        await conn.sendMessage(m.chat, {
            image: { url: lord.cardImg },
            caption: `👑 تواصل مباشر مع ${lord.name}\n> ${lord.contactUrl}`
        }, { quoted: m }).catch(() => {});
    }

    // 2) الصوت المرفق بعد الكرت
    try {
        await conn.sendMessage(m.chat, {
            audio: { url: lord.audioUrl },
            mimetype: 'audio/mpeg',
            ptt: false
        }, { quoted: m });
    } catch (err) {
        console.error('[لورد_قبل - صوت]', err?.message);
    }

    return true;
}
