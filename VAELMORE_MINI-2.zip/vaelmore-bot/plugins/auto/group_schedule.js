

import { readFileSync, writeFileSync, existsSync } from 'fs';
import { adminGuard, checkCommandCooldown, notAdminMsg, notAuthMsg } from '../../system/bot_protection.js';
import { getLocalNow } from '../../system/timezone.js';

const SCHEDULE_FILE = './system/group_schedule.json';

const loadConfig = () => {
    try { return existsSync(SCHEDULE_FILE) ? JSON.parse(readFileSync(SCHEDULE_FILE, 'utf-8')) : {}; }
    catch { return {}; }
};

const saveConfig = (cfg) => {
    try { writeFileSync(SCHEDULE_FILE, JSON.stringify(cfg, null, 2)); } catch {}
};

if (!global.__botConnRegistry) global.__botConnRegistry = new Map();

const registerConn = (conn) => {
    const botId = conn?.user?.id;
    if (botId) global.__botConnRegistry.set(botId, conn);
    if (!global._conn) global._conn = conn;
};

const resolveConnForChat = async (chatId, savedBotId) => {
    if (savedBotId && global.__botConnRegistry.has(savedBotId)) {
        return global.__botConnRegistry.get(savedBotId);
    }
    for (const conn of global.__botConnRegistry.values()) {
        try {
            await conn.groupMetadata(chatId);
            return conn;
        } catch { }
    }
    return global._conn || null;
};

// ٠-٩ عربي => 0-9 انجليزي (بعض الكيبوردات بتكتب أرقام عربي تلقائي)
const normalizeDigits = (s) => s.replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));

// بيقبل: "7:00 م" / "7:00م" / "7 م" / "07:00 ص" / "19:00" (بدون ص/م = نظام 24 ساعة)
const parseTime = (str) => {
    if (!str) return null;
    const cleaned = normalizeDigits(str.trim());

    // صيغة 12 ساعة + ص/م (الدقايق اختيارية: "7 م" = "7:00 م")
    const m12 = cleaned.match(/^(\d{1,2})(?::(\d{1,2}))?\s*(ص|م)$/);
    if (m12) {
        let h = parseInt(m12[1], 10);
        const min = m12[2] !== undefined ? parseInt(m12[2], 10) : 0;
        const period = m12[3];
        if (h < 1 || h > 12 || min < 0 || min > 59) return null;

        if (period === 'م' && h !== 12) h += 12;
        if (period === 'ص' && h === 12) h = 0;

        return `${h.toString().padStart(2, '0')}:${min.toString().padStart(2, '0')}`;
    }

    // صيغة 24 ساعة من غير ص/م
    const m24 = cleaned.match(/^(\d{1,2}):(\d{1,2})$/);
    if (m24) {
        const h = parseInt(m24[1], 10), min = parseInt(m24[2], 10);
        if (h < 0 || h > 23 || min < 0 || min > 59) return null;
        return `${h.toString().padStart(2, '0')}:${min.toString().padStart(2, '0')}`;
    }

    return null;
};

const formatTime12 = (time24) => {
    if (!time24) return null;
    const [hStr, min] = time24.split(':');
    let h = parseInt(hStr);
    const period = h < 12 ? 'ص' : 'م';
    if (h === 0) h = 12;
    else if (h > 12) h -= 12;
    return `${h}:${min} ${period}`;
};

// بياخد آخر رقم لوحده في نهاية الكلام كـ"مدة بالدقايق" لو موجود، ويرجع
// الوقت من غيره. مثال: "7:00 م 30" => الوقت "7:00 م" + مدة 30 دقيقة
// (يستخدم عشان "افتح الساعة كذا واقفل تاني بعد كذا دقيقة" والعكس)
const extractDuration = (args) => {
    if (args.length >= 2) {
        const last = normalizeDigits(args[args.length - 1]);
        if (/^\d{1,4}$/.test(last)) {
            return { duration: parseInt(last, 10), rest: args.slice(0, -1).join(' ') };
        }
    }
    return { duration: null, rest: args.join(' ') };
};

const statusText = (s) => {
    const openLine = s.openTime
        ? `${formatTime12(s.openTime)} (${s.openTime})` + (s.openDurationMin ? ` — يتقفل تلقائي بعد ${s.openDurationMin} دقيقة` : '')
        : 'مش متحدد';
    const closeLine = s.closeTime
        ? `${formatTime12(s.closeTime)} (${s.closeTime})` + (s.closeDurationMin ? ` — يتفتح تلقائي بعد ${s.closeDurationMin} دقيقة` : '')
        : 'مش متحدد';

    return (
        `*📅 جدولة الجروب*\n\n` +
        `🔓 وقت الفتح: ${openLine}\n` +
        `🔒 وقت القفل: ${closeLine}\n` +
        `⚡ الحالة: ${s.active ? 'شغالة ✅' : 'مقفولة 🚫'}\n\n` +
        `*الأوامر:*\n` +
        `.فتح_الساعه 7:00 م\n` +
        `.فتح_الساعه 7:00 م 30  (يقفل تاني بعد 30 دقيقة تلقائي)\n` +
        `.قفل_الساعه 12:00 ص\n` +
        `.قفل_الساعه 12:00 ص 45  (يفتح تاني بعد 45 دقيقة تلقائي)\n` +
        `.الغاء_فتح_تلقائي\n` +
        `.الغاء_قفل_تلقائي\n` +
        `.حالة_الجدولة`
    );
};

// ==========================================================
// المحرك الشغال في الخلفية: بيفحص كل 30 ثانية ولو الوقت الحالي
// طابق ميعاد الفتح أو القفل المحفوظ لأي جروب، بينفذ فعليًا عن طريق
// conn.groupSettingUpdate. الحماية __groupScheduleFired بتمنع إعادة
// التنفيذ أكتر من مرة في نفس اليوم لو الفحص جه مرتين في نفس الدقيقة.
// ==========================================================
if (!global.__groupScheduleInterval) {
    global.__groupScheduleInterval = setInterval(async () => {
        const cfg = loadConfig();
        if (!Object.keys(cfg).length) return;
        if (!global.__botConnRegistry?.size && !global._conn) return;

        const { currentTime, dayKey } = getLocalNow();

        for (const [chatId, s] of Object.entries(cfg)) {
            if (!s.active) continue;
            if (s.openTime !== currentTime && s.closeTime !== currentTime) continue;

            const conn = await resolveConnForChat(chatId, s.botId);
            if (!conn) continue;

            if (s.openTime === currentTime) {
                const fireKey = `open_${chatId}_${dayKey}_${currentTime}`;
                if (!global.__groupScheduleFired) global.__groupScheduleFired = {};
                if (!global.__groupScheduleFired[fireKey]) {
                    global.__groupScheduleFired[fireKey] = true;
                    try {
                        await conn.groupSettingUpdate(chatId, 'not_announcement');
                        await conn.sendMessage(chatId, {
                            text: `🔓 *الجروب اتفتح لوحده* 🔓\n⏰ حسب الجدولة الساعة ${formatTime12(currentTime)}`
                        });

                        // لو محدد مدة، اقفل تاني بعدها لوحده
                        if (s.openDurationMin && s.openDurationMin > 0) {
                            setTimeout(async () => {
                                try {
                                    await conn.groupSettingUpdate(chatId, 'announcement');
                                    await conn.sendMessage(chatId, {
                                        text: `🔒 *الجروب اتقفل تلقائيًا* 🔒\nبعد ${s.openDurationMin} دقيقة من الفتح`
                                    });
                                } catch (e) {
                                    console.error(`[جدولة] قفل تلقائي بعد المدة فشل ${chatId}:`, e?.message);
                                }
                            }, s.openDurationMin * 60 * 1000);
                        }
                    } catch (e) {
                        console.error(`[جدولة] فتح الجروب فشل ${chatId}:`, e?.message);
                    }
                }
            }

            if (s.closeTime === currentTime) {
                const fireKey = `close_${chatId}_${dayKey}_${currentTime}`;
                if (!global.__groupScheduleFired) global.__groupScheduleFired = {};
                if (!global.__groupScheduleFired[fireKey]) {
                    global.__groupScheduleFired[fireKey] = true;
                    try {
                        await conn.groupSettingUpdate(chatId, 'announcement');
                        await conn.sendMessage(chatId, {
                            text: `🔒 *الجروب اتقفل لوحده* 🔒\n⏰ حسب الجدولة الساعة ${formatTime12(currentTime)}`
                        });

                        // لو محدد مدة، افتح تاني بعدها لوحده
                        if (s.closeDurationMin && s.closeDurationMin > 0) {
                            setTimeout(async () => {
                                try {
                                    await conn.groupSettingUpdate(chatId, 'not_announcement');
                                    await conn.sendMessage(chatId, {
                                        text: `🔓 *الجروب اتفتح تلقائيًا* 🔓\nبعد ${s.closeDurationMin} دقيقة من القفل`
                                    });
                                } catch (e) {
                                    console.error(`[جدولة] فتح تلقائي بعد المدة فشل ${chatId}:`, e?.message);
                                }
                            }, s.closeDurationMin * 60 * 1000);
                        }
                    } catch (e) {
                        console.error(`[جدولة] قفل الجروب فشل ${chatId}:`, e?.message);
                    }
                }
            }
        }

        if (global.__groupScheduleFired) {
            for (const k of Object.keys(global.__groupScheduleFired)) {
                if (!k.includes(dayKey)) delete global.__groupScheduleFired[k];
            }
        }
    }, 30_000);
}

const handler = async (m, { conn, command, args, bot }) => {
    if (!m.isGroup) return m.reply('*❌ الأمر ده شغال في الجروبات بس يا معلم*');

    registerConn(conn);

    await adminGuard(m, { conn, bot });

    const cooldown = checkCommandCooldown(command, m.sender, m.chat);
    if (!cooldown.allowed) {
        return m.reply(`*⏳ استنى ${Math.ceil(cooldown.waitMs / 1000)} ثانية*`);
    }

    if (!m.isAdmin) return m.reply(notAuthMsg());
    if (!m.isBotAdmin) return m.reply(notAdminMsg());

    const cfg = loadConfig();
    const chatId = m.chat;
    if (!cfg[chatId]) {
        cfg[chatId] = { openTime: null, closeTime: null, openDurationMin: null, closeDurationMin: null, active: false, botId: null };
    }
    // ترقية سجلات قديمة اتعملت قبل إضافة المدة
    if (cfg[chatId].openDurationMin === undefined) cfg[chatId].openDurationMin = null;
    if (cfg[chatId].closeDurationMin === undefined) cfg[chatId].closeDurationMin = null;

    cfg[chatId].botId = conn?.user?.id || cfg[chatId].botId;
    const s = cfg[chatId];

    // ================= .فتح_الساعه <وقت> [دقايق] =================
    if (command === 'فتح_الساعه' || command === 'autoopen') {
        const { duration, rest } = extractDuration(args);
        const t = parseTime(rest);
        if (!t) {
            return m.reply(
                '*❌ اكتب الوقت صح، مثال:*\n' +
                '.فتح_الساعه 7:00 م\n' +
                '.فتح_الساعه 8:00 ص\n' +
                '.فتح_الساعه 7:00 م 30  ← يقفل تلقائي بعد 30 دقيقة'
            );
        }
        if (duration !== null && (duration < 1 || duration > 1440)) {
            return m.reply('*❌ عدد الدقايق لازم يكون بين 1 و 1440*');
        }
        s.openTime = t;
        s.openDurationMin = duration;
        s.active = true;
        saveConfig(cfg);
        return m.reply(
            `✅ *موعد فتح الجروب اتظبط*\n⏰ الساعة ${formatTime12(t)} (${t}) كل يوم` +
            (duration ? `\n⏱️ هيتقفل تلقائي بعد ${duration} دقيقة من الفتح` : '')
        );
    }

    // ================= .قفل_الساعه <وقت> [دقايق] =================
    if (command === 'قفل_الساعه' || command === 'autoclose') {
        const { duration, rest } = extractDuration(args);
        const t = parseTime(rest);
        if (!t) {
            return m.reply(
                '*❌ اكتب الوقت صح، مثال:*\n' +
                '.قفل_الساعه 12:00 ص\n' +
                '.قفل_الساعه 11:00 م\n' +
                '.قفل_الساعه 12:00 ص 45  ← يفتح تلقائي بعد 45 دقيقة'
            );
        }
        if (duration !== null && (duration < 1 || duration > 1440)) {
            return m.reply('*❌ عدد الدقايق لازم يكون بين 1 و 1440*');
        }
        s.closeTime = t;
        s.closeDurationMin = duration;
        s.active = true;
        saveConfig(cfg);
        return m.reply(
            `✅ *موعد قفل الجروب اتظبط*\n⏰ الساعة ${formatTime12(t)} (${t}) كل يوم` +
            (duration ? `\n⏱️ هيتفتح تلقائي بعد ${duration} دقيقة من القفل` : '')
        );
    }

    // ================= إلغاء فتح/قفل لوحده =================
    if (command === 'الغاء_فتح_تلقائي') {
        s.openTime = null;
        s.openDurationMin = null;
        if (!s.closeTime) s.active = false;
        saveConfig(cfg);
        return m.reply('🚫 *جدولة فتح الجروب اتلغت*');
    }

    if (command === 'الغاء_قفل_تلقائي') {
        s.closeTime = null;
        s.closeDurationMin = null;
        if (!s.openTime) s.active = false;
        saveConfig(cfg);
        return m.reply('🚫 *جدولة قفل الجروب اتلغت*');
    }

    if (command === 'حالة_الجدولة') {
        return m.reply(statusText(s));
    }

    // ================= الأمر الشامل القديم: .جدولة [فتح/قفل/...] =================
    const sub = args[0]?.toLowerCase()?.trim();
    const subArgs = args.slice(1);

    if (sub === 'فتح' || sub === 'open') {
        const { duration, rest } = extractDuration(subArgs);
        const t = parseTime(rest);
        if (!t) return m.reply('*❌ اكتب الوقت صح، مثال:*\n.جدولة فتح 8:00 ص');
        if (duration !== null && (duration < 1 || duration > 1440)) return m.reply('*❌ عدد الدقايق لازم يكون بين 1 و 1440*');
        s.openTime = t;
        s.openDurationMin = duration;
        s.active = true;
        saveConfig(cfg);
        return m.reply(`✅ *موعد فتح الجروب اتظبط الساعة ${formatTime12(t)} (${t}) كل يوم*` + (duration ? `\n⏱️ هيتقفل تلقائي بعد ${duration} دقيقة` : ''));
    }

    if (sub === 'قفل' || sub === 'close') {
        const { duration, rest } = extractDuration(subArgs);
        const t = parseTime(rest);
        if (!t) return m.reply('*❌ اكتب الوقت صح، مثال:*\n.جدولة قفل 11:00 م');
        if (duration !== null && (duration < 1 || duration > 1440)) return m.reply('*❌ عدد الدقايق لازم يكون بين 1 و 1440*');
        s.closeTime = t;
        s.closeDurationMin = duration;
        s.active = true;
        saveConfig(cfg);
        return m.reply(`✅ *موعد قفل الجروب اتظبط الساعة ${formatTime12(t)} (${t}) كل يوم*` + (duration ? `\n⏱️ هيتفتح تلقائي بعد ${duration} دقيقة` : ''));
    }

    if (sub === 'تفعيل' || sub === 'on') {
        if (!s.openTime && !s.closeTime) {
            return m.reply('*❌ حدد وقت فتح أو قفل الأول*');
        }
        s.active = true;
        saveConfig(cfg);
        return m.reply('✅ *جدولة الجروب اتشغلت*');
    }

    if (sub === 'الغاء' || sub === 'off' || sub === 'إلغاء') {
        s.active = false;
        saveConfig(cfg);
        return m.reply('🚫 *جدولة الجروب اتقفلت* (المواعيد لسه محفوظة)');
    }

    if (sub === 'حذف' || sub === 'delete') {
        delete cfg[chatId];
        saveConfig(cfg);
        return m.reply('🗑️ *جدولة الجروب اتمسحت خالص*');
    }

    return m.reply(statusText(s));
};

handler.usage    = [
    'فتح_الساعه <وقت> [دقايق]',
    'قفل_الساعه <وقت> [دقايق]',
    'الغاء_فتح_تلقائي',
    'الغاء_قفل_تلقائي',
    'حالة_الجدولة'
];
handler.category = 'auto';
handler.command  = [
    'جدولة', 'جدولة_الجروب', 'group_schedule', 'schedule',
    'فتح_الساعه', 'autoopen',
    'قفل_الساعه', 'autoclose',
    'الغاء_فتح_تلقائي', 'الغاء_قفل_تلقائي',
    'حالة_الجدولة'
];
handler.admin    = true;
handler.botAdmin = true;

handler.before = async (m, { conn }) => {
    registerConn(conn);
};

export default handler;
