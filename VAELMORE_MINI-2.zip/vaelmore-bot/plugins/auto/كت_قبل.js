// plugins/auto/كت_قبل.js
// معالج before المنقول من plugins/كت.js
// بوت VAELMORE بيستخدم نمط "before" في plugins/auto/ بدل handler.before

export default async function before(m, { conn }) {
    if (!m.isCommand) return false;
    if (!m.text) return false;
    
    const cmd = m.text.toLowerCase();
    
    if (cmd.startsWith('.كت_صحيح_') || cmd.startsWith('.كت_خطأ_')) {
        
        const userKt = global.db.users[m.sender]?.currentKt;
        if (!userKt) {
            await conn.sendMessage(m.chat, { text: '> ❄️ *VAELMORE: "لا توجد مهمة نشطة"*\n> \n> 🔮 استخدم .كت لبدء مهمة جديدة' }, { quoted: m });
            return true;
        }
        
        const isCorrect = cmd === `.${userKt.correctCmd}`;
        
        if (isCorrect) {
            if (!global.db.users[m.sender].points) {
                global.db.users[m.sender].points = 0;
            }
            global.db.users[m.sender].points += 100;
            
            await conn.sendMessage(m.chat, { text: '> ✅ *VAELMORE: "إجابة صحيحة"*\n> \n> 🎉 أحسنت أيها المحارب! +100 نقطة\n> 🔮 الإجابة: ' + userKt.correctAnswer + '\n> ⭐ نقاطك: ' + global.db.users[m.sender].points + ' نقطة' }, { quoted: m });
        } else {
            await conn.sendMessage(m.chat, { text: '> ❌ *VAELMORE: "إجابة خاطئة"*\n> \n> 🔮 الإجابة الصحيحة: ' + userKt.correctAnswer }, { quoted: m });
        }
        
        delete global.db.users[m.sender].currentKt;
        return true;
    }
    
    return false;
}
