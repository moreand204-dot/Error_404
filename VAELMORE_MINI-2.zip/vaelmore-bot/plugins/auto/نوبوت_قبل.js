// plugins/auto/نوبوت_قبل.js
// ✧ معالج الكشف الفعلي لنظام "نوبوت" (مضاد البوتات) - نظام مستقل ووحيد
// شغال في المشروع دلوقتي (النظام التاني الأوتوماتيكي اتقفل من
// plugins/auto/anti-bot.js عشان يبقى نوبوت هو المتحكم الوحيد).
//
// التفعيل/الإيقاف من: plugins/vaelmore-2b-commands/نوبوت.js (.نوبوت اون/اوف)
// بيستخدم نفس ملف الإعدادات: ./data/antibot.json
//
// طريقة الكشف (أكتر من إشارة مع بعض، مش بس بصمة الـ message ID
// اللي كانت مش بتظبط مع بوتات كتير):
//   1) الـ JID فيه ":" قبل @s.whatsapp.net → يعني رقم متصل كـ "جهاز
//      مربوط" (linked device) - ده أهم وأقوى إشارة، وهي نفس الطريقة
//      اللي بيعتمد عليها بوتات كتير تانية في نفس المشروع.
//   2) اسم العرض (pushName) فيه كلمة BOT / بوت.
//   3) نص الرسالة نفسه فيه عبارات معروفة من بوتات تانية (تنصيب،
//      البوت مش أدمن، جاري تنصيب البوت...إلخ).
//   4) بصمة الـ message ID (احتياطي إضافي بس، مش بيتعمد عليه لوحده).
//
// بوتاتنا احنا (البوت الرئيسي + الفرعيين) والمطورين مستثنيين تمامًا
// مهما طلعت عليهم أي إشارة من دول.

import fs from 'fs';

const antibotPath = './data/antibot.json';
const detectedBots = {}; // تتبع محلي بس لمنع تكرار نفس البوت خلال 10 ثواني

// 🔥 روابط تنبيه الفيديو/الصوت
const MEDIA_URLS = {
    video: 'https://file.garden/aauvg01sjleV_ic1/VID-20260511-WA0128.mp4',
    audio: 'https://file.garden/aauvg01sjleV_ic1/VID-20260511-WA0128.mp3'
};

// تأكيد دفاعي إن الملف موجود حتى لو الملف ده اتحمّل قبل ملف الأمر
if (!fs.existsSync('./data')) fs.mkdirSync('./data', { recursive: true });
if (!fs.existsSync(antibotPath)) fs.writeFileSync(antibotPath, JSON.stringify({}, null, 2));

// ── حماية بوتاتنا احنا (نفس منطق anti-bot.js بالظبط، منسوخ هنا عشان
// النظام يفضل مستقل ومايتأثرش لو anti-bot.js اتقفل أو اتشال) ──
const isMyBot = (sender, conn) => {
    const myNum = conn?.user?.id?.split(':')[0];
    return !!(myNum && sender.includes(myNum));
};

const isMySubBot = (sender) => {
    try {
        const subList = global.subBots?.list?.() || [];
        const senderNum = sender.split('@')[0].split(':')[0];
        return subList.some(b => b.phone === senderNum || String(b.number) === senderNum);
    } catch { return false; }
};

const isOwner = (sender, bot) =>
    bot?.config?.owners?.some(o => o.jid === sender || o.lid === sender);

// ── عبارات معروفة عن بوتات تانية (زوّد عليها براحتك) ──
const BOT_TEXT_SIGNATURES = [
    'تنصيب',
    'التنصيب متوقف',
    'جاري تنصيب البوت',
    'البوت مش أدمن',
    'sub bot',
    'made by',
];

const looksLikeBotText = (text = '') => {
    const t = text.toLowerCase();
    return BOT_TEXT_SIGNATURES.some(sig => t.includes(sig.toLowerCase()));
};

export default async function before(m, { conn, bot }) {
    try {
        // 1. التأكد إنها رسالة في جروب
        if (!m.isGroup) return false;

        // 2. جلب إعدادات الجروب
        let chatId = m.chat;
        let antibott = {};
        try {
            antibott = JSON.parse(fs.readFileSync(antibotPath));
        } catch {
            return false;
        }

        // 3. هل مضاد البوتات مفعل في هذا الجروب؟
        if (antibott[chatId] !== true) return false;

        // 4. منع طرد البوت نفسه أو رسائل النظام
        if (m.key.fromMe) return false;

        let senderId = m.sender;
        if (typeof conn.decodeJid === 'function') {
            senderId = conn.decodeJid(senderId);
        }

        // 5. استثناء تام: بوتنا الرئيسي، بوتاتنا الفرعية، والمطورين
        if (isMyBot(senderId, conn)) return false;
        if (isMySubBot(senderId)) return false;
        if (isOwner(senderId, bot)) return false;

        // 6. الكشف - أكتر من إشارة مع بعض
        const msgId = m.key?.id || m.id || '';
        const msgText = m.text || m.body || '';
        const pushName = (m.pushName || '').toLowerCase();

        let isBot = false;
        let botType = '';

        // إشارة 1: JID فيه ":" = جهاز مربوط (linked device) - الأقوى
        if (/^\d+:\d+@s\.whatsapp\.net$/.test(senderId)) {
            isBot = true; botType = 'جهاز مربوط (Linked Device)';
        }
        // إشارة 2: اسم العرض فيه كلمة بوت
        else if (pushName.includes('bot') || pushName.includes('بوت')) {
            isBot = true; botType = 'اسم العرض';
        }
        // إشارة 3: نص الرسالة فيه عبارة بوت معروفة
        else if (looksLikeBotText(msgText)) {
            isBot = true; botType = 'محتوى الرسالة';
        }
        // إشارة 4 (احتياطي): بصمة الـ message ID القديمة
        else if (msgId) {
            if (msgId.startsWith('3EB0') && msgId.length < 25) { isBot = true; botType = 'بصمة ID (Baileys)'; }
            else if (msgId.startsWith('BAE5') && msgId.length === 16) { isBot = true; botType = 'بصمة ID (Baileys v2)'; }
            else if (msgId.startsWith('B24E') && msgId.length === 20) { isBot = true; botType = 'بصمة ID (Baileys v3)'; }
            else if (msgId.startsWith('8SCO') && msgId.length === 20) { isBot = true; botType = 'بصمة ID (Baileys v4)'; }
            else if (msgId.startsWith('NJX-')) { isBot = true; botType = 'بصمة ID (NJX Bot)'; }
        }

        if (!isBot) return false;

        const senderNum = senderId.split('@')[0].split(':')[0];

        // 7. منع التكرار لنفس البوت خلال 10 ثواني
        if (detectedBots[chatId]?.includes(senderId)) return false;
        if (!detectedBots[chatId]) detectedBots[chatId] = [];
        detectedBots[chatId].push(senderId);

        // 8. إرسال الفيديو والصوت من الروابط
        try {
            let fixedChatId = chatId;
            if (typeof conn.decodeJid === 'function') {
                fixedChatId = conn.decodeJid(chatId);
            }

            await conn.sendMessage(fixedChatId, {
                video: { url: MEDIA_URLS.video },
                gifPlayback: true,
                caption: `🚨 *تم اكتشاف بوت!*\n👤 *الرقم:* ${senderNum}\n🔍 *سبب الكشف:* ${botType}`,
                mentions: [senderId]
            });

            await conn.sendMessage(fixedChatId, {
                audio: { url: MEDIA_URLS.audio },
                mimetype: 'audio/mpeg',
                ptt: false
            });

        } catch (mediaErr) {
            console.error('خطأ في إرسال الميديا:', mediaErr);
            await conn.sendMessage(chatId, {
                text: `🚨 *تم اكتشاف بوت!*\n📞 الرقم: ${senderNum}\n🏷️ سبب الكشف: ${botType}`,
                mentions: [senderId]
            });
        }

        // 9. محاولة طرد البوت
        try {
            await conn.groupParticipantsUpdate(chatId, [senderId], "remove");
            await conn.sendMessage(chatId, {
                text: `✅ *تم طرد البوت بنجاح!*\n📞 الرقم: ${senderNum}`,
                mentions: [senderId]
            });
        } catch (err) {
            await conn.sendMessage(chatId, {
                text: `⚠️ *فشل الطرد!*\n📞 الرقم: ${senderNum}\n🔧 يرجى جعل البوت أدمن أولاً`,
                mentions: [senderId]
            });
        }

        // 10. إزالة من القائمة بعد 10 ثواني
        setTimeout(() => {
            if (detectedBots[chatId]) {
                const index = detectedBots[chatId].indexOf(senderId);
                if (index > -1) detectedBots[chatId].splice(index, 1);
            }
        }, 10000);

        return false;

    } catch (e) {
        console.error('❌ خطأ في مضاد البوتات:', e);
        return false;
    }
}
