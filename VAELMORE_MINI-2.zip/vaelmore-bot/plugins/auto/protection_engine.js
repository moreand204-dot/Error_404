// plugins/auto/protection_engine.js
// ✧ VAELMORE BOT - نقطة تشغيل محرك الحماية على كل رسالة جروب
// بيستبدل الملفات القديمة: anti-link.js, anti_advanced.js, وجزء الميديا/الشتايم
// من welcome.js - كلهم دلوقتي مكان واحد متسق بيستخدم نفس التخزين ونفس منطق الطرد.
//
// للتشخيص: شغّل البوت بـ DEBUG_PROTECTION=1 وهتشوف في الكونسول ليه رسالة معينة
// اتجاهلت (مطوّر/أدمن، مفيش إعداد شغال في الجروب، ...) أو اتعاقبت.

import { getG, isOwnerFn, evaluateMessage, enforceViolation } from '../../system/protection_engine.js';

const dbg = (...a) => { if (process.env.DEBUG_PROTECTION === '1') console.log('[protection]', ...a); };

export default async function before(m, { conn, bot }) {
  if (!m.isGroup) return false;
  if (m.key?.fromMe) return false;

  const g = getG(m.chat);
  if (isOwnerFn(m.sender, bot, conn) || m.isAdmin || m.isSuperAdmin) {
    dbg('تجاهل (مطوّر/أدمن):', m.sender);
    return false;
  }

  const violation = evaluateMessage(m, g);
  if (!violation) {
    dbg('مفيش مخالفة. الإعدادات الشغالة:', Object.keys(g).filter(k => g[k] === true).join(',') || 'ولا واحد');
    return false;
  }

  dbg('مخالفة:', violation.reason, 'من', m.sender);
  await enforceViolation(m, conn, bot, g, violation);
  return true;
}
