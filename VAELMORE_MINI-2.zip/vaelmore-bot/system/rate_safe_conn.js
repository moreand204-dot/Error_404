

// system/rate_safe_conn.js
// ✧ حماية النداءات اللي واتساب بيحط عليها rate-limit (groupMetadata، sendMessage...)
//
// اتصلح فيه حاجتين مهمين كانوا سبب إن البوت بيتقّل ويرد متأخر / مش بيرد خالص:
//
// 1) الجيت (throttle) كان *مشترك* بين كل الدوال - يعني لو فيه زحمة نداءات
//    groupMetadata بتتعاد (retry) بتأخير كبير، sendMessage (رد البوت) كان
//    بيتحبس وراهم في نفس الطابور. دلوقتي كل دالة ليها طابور/تايمر مستقل،
//    فرد البوت (sendMessage) مبيستناش خلف مزامنة الجروبات.
//
// 2) عمل كاش بسيط لـ groupMetadata (TTL) - ده أهم حاجة، لأن أغلب النداءات
//    كانت بتتكرر لنفس الجروب كذا مرة قريبة من بعض (كل حدث/كل رسالة)
//    فكانت بتضرب rate-overlimit باستمرار. الكاش بيلغي 90%+ من النداءات دي.

const RATE_LIMITED_METHODS = [
    'sendMessage',
    'groupParticipantsUpdate',
    'groupMetadata',
    'groupSettingUpdate',
    'groupInviteCode',
    'groupRevokeInvite',
    'groupUpdateSubject',
    'groupUpdateDescription',
    'updateProfileStatus',
    'onWhatsApp',
    'profilePictureUrl',
];

const MAX_RETRIES = 3;          // عدد المحاولات بعد الأولى
const BASE_DELAY_MS = 2000;
const MIN_GAP_MS = 250;         // أقل فاصل بين نداءين لنفس الدالة

// كاش groupMetadata: TTL 5 دقايق - كافي إنه يقلل الزحمة جداً من غير ما
// البيانات تبقى قديمة أوي (اسم الجروب/الأعضاء بيتغيروا مش كل ثانية)
const GROUP_META_TTL_MS = 5 * 60 * 1000;
const groupMetaCache = new Map(); // jid -> { data, at }

const isRateLimitError = (e) => {
    const msg = (e?.message || e?.data || String(e) || '').toLowerCase();
    return msg.includes('rate-overlimit') || msg.includes('rate overlimit');
};

export const invalidateGroupMetaCache = (jid) => {
    if (jid) groupMetaCache.delete(jid);
    else groupMetaCache.clear();
};

export const wrapConnWithRateSafety = (conn) => {
    if (!conn || conn.__rateSafeWrapped) return conn;
    conn.__rateSafeWrapped = true;

    // كل دالة ليها وقت آخر نداء خاص بيها لوحدها - مش مشترك
    const lastCallAt = Object.create(null);

    const throttle = async (methodName) => {
        const wait = (lastCallAt[methodName] || 0) + MIN_GAP_MS - Date.now();
        if (wait > 0) await new Promise(r => setTimeout(r, wait));
        lastCallAt[methodName] = Date.now();
    };

    for (const methodName of RATE_LIMITED_METHODS) {
        const original = conn[methodName];
        if (typeof original !== 'function') continue;

        conn[methodName] = async function (...args) {
            // ── كاش groupMetadata: لو عندنا نسخة لسه طازة، منعملش نداء أصلاً
            if (methodName === 'groupMetadata') {
                const jid = args[0];
                const cached = groupMetaCache.get(jid);
                if (cached && (Date.now() - cached.at) < GROUP_META_TTL_MS) {
                    return cached.data;
                }
            }

            await throttle(methodName);

            let lastErr;
            for (let attempt = 1; attempt <= 1 + MAX_RETRIES; attempt++) {
                try {
                    const result = await original.apply(this, args);
                    if (methodName === 'groupMetadata') {
                        groupMetaCache.set(args[0], { data: result, at: Date.now() });
                    }
                    return result;
                } catch (e) {
                    lastErr = e;
                    if (!isRateLimitError(e)) throw e;
                    if (attempt > MAX_RETRIES) break; // خلصت المحاولات

                    const delay = BASE_DELAY_MS * Math.pow(2, attempt - 1);
                    console.error(`[rate-safety] ${methodName} اتضرب rate-overlimit، استنى ${delay}ms (محاولة ${attempt}/${MAX_RETRIES})`);
                    await new Promise(r => setTimeout(r, delay));
                }
            }
            throw lastErr;
        };
    }

    return conn;
};
