// إعداد التوقيت العام اللي بتعتمد عليه أي جدولة وقتية في البوت (زي فتح/قفل
// الجروبات). مش متثبت على دولة معينة في الكود - المطور هو اللي بيحدده مرة
// واحدة بالأمر المناسب، وبيتخزن هنا، وأي نظام تاني محتاج "دلوقتي كام الساعة
// عند المستخدم" بيقرا منه بدل ما يعتمد على توقيت السيرفر.

import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import path from 'path';

const CONFIG_FILE = path.join(process.cwd(), 'system', 'timezone.json');

// افتراضي مبدئي بس - قابل للتغيير بالكامل عن طريق .تعيين_التوقيت
const DEFAULT_TZ = 'Africa/Cairo';

const isValidTimeZone = (tz) => {
    try {
        Intl.DateTimeFormat(undefined, { timeZone: tz });
        return true;
    } catch {
        return false;
    }
};

export const getTimezone = () => {
    try {
        if (existsSync(CONFIG_FILE)) {
            const data = JSON.parse(readFileSync(CONFIG_FILE, 'utf-8'));
            if (data?.tz && isValidTimeZone(data.tz)) return data.tz;
        }
    } catch { }
    return DEFAULT_TZ;
};

export const setTimezone = (tz) => {
    if (!isValidTimeZone(tz)) return false;
    try {
        mkdirSync(path.dirname(CONFIG_FILE), { recursive: true });
        writeFileSync(CONFIG_FILE, JSON.stringify({ tz, updatedAt: Date.now() }, null, 2));
        return true;
    } catch {
        return false;
    }
};

// بيرجع { currentTime: "HH:MM", dayKey: "YYYY-MM-DD" } بتوقيت المنطقة
// المحفوظة حاليًا، بغض النظر عن توقيت السيرفر نفسه.
export const getLocalNow = () => {
    const tz = getTimezone();
    const parts = new Intl.DateTimeFormat('en-GB', {
        timeZone: tz,
        year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit', hour12: false
    }).formatToParts(new Date());

    const map = {};
    for (const p of parts) map[p.type] = p.value;

    return {
        currentTime: `${map.hour}:${map.minute}`,
        dayKey: `${map.year}-${map.month}-${map.day}`
    };
};
