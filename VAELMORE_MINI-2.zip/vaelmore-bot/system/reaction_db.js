// reaction_db.js - قاعدة بيانات اشتراكات رشق التفاعلات

const KEY = '__reactionSubs';

export const getDB = () => {
    if (!global._gs) global._gs = {};
    if (!global._gs[KEY]) global._gs[KEY] = {};
    return global._gs[KEY];
};

// جيب كل الاشتراكات النشطة
export const getAllSubs = () => {
    const db = getDB();
    const now = Date.now();
    // نظّف المنتهية أول
    for (const id of Object.keys(db)) {
        if (db[id].expiresAt < now) delete db[id];
    }
    return Object.values(db);
};

// جيب اشتراكات قناة معينة
export const getSubsByChannel = (channelJid) =>
    getAllSubs().filter(s => s.channelJid === channelJid);

// أضف اشتراك
export const addSub = (data) => {
    const db = getDB();
    const id = `sub_${Date.now()}_${Math.random().toString(36).slice(2,6)}`;
    db[id] = { id, ...data, createdAt: Date.now() };
    return db[id];
};

// احذف اشتراك
export const removeSub = (id) => {
    const db = getDB();
    const sub = db[id];
    delete db[id];
    return sub;
};

// جيب اشتراك بالـ id
export const getSub = (id) => getDB()[id];

// اشتراكات شخص معين
export const getSubsByUser = (sender) =>
    getAllSubs().filter(s => s.owner === sender);

// استخرج JID القناة من الرابط
export const parseChannelJid = (input) => {
    if (!input) return null;
    input = input.trim();
    // لو JID مباشر
    if (input.includes('@newsletter')) return input;
    // لو رابط whatsapp.com/channel/XXX
    const m = input.match(/channel\/([A-Za-z0-9_-]+)/);
    if (m) return `${m[1]}@newsletter`;
    return null;
};

// وقت منسق
export const formatExpiry = (ms) => {
    const diff = ms - Date.now();
    if (diff <= 0) return 'منتهي';
    const d = Math.floor(diff / 86400000);
    const h = Math.floor((diff % 86400000) / 3600000);
    const min = Math.floor((diff % 3600000) / 60000);
    if (d > 0) return `${d} يوم ${h} ساعة`;
    if (h > 0) return `${h} ساعة ${min} دقيقة`;
    return `${min} دقيقة`;
};
