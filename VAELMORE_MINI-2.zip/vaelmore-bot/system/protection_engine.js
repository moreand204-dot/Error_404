// system/protection_engine.js
// ✧ VAELMORE BOT - محرك الحماية المركزي
// منقول ومُعاد بناؤه من نظام حماية خارجي (Detect → Classify → Risk → Enforce)
// وتم تكييفه بالكامل ليشتغل على فريمورك drakon الخاص بـ VAELMORE، باستخدام نفس
// أدوات المشروع (getG / addWarn / updateParticipant من system/admin_utils.js)
// بدل أي كود تحكم مباشر جديد، عشان يكون التخزين والطرد متسقين مع باقي البوت.

import { getG, addWarn, updateParticipant, isOwnerFn } from './admin_utils.js';

// ==================== أنماط كشف هجمات الكراش ====================
const CRASH_PATTERNS = [
  /[\u0F00-\u0FFF]{18,}/,
  /(ྃ){12,}/,
  /(ꦾ){10,}/,
  /[\u200B-\u200F\u202A-\u202E\u2060-\u206F\uFEFF]{14,}/,
  /[\uFE00-\uFE0F]{22,}/,
  /[\u180B-\u180D]{8,}/,
  /[\uFFF0-\uFFFF]{6,}/,
  /[\uE000-\uF8FF]{14,}/,
  /\u202E.{6,}/,
  /[\u202A-\u202E]{4,}/,
  /[\u{1F300}-\u{1F9FF}]{50,}/u,
  /[\u0300-\u036F]{35,}/,
  /(virtex|troli|bugwa|crashwa|xeontext|payload|crash\s*bot)/i
];

const LINK_REGEX =
  /(?:https?:\/\/|www\.|wa\.me\/|t\.me\/|chat\.whatsapp\.com\/|bit\.ly\/|goo\.gl\/|tinyurl\.com\/)[^\s\u200B-\u200F\u202A-\u202E]{3,}/gi;
const INVITE_REGEX = /chat\.whatsapp\.com\/[A-Za-z0-9]{10,}/i;

export function extractText(m) {
  return (
    m.text || m.body ||
    m.message?.conversation ||
    m.message?.extendedTextMessage?.text ||
    m.message?.imageMessage?.caption ||
    m.message?.videoMessage?.caption ||
    m.message?.documentMessage?.caption ||
    ''
  ).trim();
}

export function extractUrls(text) {
  if (!text) return [];
  LINK_REGEX.lastIndex = 0;
  return (text.match(LINK_REGEX) || []).map(u => u.trim());
}

export function normalizeDomain(raw) {
  try {
    let s = raw.trim().toLowerCase();
    if (!s.startsWith('http')) s = 'https://' + s;
    const u = new URL(s);
    return u.hostname.replace(/^www\./, '');
  } catch {
    return null;
  }
}

export function isDomainAllowed(hostname, allowedList) {
  if (!hostname || !allowedList?.length) return false;
  const h = hostname.toLowerCase();
  return allowedList.some(d => {
    const domain = d.toLowerCase().replace(/^www\./, '');
    return h === domain || h.endsWith('.' + domain);
  });
}

export function hasInviteLink(text) {
  return !!text && INVITE_REGEX.test(text);
}

export function isCrash(text) {
  if (!text) return null;
  if (text.length > 1200) return { reason: 'طول رسالة مفرط', score: 85 };
  for (const p of CRASH_PATTERNS) {
    if (p.test(text)) return { reason: 'نمط كراش معروف', score: 95 };
  }
  const zw = (text.match(/[\u200B-\u200F\u202A-\u202E\u2060-\u206F\uFEFF]/g) || []).length;
  if (zw > 12) return { reason: 'Zero-Width كثيف', score: 80 };
  const rtl = (text.match(/[\u202A-\u202E]/g) || []).length;
  if (rtl > 3) return { reason: 'هجوم اتجاه نص', score: 75 };
  return null;
}

// ==================== تتبع السبام / الفيضان / التكرار (في الذاكرة) ====================
const rateBuckets = new Map();
const dupBuckets = new Map();

function pruneOld(arr, windowMs, now) {
  return arr.filter(t => now - t < windowMs);
}

export function checkSpam(sender, max, windowSec) {
  const key = `spam:${sender}`;
  const now = Date.now();
  let arr = pruneOld(rateBuckets.get(key) || [], windowSec * 1000, now);
  arr.push(now);
  rateBuckets.set(key, arr);
  if (arr.length > max) return { reason: 'إزعاج/سبام 📢', count: arr.length, score: 55 + Math.min(30, arr.length) };
  return null;
}

export function checkFlood(sender, max, windowSec) {
  const key = `flood:${sender}`;
  const now = Date.now();
  let arr = pruneOld(rateBuckets.get(key) || [], windowSec * 1000, now);
  arr.push(now);
  rateBuckets.set(key, arr);
  if (arr.length > max) return { reason: 'فيضان رسائل 🌊', count: arr.length, score: 50 + Math.min(25, arr.length) };
  return null;
}

export function checkDuplicate(sender, text, max, windowSec) {
  if (!text || text.length < 6) return null;
  const key = `dup:${sender}`;
  const hash = text.slice(0, 160).toLowerCase().replace(/\s+/g, ' ');
  const now = Date.now();
  let entry = dupBuckets.get(key) || { hash: null, count: 0, ts: 0 };
  if (entry.hash === hash && now - entry.ts < windowSec * 1000) {
    entry.count += 1;
  } else {
    entry = { hash, count: 1, ts: now };
  }
  dupBuckets.set(key, entry);
  if (entry.count >= max) return { reason: 'تكرار نفس الرسالة 🔁', count: entry.count, score: 45 + entry.count * 5 };
  return null;
}

// تنظيف دوري للـ Map عشان مايكبرش من غير حدود
setInterval(() => {
  const now = Date.now();
  for (const [k, arr] of rateBuckets) {
    if (!arr.length || now - arr[arr.length - 1] > 120000) rateBuckets.delete(k);
  }
  for (const [k, e] of dupBuckets) {
    if (now - e.ts > 120000) dupBuckets.delete(k);
  }
}, 60000);

// ==================== كشف الميديا / التوجيه / المنشن ====================
export function detectMediaType(m) {
  const msg = m.message || {};
  if (msg.imageMessage) return 'image';
  if (msg.videoMessage) return 'video';
  if (msg.documentMessage || msg.documentWithCaptionMessage) return 'document';
  if (msg.stickerMessage) return 'sticker';
  if (msg.audioMessage || msg.pttMessage) return 'audio';
  if (msg.contactMessage || msg.contactsArrayMessage) return 'contact';
  if (msg.locationMessage || msg.liveLocationMessage) return 'location';
  if (msg.pollCreationMessage || msg.pollCreationMessageV2 || msg.pollCreationMessageV3) return 'poll';
  return null;
}

export function isForwarded(m) {
  const ctx =
    m.message?.extendedTextMessage?.contextInfo ||
    m.message?.imageMessage?.contextInfo ||
    m.message?.videoMessage?.contextInfo ||
    m.message?.documentMessage?.contextInfo;
  return !!(ctx?.isForwarded || ctx?.forwardingScore > 0);
}

export function countMentions(m) {
  const ctx = m.message?.extendedTextMessage?.contextInfo || m.message?.imageMessage?.contextInfo || m.message?.videoMessage?.contextInfo;
  return (ctx?.mentionedJid || []).length;
}

// ==================== قاموس السب (فصحى + لهجات + إنجليزي + تحايل) ====================
export const DEFAULT_SWEARS = [
  'كس','كسك','كسمك','كسي','كسها','كس ام','كس امك','كسم','كسمكم','كسمين',
  'زب','زبك','زبي','زبب','زوب','زوبك','زبر','زبره',
  'شرموط','شرموطة','شرموطه','شراميط','قحبة','قحبه','قحاب','عاهرة','عاهر','عهرة',
  'منيوك','منيك','متناك','متناكة','متناكه','نيك','نييك','ينيك','انيك','تناك',
  'عرص','عرصك','يعرص','خول','خولة','خولات','لبوة','لبوه',
  'طيز','طيزك','طيزي','خرا','خراي','خرة','خره','خرء',
  'ابن الكلب','ابن الحرام','بن الحرام',
  'يا كلب','يا حيوان','يا حمار','يا خنزير','يا قرد','يا وسخ','يا نجس','يا قذر','يا تافه','يا حقير',
  'زاني','زانية','زنا','لعق','امص','امصه','مصاص',
  'وسخة','وسخه','قذارة','نجاسة','حثالة','زبالة',
  'كس اختك','كس اخت','كس امك','كس امها','كسم عيشك','يا ابن الوسخة',
  'ابو زبالة','عرصة','معرص','متناكين','واطي','واطية',
  'كسمج','كسمچ','خنيث','خنيثة','لوطي','لواطة',
  'يا خايس','خايس','خايسة','فاشخ','مفشوخ',
  'گحبة','كحبة','جحش','يا جحش','معفن','يا معفن',
  'زامل','طبون','طابون',
  'fuck','fucker','fucking','fucked','motherfucker','mf','stfu',
  'shit','bullshit','asshole','bitch','bitches','slut','whore',
  'dick','cock','pussy','cunt','bastard',
  'damn','crap','piss','retard','douche','wanker','twat',
  'jackass','moron',
  'koss','kosmk','kosomak','sharmota','sharmotaa','ya koss',
  'metnak','ars','ya3ars','kalb',
  'f*ck','f**k','sh*t','b*tch','a$$','a$$hole','fuk','fck'
];

const ARABIC_DIACRITICS = /[\u064B-\u065F\u0670\u06D6-\u06ED\u0640]/g;

export function normalizeForSwearCheck(text) {
  if (!text) return '';
  let t = text.toLowerCase();
  t = t.replace(ARABIC_DIACRITICS, '');
  t = t.replace(/(.)\1{2,}/g, '$1');
  t = t.replace(/(?:^|\s)((?:[\u0600-\u06FF]\s+){2,}[\u0600-\u06FF])(?=\s|$)/g, (m0, g1) => ' ' + g1.replace(/\s+/g, '') + ' ');
  t = t.replace(/3/g, 'ع').replace(/7/g, 'ح').replace(/[$]/g, 's');
  return t;
}

export function checkSwear(text, extraWords) {
  if (!text) return null;
  const raw = text.toLowerCase().replace(/[^\u0600-\u06FFa-z0-9\s*$]/gi, ' ');
  const normalized = normalizeForSwearCheck(raw);
  const list = [...DEFAULT_SWEARS, ...(extraWords || [])];
  for (const w of list) {
    if (!w || w.length < 2) continue;
    const needle = w.toLowerCase();
    const escaped = needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const re = new RegExp('(?:^|\\s)' + escaped + '(?:\\s|$)', 'i');
    if (re.test(raw) || raw.includes(needle) || re.test(normalized) || normalized.includes(needle)) {
      return { reason: `سب/شتيمة 🤬 (${w})`, score: 70 };
    }
  }
  return null;
}

export function checkWordFilter(text, words) {
  if (!text || !words?.length) return null;
  const lower = text.toLowerCase();
  for (const w of words) {
    if (w && lower.includes(String(w).toLowerCase())) {
      return { reason: `كلمة محظورة (${w}) 🚫`, score: 60 };
    }
  }
  return null;
}

// ==================== المحرك المركزي: تقييم + تنفيذ ====================
const MEDIA_FLAG = {
  image: 'antiImage', video: 'antiVideo', document: 'antiDocument',
  sticker: 'antiSticker', audio: 'antiAudio', contact: 'antiContact',
  location: 'antiLocation', poll: 'antiPoll'
};
const MEDIA_LABEL = {
  image: 'إرسال صورة 🖼️', video: 'إرسال فيديو 🎬', document: 'إرسال ملف 📁',
  sticker: 'إرسال ستيكر 🎭', audio: 'إرسال صوت 🔉', contact: 'إرسال جهة اتصال 👤',
  location: 'إرسال موقع 📍', poll: 'إرسال استطلاع 📊'
};

/**
 * يفحص رسالة جروب ويرجّع أول مخالفة لقاها (أو null لو مفيش حاجة).
 * لا يطبّق أي إجراء بنفسه - فقط يكتشف؛ enforceViolation هي اللي بتنفّذ.
 */
export function evaluateMessage(m, g) {
  const text = extractText(m);

  if (g.antiCrash) {
    const c = isCrash(text);
    if (c) return c;
  }

  if (g.antiLink || g.antiLinkInvite) {
    const urls = extractUrls(text);
    for (const u of urls) {
      if (g.antiLinkInvite && hasInviteLink(u)) return { reason: 'رابط دعوة واتساب 🔗' };
      const host = normalizeDomain(u);
      if (host && g.antiLink && !isDomainAllowed(host, g.allowedLinks || [])) {
        return { reason: `رابط غير مسموح 🔗 (${host})` };
      }
    }
  }

  if (g.antiSpam) {
    const s = checkSpam(m.sender, g.spamMax || 7, g.spamWindow || 12);
    if (s) return s;
  }
  if (g.antiFlood) {
    const f = checkFlood(m.sender, g.floodMax || 14, g.floodWindow || 18);
    if (f) return f;
  }
  if (g.antiDuplicate) {
    const d = checkDuplicate(m.sender, text, g.duplicateMax || 3, g.duplicateWindow || 30);
    if (d) return d;
  }

  if (g.antiTag) {
    const cnt = countMentions(m);
    if (cnt >= (g.mentionMax || 5)) return { reason: `منشن جماعي 🏷️ (${cnt})` };
  }

  const media = detectMediaType(m);
  if (media && g[MEDIA_FLAG[media]]) return { reason: MEDIA_LABEL[media] };

  if (g.antiForward && isForwarded(m)) return { reason: 'رسالة معاد توجيهها ↪️' };

  if (g.wordFilter && g.words?.length) {
    const w = checkWordFilter(text, g.words);
    if (w) return w;
  }

  if (g.antiSwear) {
    const sw = checkSwear(text, g.swearExtra || []);
    if (sw) return sw;
  }

  return null;
}

/**
 * ينفّذ إجراء المخالفة: يمسح الرسالة (لو ينفع) + يسجل إنذار (بيطرد تلقائي عند
 * وصول العدد للحد الأقصى، عبر addWarn الموجودة أصلاً في admin_utils.js) —
 * أو طرد فوري لو الوضع "مشددة".
 */
export async function enforceViolation(m, conn, bot, g, violation) {
  try { await conn.sendMessage(m.chat, { delete: m.key }); } catch {}

  g.stats = g.stats || {};
  g.stats.blocked = (g.stats.blocked || 0) + 1;
  g.log = g.log || [];
  g.log.unshift({ sender: m.sender, reason: violation.reason, ts: Date.now() });
  if (g.log.length > 50) g.log.length = 50;
  g.offenders = g.offenders || {};
  g.offenders[m.sender] = (g.offenders[m.sender] || 0) + 1;

  if (g.strictMode) {
    try {
      await conn.sendMessage(m.chat, {
        text: `⛔ *وضع الحماية المشددة - اتطرد @${m.sender.split('@')[0]}*\nالسبب: ${violation.reason}`,
        mentions: [m.sender]
      });
      await updateParticipant(m.chat, m.sender, 'remove', conn);
      g.stats.kicked = (g.stats.kicked || 0) + 1;
    } catch {}
    return;
  }

  await addWarn(m.chat, m.sender, conn, violation.reason, bot);
}

export { getG, isOwnerFn };
